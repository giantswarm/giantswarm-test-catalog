# support-portal

Giant Swarm Support Portal. Customers raise and follow tickets that live as GitHub issues in their repositories.

**Homepage:** <https://github.com/giantswarm/support-portal>

## Source Code

* <https://github.com/giantswarm/support-portal>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
|  | keycloak | 0.1.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| image.registry | string | `"gsociprivate.azurecr.io"` |  |
| image.name | string | `"giantswarm/support-portal"` |  |
| image.tag | string | `""` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| imagePullSecret.name | string | `"support-portal-pull-secret"` |  |
| imagePullSecret.dockerconfigjson | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| global.portalHostname | string | `"support.operations.awsprod.gigantic.io"` |  |
| global.keycloak.hostname | string | `"support-auth.operations.awsprod.gigantic.io"` |  |
| global.keycloak.realm | string | `"support"` |  |
| global.keycloak.staffIdpAlias | string | `"github"` |  |
| global.existingSecrets.portal | string | `""` |  |
| global.existingSecrets.keycloak | string | `""` |  |
| replicas | int | `2` |  |
| config.TICKET_BACKEND | string | `"github"` |  |
| config.OIDC_CLIENT_ID | string | `"support-portal"` |  |
| config.KEYCLOAK_ADMIN_CLIENT_ID | string | `"support-portal-admin"` |  |
| config.STAFF_GITHUB_ORG | string | `"giantswarm"` |  |
| config.STAFF_GITHUB_TEAM | string | `""` |  |
| config.GITHUB_APP_ID | string | `""` |  |
| config.GITHUB_APP_INSTALLATION_ID | string | `""` |  |
| config.TRUSTED_BOT_LOGINS | string | `""` |  |
| config.S3_ENDPOINT | string | `"s3.eu-central-1.amazonaws.com"` |  |
| config.S3_REGION | string | `"eu-central-1"` |  |
| config.S3_BUCKET | string | `"giantswarm-operations-support-portal"` |  |
| config.S3_USE_TLS | string | `"true"` |  |
| config.MAX_UPLOAD_MB | string | `"25"` |  |
| config.UPLOAD_QUOTA_DAILY_MB | string | `"2048"` |  |
| config.UPLOAD_QUOTA_TOTAL_MB | string | `"20480"` |  |
| config.UPLOAD_RATE_PER_HOUR | string | `"20"` |  |
| config.EMAIL_ENABLED | string | `"false"` |  |
| config.SMTP_ADDR | string | `""` |  |
| config.MAIL_FROM | string | `"Giant Swarm Support <support@giantswarm.io>"` |  |
| credentials.env | object | `{}` |  |
| customers | list | `[]` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `""` |  |
| serviceAccount.awsRoleArn | string | `"arn:aws:iam::637807836937:role/operations-support-portal"` |  |
| serviceAccount.annotations | object | `{}` |  |
| route.enabled | bool | `true` |  |
| route.gateway.name | string | `"giantswarm-default"` |  |
| route.gateway.namespace | string | `"envoy-gateway-system"` |  |
| route.gateway.sectionName | string | `"https"` |  |
| service.port | int | `80` |  |
| service.metricsPort | int | `9090` |  |
| serviceMonitor.enabled | bool | `true` |  |
| serviceMonitor.interval | string | `"60s"` |  |
| serviceMonitor.scrapeTimeout | string | `"10s"` |  |
| networkPolicy.enabled | bool | `true` |  |
| networkPolicy.gateway.namespace | string | `"envoy-gateway-system"` |  |
| networkPolicy.gateway.podLabels."app.kubernetes.io/name" | string | `"envoy"` |  |
| networkPolicy.gateway.podLabels."app.kubernetes.io/component" | string | `"proxy"` |  |
| networkPolicy.monitoring.namespace | string | `"kube-system"` |  |
| networkPolicy.monitoring.podLabels."app.kubernetes.io/name" | string | `"alloy"` |  |
| networkPolicy.monitoring.podLabels."app.kubernetes.io/instance" | string | `"alloy-metrics"` |  |
| networkPolicy.dns.namespace | string | `"kube-system"` |  |
| networkPolicy.postgresOperator.namespace | string | `"postgres-operator"` |  |
| networkPolicy.postgresOperator.podLabels."app.kubernetes.io/name" | string | `"postgres-operator"` |  |
| networkPolicy.externalPorts[0] | int | `443` |  |
| networkPolicy.smtpPorts[0] | int | `587` |  |
| networkPolicy.smtpPorts[1] | int | `465` |  |
| networkPolicy.extraIngressFrom | list | `[]` |  |
| podDisruptionBudget.enabled | bool | `true` |  |
| podDisruptionBudget.minAvailable | int | `1` |  |
| resources.requests.cpu | string | `"50m"` |  |
| resources.requests.memory | string | `"64Mi"` |  |
| resources.limits.memory | string | `"256Mi"` |  |
| uploads.requestFactor | int | `10` |  |
| uploads.concurrentRequests | int | `4` |  |
| uploads.headroomMi | int | `256` |  |
| shutdown.preStopSleepSeconds | int | `10` |  |
| shutdown.shutdownTimeoutSeconds | int | `20` |  |
| podSecurityContext.runAsNonRoot | bool | `true` |  |
| podSecurityContext.runAsUser | int | `65532` |  |
| podSecurityContext.runAsGroup | int | `65532` |  |
| podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| securityContext.allowPrivilegeEscalation | bool | `false` |  |
| securityContext.readOnlyRootFilesystem | bool | `true` |  |
| securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| nodeSelector | object | `{}` |  |
| tolerations | list | `[]` |  |
| affinity | object | `{}` |  |
| podAnnotations | object | `{}` |  |
| keycloak.enabled | bool | `true` |  |
