You're invited to the Giant Swarm support portal.

Set your password here:
${link}

The link is valid for ${linkExpirationFormatter(linkExpiration)}.
