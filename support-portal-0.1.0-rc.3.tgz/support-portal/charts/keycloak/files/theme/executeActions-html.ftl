<#-- Invitation email, design "Email · Invitation". Keycloak sends it when an admin invites a user. -->
<html>
<body style="margin:0;padding:0;background:#f0f7f9;font-family:Roboto,'Helvetica Neue',Helvetica,Arial,sans-serif;color:#002645">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f0f7f9"><tr><td align="center" style="padding:32px 16px">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%">
<tr><td style="background:#ffffff;border-radius:14px;padding:40px">
<table role="presentation" cellpadding="0" cellspacing="0"><tr>
<td style="padding-right:6px"><img src="${(properties.portalUrl)!''}/static/logo.png" alt="" width="31" height="28" style="display:block"></td>
<td style="font-size:16px"><strong>Giant Swarm</strong> <span style="font-weight:300">Support</span></td></tr></table>
<h1 style="margin:22px 0 0;font-size:24px;font-weight:500;line-height:1.3">You&rsquo;re invited to the Giant Swarm support portal</h1>
<p style="margin:14px 0 0;font-size:15px;line-height:1.6;color:#30475a">Set a password to raise and follow support requests with Giant Swarm.</p>
<p style="margin:22px 0 0"><a href="${link}" style="display:inline-block;padding:14px 22px;border-radius:10px;background:#002645;color:#ffffff;font-size:15px;font-weight:500;text-decoration:none">Set your password</a></p>
<p style="margin:22px 0 0;font-size:13px;color:#5b6c79">The link is valid for ${linkExpirationFormatter(linkExpiration)}.</p>
</td></tr>
<tr><td style="padding:16px 4px;font-size:12px;color:#5b6c79">Giant Swarm GmbH</td></tr>
</table></td></tr></table>
</body>
</html>
