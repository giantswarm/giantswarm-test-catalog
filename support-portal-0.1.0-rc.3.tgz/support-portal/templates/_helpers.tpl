{{- define "support-portal.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "support-portal.fullname" -}}
{{- if contains .Chart.Name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "support-portal.selectorLabels" -}}
app.kubernetes.io/name: {{ include "support-portal.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "support-portal.labels" -}}
{{ include "support-portal.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
application.giantswarm.io/team: {{ index .Chart.Annotations "application.giantswarm.io/team" | quote }}
{{- end -}}

{{- define "support-portal.image" -}}
{{ .Values.image.registry }}/{{ .Values.image.name }}:{{ .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}

{{- define "support-portal.secretName" -}}
{{- include "support-portal.existingSecret" . | default (include "support-portal.fullname" .) -}}
{{- end -}}

{{- define "support-portal.portalURL" -}}
{{- printf "https://%s" (required "global.portalHostname is required" .Values.global.portalHostname) -}}
{{- end -}}

{{/* Size of /tmp in Mi: concurrent worst-case upload requests plus headroom. */}}
{{- define "support-portal.tmpMi" -}}
{{- $mb := int (.Values.config.MAX_UPLOAD_MB | default 25) -}}
{{- $u := .Values.uploads -}}
{{- add (mul $mb (int $u.requestFactor) (int $u.concurrentRequests)) (int $u.headroomMi) -}}
{{- end -}}

{{- define "support-portal.tmpSizeLimit" -}}
{{- printf "%sMi" (include "support-portal.tmpMi" .) -}}
{{- end -}}

{{- define "support-portal.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- .Values.serviceAccount.name | default (include "support-portal.fullname" .) -}}
{{- else -}}
{{- .Values.serviceAccount.name | default "default" -}}
{{- end -}}
{{- end -}}

{{- define "support-portal.existingSecret" -}}
{{- with .Values.global.existingSecrets }}{{ .portal | default "" }}{{ end -}}
{{- end -}}

{{/* Service of the Keycloak subchart: its fullname for this release. */}}
{{- define "support-portal.keycloakService" -}}
{{- if contains "keycloak" .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-keycloak" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/* Environment of the portal: settings derived from the Keycloak subchart,
overridden by .Values.config. */}}
{{- define "support-portal.env" -}}
{{- $env := dict -}}
{{- if .Values.keycloak.enabled -}}
{{- $realm := .Values.global.keycloak.realm | default "support" -}}
{{- $internal := printf "http://%s:8080" (include "support-portal.keycloakService" .) -}}
{{- $_ := set $env "OIDC_ISSUER" (printf "https://%s/realms/%s" (required "global.keycloak.hostname is required" .Values.global.keycloak.hostname) $realm) -}}
{{- $_ := set $env "OIDC_DISCOVERY_URL" (printf "%s/realms/%s" $internal $realm) -}}
{{- $_ := set $env "KEYCLOAK_URL" $internal -}}
{{- $_ := set $env "KEYCLOAK_REALM" $realm -}}
{{- end -}}
{{- $_ := set $env "STAFF_IDP_ALIAS" (.Values.global.keycloak.staffIdpAlias | default "github") -}}
{{- range $k, $v := .Values.config -}}
{{- $_ := set $env $k (toString $v) -}}
{{- end -}}
{{- if hasKey $env "STAFF_GROUP_TRUSTED" -}}
{{- fail "config.STAFF_GROUP_TRUSTED is for the local kind setup only; staff are GitHub organisation members" -}}
{{- end -}}
{{- if not $env.OIDC_ISSUER -}}
{{- fail "config.OIDC_ISSUER is required when keycloak.enabled is false" -}}
{{- end -}}
{{- toYaml $env -}}
{{- end -}}

{{/* Pull secrets of the portal pods: the rendered one plus existing ones. */}}
{{- define "support-portal.imagePullSecrets" -}}
{{- $list := list -}}
{{- if .Values.imagePullSecret.dockerconfigjson -}}
{{- $list = append $list (dict "name" .Values.imagePullSecret.name) -}}
{{- end -}}
{{- range .Values.imagePullSecrets -}}
{{- $list = append $list . -}}
{{- end -}}
{{- toYaml $list -}}
{{- end -}}

{{/* The Keycloak subchart's database cluster (support-portal-keycloak.dbCluster),
computed from the parent for the network policies. */}}
{{- define "support-portal.keycloakDBCluster" -}}
{{- $kc := ternary .Release.Name (printf "%s-keycloak" .Release.Name) (contains "keycloak" .Release.Name) | trunc 63 | trimSuffix "-" -}}
{{- printf "%s-db" $kc | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Egress to the cluster DNS. CoreDNS listens on 1053 behind the Service's
port 53, and policies apply after the Service is resolved. */}}
{{- define "support-portal.ciliumDNS" -}}
- toEndpoints:
    - matchLabels:
        io.kubernetes.pod.namespace: {{ .dns.namespace }}
  toPorts:
    - ports:
        - {port: "53", protocol: UDP}
        - {port: "53", protocol: TCP}
        - {port: "1053", protocol: UDP}
        - {port: "1053", protocol: TCP}
{{- end -}}

{{- define "support-portal.networkPolicyDNS" -}}
- to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: {{ .dns.namespace }}
  ports:
    - {port: 53, protocol: UDP}
    - {port: 53, protocol: TCP}
    - {port: 1053, protocol: UDP}
    - {port: 1053, protocol: TCP}
{{- end -}}
