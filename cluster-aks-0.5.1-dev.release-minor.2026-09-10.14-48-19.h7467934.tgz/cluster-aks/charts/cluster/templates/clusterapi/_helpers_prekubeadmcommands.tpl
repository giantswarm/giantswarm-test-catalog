{{/*
    Template cluster.internal.kubeadm.preKubeadmCommands defines common commands to run on all
    (control plane and workers) nodes before kubeadm runs.

    It includes:
    - provider-independent commands defined in cluster chart,
    - provider-specific commands specified in cluster-<provider> app,
    - custom cluster-specific commands.
*/}}
{{- define "cluster.internal.kubeadm.preKubeadmCommands" }}
{{- include "cluster.internal.kubeadm.preKubeadmCommands.flatcar" $ }}
{{- include "cluster.internal.kubeadm.preKubeadmCommands.ssh" $ }}
{{- include "cluster.internal.kubeadm.preKubeadmCommands.proxy" $ }}
{{- include "cluster.internal.kubeadm.preKubeadmCommands.selinux" $ }}
{{- include "cluster.internal.kubeadm.preKubeadmCommands.provider" $ }}
{{- include "cluster.internal.kubeadm.preKubeadmCommands.custom" $ }}
{{- end }}

{{- define "cluster.internal.kubeadm.preKubeadmCommands.selinux" }}
{{- if ne $.Values.global.components.selinux.mode "disabled" }}
{{- if $.Values.global.components.selinux.writablePolicyStore }}
# Make `/var/lib/selinux` writable for loading additional policies
- rm -rf /var/lib/selinux
- cp -a /usr/lib/selinux/policy /var/lib/selinux
- semodule -DB
# Load policy for containerd to work with any container_domain type (other than container_t)
- semodule -i /etc/selinux/flatcar-containerd-patch.cil
{{- end }}
# Remove audit rules that suppress SELinux AVC logs in Flatcar
# Required for generating SELinux policies (e.g. using security-profiles-operator)
- rm -f /etc/audit/rules.d/80-selinux.rules
- systemctl restart audit-rules
# All certs in /etc/ssl/certs are symlinked to /usr/share/ca-certificates in Flatcar
# /usr is unlabeled and read-only in Flatcar. Copy certs to /etc/ssl/certs for correct labeling
# Required for mounting /etc/ssl/certs into containers (e.g. kube-apiserver, cluster-autoscaler)
- rm -rf /etc/ssl/certs
- cp -a /usr/share/ca-certificates /etc/ssl/certs
# Fix SELinux labels for everything except `/usr` (read-only in Flatcar)
- restorecon -RFv -e /usr /
# Change label for kube-apiserver audit log directory for access from containers
- mkdir -p /var/log/apiserver
- chcon -R -t container_file_t /var/log/apiserver
{{- end }}
{{- end }}

{{- define "cluster.internal.kubeadm.preKubeadmCommands.flatcar" }}
- envsubst < /etc/kubeadm.yml > /etc/kubeadm.yml.tmp
- mv /etc/kubeadm.yml.tmp /etc/kubeadm.yml
- systemctl restart containerd
{{- end }}

{{- define "cluster.internal.kubeadm.preKubeadmCommands.ssh" }}
{{- if $.Values.providerIntegration.resourcesApi.bastionResourceEnabled }}
{{- if .Values.global.connectivity.bastion.enabled }}
- systemctl restart sshd
{{- end }}
{{- end }}
{{- end }}

{{- define "cluster.internal.kubeadm.preKubeadmCommands.proxy" }}
{{- if and $.Values.global.connectivity.proxy $.Values.global.connectivity.proxy.enabled }}
- export HTTP_PROXY={{ $.Values.global.connectivity.proxy.httpProxy }}
- export HTTPS_PROXY={{ $.Values.global.connectivity.proxy.httpsProxy }}
- export NO_PROXY="{{ include "cluster.connectivity.proxy.noProxy" (dict "global" $.Values.global "providerIntegration" $.Values.providerIntegration) }}"
- export http_proxy={{ $.Values.global.connectivity.proxy.httpProxy }}
- export https_proxy={{ $.Values.global.connectivity.proxy.httpsProxy }}
- export no_proxy="{{ include "cluster.connectivity.proxy.noProxy" (dict "global" $.Values.global "providerIntegration" $.Values.providerIntegration) }}"
{{- end }}
{{- end }}

{{/* Provider-specific commands to run before kubeadm on all nodes */}}
{{- define "cluster.internal.kubeadm.preKubeadmCommands.provider" }}
{{- range $command := $.Values.providerIntegration.kubeadmConfig.preKubeadmCommands }}
- {{ $command }}
{{- end }}
{{- end }}

{{/* Custom cluster-specific commands to run before kubeadm on all nodes */}}
{{- define "cluster.internal.kubeadm.preKubeadmCommands.custom" }}
{{- range $command := $.Values.internal.advancedConfiguration.preKubeadmCommands }}
- {{ $command }}
{{- end }}
{{- end }}
