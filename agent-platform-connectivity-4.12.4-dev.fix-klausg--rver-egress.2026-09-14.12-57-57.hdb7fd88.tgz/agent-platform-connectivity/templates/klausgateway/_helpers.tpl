{{/* vim: set filetype=mustache: */}}
{{/*
Helpers of the klaus-gateway component's wiring (templates/klausgateway/).

One values block feeds these templates: klausGateway — the klaus-gateway
chart's own values as the meta chart forwards them (the store, controller,
Slack, OBO and A2A knobs) plus the umbrella's wiring keys (agentgatewayRoute).
A component release's values cannot be derived at render time, so the wiring
reads what the chart will see; a knob the block does not declare is read with
the klaus-gateway chart's own default.
*/}}

{{/*
The klaus-gateway pod's app.kubernetes.io/name label value: the chart's
fullnameOverride, else its chart name. Every policy selecting the gateway pod
uses this, so a renamed release moves them all.
*/}}
{{- define "agent-platform.klausGateway.fullname" -}}
{{- .Values.klausGateway.fullnameOverride | default "klaus-gateway" -}}
{{- end -}}

{{/*
Truthy (emits "true") when the gateway pod reads or writes the Kubernetes API,
so its egress needs the kube-apiserver: the Secret link store
(klausGateway.obo.store: secret with OBO on — the gateway's own gate,
klaus-gateway's obo.secretStore helper), a cluster-backed routing store
(klausGateway.routing.store: configmap or crd) or the embedded ChannelRoute
controller (klausGateway.controller.enabled). Empty otherwise: the default
shape — memory routing, the bolt link store, no controller — never touches
the API and gets no rule. The store and controller keys are the klaus-gateway
chart's; when the block leaves one unset its chart default applies (bolt,
memory, off).
*/}}
{{- define "agent-platform.klausGateway.apiServerEgress" -}}
{{- $kg := .Values.klausGateway -}}
{{- $secretLinks := and (dig "obo" "enabled" false $kg) (eq (dig "obo" "store" "bolt" $kg) "secret") -}}
{{- $clusterRoutes := has (dig "routing" "store" "memory" $kg) (list "configmap" "crd") -}}
{{- if or $secretLinks $clusterRoutes (dig "controller" "enabled" false $kg) -}}true{{- end -}}
{{- end -}}
