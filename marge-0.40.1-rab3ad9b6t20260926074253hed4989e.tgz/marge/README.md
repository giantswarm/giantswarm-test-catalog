# marge

![Version: 0.1.0](https://img.shields.io/badge/Version-0.1.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.1.0](https://img.shields.io/badge/AppVersion-0.1.0-informational?style=flat-square)

A housekeeping tool for dependency update PRs, served as an MCP server

Runs `marge serve --transport streamable-http`: the `sweep` and `mark` MCP tools on `/mcp`, with `/healthz` and `/readyz` for the probes. Register the Service as a streamable-http MCP server in muster to make the tools available to people and agents.

marge needs a GitHub token with the permissions listed in the [repository README](https://github.com/giantswarm/marge#setup). Pass it inline (`marge.github.token`, the chart writes a Secret) or point at an existing Secret (`marge.github.existingSecret`, key `marge.github.existingSecretKey`). A CircleCI token (`marge.circleci.*`) is optional; it lets marge inspect private CircleCI projects and retry auto-cancelled builds.

## The scheduled sweep

`schedules` holds one entry per scheduled run, and each entry renders one CronJob. An entry names a team and a cron expression, so every team carries its own cadence, its own steps and its own suspension:

```yaml
schedules:
  - name: bumblebee-sweep
    team: bumblebee
    schedule: "0 6 * * 1-5"
  - name: atlas-sweep
    team: atlas
    schedule: "10 6 * * 1-5"
```

An entry takes the keys it does not set from `scheduleDefaults`, and overrides any of them, `activeDeadlineSeconds` included: keep the fleet default in `scheduleDefaults` and raise it on the one entry whose queue needs longer. `suspend` pauses one run and `suspendAll` pauses every run, in both cases without deleting the entry. Stagger the expressions: every run acts as the same GitHub App and shares its rate limit.

A run sweeps one team: it classifies, approves, merges, refreshes stale branches, retries cancelled builds and applies the catalogue's rules. Every one of those steps acts through the GitHub or CircleCI API, so a scheduled run writes no code to any branch. The team's policy file in `giantswarm/github` says what may merge.

The schedule acts as the App and never as a person. Set `marge.github.app` and the CronJob mints an installation token per repository, for one hour, and stores none. Without `marge.github.app` the chart refuses to render an enabled schedule. The App's credentials live in 1Password, in the `Team Bumblebee` vault, in the item `marge sweep GitHub App`; see [docs/github-app.md](https://github.com/giantswarm/marge/blob/main/docs/github-app.md).

Set `notices.gatewayURL` and each run posts one summary to the notices channel of the team's channel file, `teams/team-<name>.yaml`, for every team whose policy sets `summary: true`, through klaus-gateway's team-notice endpoint (`POST /notices`). The run authenticates as its own ServiceAccount: the CronJob projects a token for `notices.audience`, the gateway verifies it with a `TokenReview` and admits the ServiceAccounts its own `reviews.allowedCallers` names. The gateway holds the Slack app, so the chart holds no Slack token. A run that changed nothing posts nothing, and a team whose policy names no channel is reported in the run's log. A run Kubernetes stopped at `activeDeadlineSeconds` is the exception: it posts what it had reached, and what it had not, because silence in the channel otherwise reads as "nothing changed". A scheduled run passes `--post-summary`, which a sweep by hand does not, so a manual sweep stays out of the team channels.

An entry that sets `args` passes them to the binary as the whole command line, and `tokenAudience` mounts a projected ServiceAccount token at `/var/run/secrets/kagent`. That pair is how the weekly rescue trigger will run. Keep such an entry suspended until the rescue command exists.

**Homepage:** <https://github.com/giantswarm/marge>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Giant Swarm | <team-bumblebee@giantswarm.io> |  |

## Source Code

* <https://github.com/giantswarm/marge>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| mcp.enabled | bool | `true` | Run the MCP server: the Deployment, its Service and its NetworkPolicy. Turn it off on an installation that runs the scheduled sweep alone. Registering the server with a muster is the platform's job: an MCPServer that points at the Service URL, with the muster's own GitHub client. |
| replicaCount | int | `1` | Number of marge replicas. The MCP transport is stateful per session, so keep it at 1 unless a client-affine load balancer sits in front. |
| image.registry | string | `"gsoci.azurecr.io"` | Registry of the marge image |
| image.repository | string | `"giantswarm/marge"` | Repository of the marge image |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| image.tag | string | `""` | Overrides the image tag whose default is the chart appVersion. |
| imagePullSecrets | list | `[]` | Image pull secrets for the pod |
| nameOverride | string | `""` | Overrides the chart name in resource names |
| fullnameOverride | string | `""` | Overrides the fully qualified resource name |
| serviceAccount.create | bool | `true` | Create a ServiceAccount for the pod. marge talks to GitHub and CircleCI only, so it needs no Kubernetes API access. |
| serviceAccount.automount | bool | `false` | Mount the ServiceAccount token into the pod |
| serviceAccount.annotations | object | `{}` | Annotations to add to the ServiceAccount |
| serviceAccount.name | string | `""` | Name of the ServiceAccount to use. Generated from the fullname when empty and create is true. |
| podAnnotations | object | `{}` | Annotations to add to the pod |
| podLabels | object | `{}` | Labels to add to the pod |
| podSecurityContext | object | `{"fsGroup":1000,"runAsGroup":1000,"runAsNonRoot":true,"runAsUser":1000,"seccompProfile":{"type":"RuntimeDefault"}}` | Pod-level security context (restricted Pod Security Standard) |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsGroup":1000,"runAsNonRoot":true,"runAsUser":1000,"seccompProfile":{"type":"RuntimeDefault"}}` | Container security context (restricted Pod Security Standard) |
| service.type | string | `"ClusterIP"` | Service type |
| service.port | int | `8080` | Service port; the container listens on 8080 |
| resources | object | `{"limits":{"cpu":"2","ephemeral-storage":"1Gi","memory":"512Mi"},"requests":{"cpu":"100m","ephemeral-storage":"50Mi","memory":"128Mi"}}` | Container resources. One pod answers every person reading the Bot PRs page at once, and a single read runs its GitHub requests in parallel, so the CPU limit bounds how many of those a pod can hold. The pod mounts an emptyDir on /tmp, so ephemeral-storage is bounded as well: a container that mounts one without both bounds is refused by the restricted policies. |
| nodeSelector | object | `{}` | Node selector for the pod |
| tolerations | list | `[]` | Tolerations for the pod |
| affinity | object | `{}` | Affinity for the pod |
| marge.github.token | string | `""` | GitHub token marge uses (needs the permissions listed in the repository README). The chart writes it into a Secret; prefer existingSecret in production. The scheduled sweeps ignore it and act as the App instead. |
| marge.github.existingSecret | string | `""` | Name of an existing Secret holding the GitHub token. Takes precedence over token. |
| marge.github.existingSecretKey | string | `"token"` | Key of the GitHub token inside existingSecret |
| marge.github.app.id | string | `""` | Numeric ID of the sweep GitHub App. Required by the scheduled sweeps, which mint an installation token per repository instead of holding a token. |
| marge.github.app.installationId | string | `""` | Numeric ID of the App's installation on the organization. |
| marge.github.app.privateKey | string | `""` | PEM private key of the App. The chart writes it into a Secret; prefer existingSecret in production. The values of this item live in 1Password, in the Team Bumblebee vault, item "marge sweep GitHub App". |
| marge.github.app.existingSecret | string | `""` | Name of an existing Secret holding the App credential. Takes precedence over the inline values, and must carry every key named below. |
| marge.github.app.idKey | string | `"github-app-id"` | Key of the App ID inside the Secret |
| marge.github.app.installationIdKey | string | `"github-app-installation-id"` | Key of the installation ID inside the Secret |
| marge.github.app.privateKeyKey | string | `"github-app-private-key"` | Key of the PEM private key inside the Secret |
| marge.circleci.token | string | `""` | CircleCI API token, optional: lets marge inspect private CircleCI projects and retry auto-cancelled builds. The chart writes it into a Secret; prefer existingSecret in production. |
| marge.circleci.existingSecret | string | `""` | Name of an existing Secret holding the CircleCI token. Takes precedence over token. |
| marge.circleci.existingSecretKey | string | `"token"` | Key of the CircleCI token inside existingSecret |
| notices.gatewayURL | string | `""` | klaus-gateway as reached from the pod, for example `http://klaus-gateway.agent-platform.svc:8080`. Empty posts no summary: the run does its work and reports it on its own output. |
| notices.audience | string | `"klaus-gateway"` | Audience the run projects its ServiceAccount token for; the gateway's own `reviews.audience`. |
| notices.gatewayNamespace | string | `"agent-platform"` | Namespace the gateway runs in, for the egress rule of each scheduled run. The URL is not parsed, so it is named here as well. |
| notices.gatewayPort | int | `8080` | Port the gateway serves the endpoint on, for the same egress rule. |
| suspendAll | bool | `false` | Suspend every scheduled run without deleting its entry. A single run is suspended on its own entry instead. |
| scheduleDefaults | object | `{"actions":"classify,approve,merge,refresh,retry,remedy,mark","activeDeadlineSeconds":3600,"dryRun":false,"failedJobsHistoryLimit":3,"resources":{"limits":{"cpu":1,"ephemeral-storage":"1Gi","memory":"512Mi"},"requests":{"cpu":"100m","ephemeral-storage":"50Mi","memory":"128Mi"}},"successfulJobsHistoryLimit":3,"timeZone":"Europe/Berlin"}` | Values every entry of schedules takes for the keys it does not set itself. |
| scheduleDefaults.timeZone | string | `"Europe/Berlin"` | IANA timezone the cron expressions are read in. |
| scheduleDefaults.actions | string | `"classify,approve,merge,refresh,retry,remedy,mark"` | Sweep steps a scheduled sweep performs. Every step here acts through the GitHub or CircleCI API; none of them writes code to a branch. |
| scheduleDefaults.dryRun | bool | `false` | Report every outcome without writing anything. Turn it on for the first runs on a new installation. |
| scheduleDefaults.activeDeadlineSeconds | int | `3600` | Seconds a scheduled run may take before Kubernetes stops it. An entry of schedules overrides it for its own run. A stopped run posts what it had reached before it was stopped. |
| scheduleDefaults.successfulJobsHistoryLimit | int | `3` | Successful Jobs kept |
| scheduleDefaults.failedJobsHistoryLimit | int | `3` | Failed Jobs kept |
| scheduleDefaults.resources | object | `{"limits":{"cpu":1,"ephemeral-storage":"1Gi","memory":"512Mi"},"requests":{"cpu":"100m","ephemeral-storage":"50Mi","memory":"128Mi"}}` | Container resources of a scheduled run. The pod mounts an emptyDir on /tmp, so ephemeral-storage is bounded as well: a container that mounts one without both bounds is refused by the restricted policies. |
| schedules | list | `[]` | Scheduled runs, one CronJob each. An entry sweeps one team, so every team carries its own cadence and its own suspension. Needs marge.github.app. Stagger the expressions: every run acts as the same GitHub App and shares its rate limit. |
| networkPolicy.enabled | bool | `true` | Create a NetworkPolicy: ingress to the MCP port from the selected namespaces, egress to DNS and HTTPS only (GitHub, CircleCI). |
| networkPolicy.ingressNamespaceSelector | object | `{}` | Namespaces allowed to reach the MCP port; an empty selector allows every namespace of the cluster. |
