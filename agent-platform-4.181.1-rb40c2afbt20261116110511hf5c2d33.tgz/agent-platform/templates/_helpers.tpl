{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- /*
The helm.sh/chart label: <name>-<version> as a valid label value. A label is at
most 63 characters and must end on an alphanumeric: Helm's `+` build metadata
(helm-controller appends the OCI digest to every chart version it installs,
`3.20.0+8c89e1be4cbf`) becomes `_`, and after the cut every trailing `-`, `.`
and `_` goes — a branch build's long prerelease version (the superseded abs
shape `3.19.1-dev.<branch>.<date>.h<sha>`; gitsemver 3's
`X.Y.Z-r<branch-hash>t<time>h<sha>` holds neither `.` nor `-`, so only the `_`
is left to land on) made the cut land on the `_` once, and the apiserver
rejected every object of the release. tests/verify-labels.py.
*/ -}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimAll "-._" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "labels.common" -}}
app: {{ include "name" . | quote }}
{{ include "labels.selector" . }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
The owning team as an annotation, from the same chart annotation as the team
label. kube-state-metrics reads it off the Flux objects into the `team` label of
gotk_resource_info, so an alert on a HelmRelease or OCIRepository this chart
renders names the team. The team-stamper controller writes the team from its
apps-to-teams mapping (keyed by the chart name of the OCIRepository URL), which
does not list every component (substrate, substrate-crds); the chart stamps
them. A component whose chart the mapping gives to another team
(cloudnative-pg, gpu-operator, gateway-api-crds) sets teamAnnotation: false and
gets no annotation from the chart, so team-stamper's value stands.
*/}}
{{- define "annotations.team" -}}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "labels.selector" -}}
app.kubernetes.io/name: {{ include "name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}

{{/*
The layer an OCIRepository of this chart takes from the artifact: the Helm
chart, copied as-is for the HelmRelease's chartRef (the form Flux documents).
Without a selector source-controller extracts layers[0], and a signed chart
carries a second layer, its provenance, which `helm push` orders by digest: on
roughly every other signed release the provenance comes first and the
OCIRepository fails with "requires gzip-compressed body" (cloudnative-pg 0.29.1,
giantswarm/agent-platform#649). The artifact revision stays <tag>@<manifest
digest>, so the chart version helm-controller derives from it does not change.
*/}}
{{- define "agent-platform.chartLayerSelector" -}}
layerSelector:
  mediaType: application/vnd.cncf.helm.chart.content.v1.tar+gzip
  operation: copy
{{- end -}}

{{/*
Whether a component is enabled — reads `components.<name>.enabled`, the single
on/off switch. `name` is the components.<key> name, which equals the component's
chart name and is therefore what a dependsOn entry references. A component with
no `enabled` key is force-enabled — except kagent-crds, which then follows
components.kagent. Emits "true" when on, empty string otherwise.

Used to drop a dependsOn reference to a component that is toggled off, so a
consumer does not wait forever on a HelmRelease that was never rendered. With
app-owned CRDs a CR consumer dependsOn the component that ships the CRD (e.g.
connectivity dependsOn agentgateway + kagent), but those components can be off —
kagent by default, agentgateway beside a slice — and then
render no HelmRelease, so
an unfiltered dependsOn would block the always-on consumer indefinitely. An
unknown name (not in components) is kept rather than silently dropped.
Usage: include "agent-platform.componentEnabled" (dict "root" $root "name" "agentgateway")
*/}}
{{- define "agent-platform.componentEnabled" -}}
{{- $root := .root -}}
{{- $c := index $root.Values.components .name -}}
{{- if $c -}}
{{- $on := true -}}
{{- /* An `enabled: null` is no switch: Helm keeps a null only for a key the
       chart's values do not default, the entries below that follow another. */ -}}
{{- if and (hasKey $c "enabled") (not (kindIs "invalid" $c.enabled)) }}{{- $on = $c.enabled }}
{{- else if has .name (list "kagent-crds" "substrate" "substrate-crds" "google-access-token-credential-provider") }}
{{- /* The kagent line ships its CRDs as their own chart and has no runtime
       without Agent Substrate; without an explicit switch these follow
       components.kagent, so a consumer turns on kagent and gets its CRDs, its
       runtime and the credential provider its Vertex AI actors need (an
       explicit false on the first three with kagent on is refused by
       agent-platform.validateKagentCrds / agent-platform.validateSubstrate). */ -}}
{{- $on = eq (include "agent-platform.componentEnabled" (dict "root" $root "name" "kagent")) "true" }}
{{- else if eq .name "agent-platform-mcps" }}
{{- /* The data plane's route to muster: on whenever muster is on
       (agent-platform.validateMusterRoute refuses an explicit false then). */ -}}
{{- $on = eq (include "agent-platform.componentEnabled" (dict "root" $root "name" "muster")) "true" }}
{{- else if eq .name "skill-manager" }}
{{- /* The skill-manager serves agent-manager's skills: on with it, unless
       its own switch says otherwise. */ -}}
{{- $on = eq (include "agent-platform.componentEnabled" (dict "root" $root "name" "agent-manager")) "true" }}
{{- else if eq .name "workspace-manager" }}
{{- /* The workspace-manager follows the one switch workspaces.enabled
       (agent-platform.validateWorkspaces refuses an explicit value that
       disagrees with it). */ -}}
{{- $on = ($root.Values.workspaces | default dict).enabled | default false }}
{{- else if eq .name "agent-platform-operator" }}
{{- /* The operator follows the one switch agentPlatformOrganizations.enabled
       (agent-platform.validateOrganizations refuses an explicit value that
       disagrees with it). */ -}}
{{- $on = ($root.Values.agentPlatformOrganizations | default dict).enabled | default false }}
{{- end }}
{{- if and $on (eq .name "default-agent") }}
{{- /* An agent: only where kagent runs it, muster serves its tools and
       agent-manager, whose tools it calls, is on. */ -}}
{{- $on = and (eq (include "agent-platform.componentEnabled" (dict "root" $root "name" "kagent")) "true") (eq (include "agent-platform.componentEnabled" (dict "root" $root "name" "muster")) "true") (eq (include "agent-platform.componentEnabled" (dict "root" $root "name" "agent-manager")) "true") }}
{{- end }}
{{- if $on }}true{{- end -}}
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
The tenant identity of the agents' Flux HelmReleases: kagent.fluxServiceAccountName
while the kagent component is on, "" otherwise. The connectivity chart renders
the ServiceAccount and its RoleBinding from the same value (a helper of the same
name there) and exports it to the portal's app-config; this copy derives
agent-manager's flux.helmReleaseServiceAccount (componentDerivedValues), so the
three consumers cannot disagree.
Usage: include "agent-platform.kagent.fluxServiceAccountName" .
*/}}
{{- define "agent-platform.kagent.fluxServiceAccountName" -}}
{{- if (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) -}}
{{- dig "fluxServiceAccountName" "" (.Values.kagent | default dict) -}}
{{- end -}}
{{- end -}}

{{/*
The credential providers' namespacePolicies, as JSON {"policies": [...]}: the
installation's own substrate.credentialProvider.namespacePolicies and, with
agentPlatformOrganizations.enabled, the organizations' agents (giantswarm/agent-platform#1041): each namespace
labelled agent-platform.orgNamespaces.label is read by the atespace of its own name only (an
ownNamespaceSelector entry), and ate-golden, where every template's golden
actor boots, reads them all (allowedNamespaceSelector on its entry, so that
entry's secretSelector narrows it there too). Each derived entry once; an
ate-golden entry that selects other namespaces fails. Substrate's bundled
provider and the Google access-token plugin get the same list.
Usage: (include "agent-platform.credentialProvider.namespacePolicies" $root | fromJson).policies
*/}}
{{- define "agent-platform.credentialProvider.namespacePolicies" -}}
{{- $own := dig "credentialProvider" "namespacePolicies" list (.Values.substrate | default dict) -}}
{{- if not (include "agent-platform.organizations.on" .) -}}
{{- toJson (dict "policies" $own) -}}
{{- else -}}
{{- $sel := dict "matchExpressions" (list (dict "key" (include "agent-platform.orgNamespaces.label" .) "operator" "Exists")) -}}
{{- $policies := list -}}
{{- $golden := false -}}
{{- $ownSel := false -}}
{{- range $i, $p := $own -}}
{{- if eq (toJson ($p.ownNamespaceSelector | default dict)) (toJson $sel) -}}{{- $ownSel = true -}}{{- end -}}
{{- if eq ($p.atespace | default "") "ate-golden" -}}
{{- if and $p.allowedNamespaceSelector (ne (toJson $p.allowedNamespaceSelector) (toJson $sel)) -}}
{{- fail (printf "substrate.credentialProvider.namespacePolicies[%d] (ate-golden) has an allowedNamespaceSelector (%s) other than the organizations' namespaces (%s), which %s sets on it: leave it unset" $i (toJson $p.allowedNamespaceSelector) (toJson $sel) "agentPlatformOrganizations.enabled") -}}
{{- end -}}
{{- $p = merge (dict "allowedNamespaceSelector" $sel) $p -}}
{{- $golden = true -}}
{{- end -}}
{{- $policies = append $policies $p -}}
{{- end -}}
{{- if not $golden -}}{{- $policies = append $policies (dict "atespace" "ate-golden" "allowedNamespaceSelector" $sel) -}}{{- end -}}
{{- if not $ownSel -}}{{- $policies = append $policies (dict "ownNamespaceSelector" $sel) -}}{{- end -}}
{{- toJson (dict "policies" $policies) -}}
{{- end -}}
{{- end -}}

{{/*
=== Secret readers where bound (giantswarm/agent-platform#1269) ===

Substrate's credential provider and the Google access-token plugin each read
the Secret an actor's credential names, after checking the actor's grant in
their own process. From Substrate 1.18.0 (credentialProvider.rbac.namespaces)
and the plugin 0.3.0 (rbac.namespaces) their Secret reader ClusterRole is
bound by RoleBinding in listed namespaces only, not cluster-wide: on a
management cluster every workload cluster's admin kubeconfig is a Secret.
This chart lists the namespaces the grants name (allowedNamespaces of every
namespacePolicies entry, the platform namespace among them), and with
agentPlatformOrganizations.enabled agent-platform-operator binds both readers
in every organization namespace (its serviceAccountBindings).
*/}}

{{/* The first agent-platform-operator release that keeps serviceAccountBindings (giantswarm/agent-platform-operator#23). */}}
{{- define "agent-platform.operator.serviceAccountBindingsFloor" -}}0.1.0-rc.13{{- end -}}

{{/*
The Secret readers the operator binds in every organization namespace, as a
JSON list of {clusterRole, serviceAccount: {namespace, name}}: Substrate's
bundled provider (release substrate, so its names are bare) and, while its
component is on, the Google access-token plugin. Empty while the
organizations are off or the operator's floor predates serviceAccountBindings.
The connectivity chart's admission policy names the same pairs
(agent-platform.organizations.secretReaders there).
Usage: include "agent-platform.operator.serviceAccountBindings" . | fromJsonArray
*/}}
{{- define "agent-platform.operator.serviceAccountBindings" -}}
{{- $out := list -}}
{{- $floor := include "agent-platform.semverRangeFloor" (dig "agent-platform-operator" "versionRange" "" .Values.components) -}}
{{- if and (include "agent-platform.organizations.on" .) $floor (semverCompare (printf ">=%s" (include "agent-platform.operator.serviceAccountBindingsFloor" .)) $floor) -}}
{{- $ns := dig "substrate" "targetNamespace" "ate-system" .Values.components -}}
{{- $plugin := include "agent-platform.componentEnabled" (dict "root" . "name" "google-access-token-credential-provider") -}}
{{- $pns := dig "google-access-token-credential-provider" "targetNamespace" "ate-system" .Values.components -}}
{{- /* The connectivity chart's admission policy admits the operator's binding
of a provider's ServiceAccount of ate-system only: another namespace binds
nothing, and the readers stay cluster-wide. */ -}}
{{- if and (eq $ns "ate-system") (or (not $plugin) (eq $pns "ate-system")) -}}
{{- $out = append $out (dict "clusterRole" "k8s-credential-provider-secret-reader" "serviceAccount" (dict "namespace" $ns "name" "k8s-credential-provider")) -}}
{{- if $plugin -}}
{{- $out = append $out (dict "clusterRole" "google-access-token-credential-provider-secret-reader" "serviceAccount" (dict "namespace" $pns "name" "google-access-token-credential-provider")) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
The namespaces the credential providers' Secret readers are bound in by their
own releases, as JSON {"namespaces": [...]}, or {} to leave them bound
cluster-wide: every allowedNamespaces entry of the namespacePolicies this
chart derives (agent-platform.credentialProvider.namespacePolicies), each
once. A grant by namespace label can be bound only by whoever creates the
namespace: the organizations' label is (the operator binds both readers in
every organization namespace), so with the organizations on the operator must
keep serviceAccountBindings; a policy that selects other labelled namespaces
leaves the readers cluster-wide.
Usage: (include "agent-platform.credentialProvider.readerNamespaces" $root | fromJson).namespaces
*/}}
{{- define "agent-platform.credentialProvider.readerNamespaces" -}}
{{- $sel := dict "matchExpressions" (list (dict "key" (include "agent-platform.orgNamespaces.label" .) "operator" "Exists")) -}}
{{- $orgs := include "agent-platform.organizations.on" . -}}
{{- $bound := true -}}
{{- $namespaces := list -}}
{{- range (include "agent-platform.credentialProvider.namespacePolicies" . | fromJson).policies -}}
{{- range list .ownNamespaceSelector .allowedNamespaceSelector -}}
{{- if and . (not (and $orgs (eq (toJson .) (toJson $sel)))) -}}{{- $bound = false -}}{{- end -}}
{{- end -}}
{{- range (.allowedNamespaces | default list) -}}
{{- /* An organization namespace is the operator's to bind: a release's
binding there of the same name would be refused by its subject lock. */ -}}
{{- if and (not (has . $namespaces)) (not (and $orgs (hasPrefix "agents-" .))) -}}{{- $namespaces = append $namespaces . -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- if and $orgs (not (include "agent-platform.operator.serviceAccountBindings" . | fromJsonArray)) -}}{{- $bound = false -}}{{- end -}}
{{- if and $bound $namespaces -}}
{{- dict "namespaces" $namespaces | toJson -}}
{{- else -}}
{{- dict | toJson -}}
{{- end -}}
{{- end -}}

{{/*
Values this chart derives for a component from a block another component owns,
merged OVER the component's forwarded values (templates/components.yaml) so one
value drives every consumer. Emits a JSON object; {} for a component with
nothing derived. A value the component's own block sets must agree with the
derived one, otherwise the render fails naming the single key to set — a silent
overwrite would hide a values file that still spells the old key.
  muster: muster.extraCaFile.secret from global.identity.ca (secretName, key
    default ca.crt) while muster names no CA Secret of its own — the issuer's
    private CA its OAuth server verifies the provider against. And
    rbac.mcpServerEditor.subjects and rbac.workflowEditor.subjects: the
    block's own subjects with tenants.platformTeam appended (each subject
    once), while that list is not empty. And toolsetPresets.<name>.icon for
    the shipped presets left without one (agent-platform.muster.presetIcons),
    from the muster floor that takes the key.
  agent-manager: flux.helmReleaseServiceAccount from kagent.fluxServiceAccountName;
                 tenants.enabled from agentPlatformOrganizations.enabled
                 (agent-platform.agentManager.organizations);
                 muster.url from the muster Service (agent-platform.musterMcpUrl);
                 kagent.controllerTarget, the kagent controller its session
                 tools call, from the agentgateway data plane
                 (agent-platform.kagentControllerTarget). Empty while the
                 controller route is off, which turns the session tools off
                 over the chart's own default.
  klaus-gateway: with klausGateway.routing.store: valkey, the platform's own
    Valkey fills in what the routing.valkey block leaves unset — url from the
    valkey release's Service (agent-platform.valkeyAddress), existingSecret and
    passwordKey from the Secret and key the valkey release authenticates its
    default user with (agent-platform.valkeySecretName / valkeyPasswordKey), so
    the switch is one line. These are defaults, not the single-source rule
    above: an operator's own url (an out-of-band Valkey), Secret or key wins.
    And workspaces.toolsPrefix while workspaces are on: x_ and
    workspace-manager.muster.mcpServer.name and _ (x_workspace-manager_), the
    name muster gives the manager's tools, which the gateway calls as the
    person; only from the floor agent-platform.klausGateway.workspacesFloor
    (4.3.0) of components.klaus-gateway.versionRange, below it nothing. Single
    source: an own value that differs fails the render. And
    reviews.allowedCallers while the toolchain-manager posts its notices and
    asks there (agent-platform.toolchainManager.reviews): the block's own list,
    else the klaus-gateway chart's default, with the toolchain-manager's
    ServiceAccount added.
  valkey:auth.usersExistingSecret and auth.aclUsers.default.passwordKey, when
    its own block leaves them empty, from the Secret and key muster reads the
    same password with (agent-platform.valkeySecretName / valkeyPasswordKey:
    muster's storage Secret, else global.identity.existingSecret; the key
    valkey-password), so the platform Secret alone authenticates both. Defaults
    as for klaus-gateway: the valkey block's own values win.
  kagent: harness.snapshotLocation from kagent.harness.snapshotStore while the
    store block renders the bucket (agent-platform.kagent.snapshotLocation);
    substrateWorkerPool.workerImage from the Substrate release THIS chart pins
    (agent-platform.substrate.workerImage: the substrate block's image.registry
    and image.repository, ateom-gvisor, the floor of components.substrate.versionRange) — never the
    worker the kagent build was published against, so the worker and the
    atelet are one Substrate release whatever kagent build the range admits
    (giantswarm/agent-platform#466); the workers run the release the control
    plane runs, which the substrate release's followRelease sets
    (giantswarm/agent-platform#822). An installation's own workerImage stands
    only while its tag is that release (a mirror by another path). And
    substrateWorkerPool.template.podAffinity, the worker pods' preferred
    affinity to the atelet on their node, from the Substrate release that
    carries the field on (agent-platform.substrate.workerPoolAteletAffinity,
    giantswarm/agent-platform#756); an installation's own podAffinity stands
    instead. And controller.session.admission.jwt, the jwt Session admission a
    Session with a workspace passes, while workspaces are on and the
    workspace-manager signs grants (agent-platform.kagent.sessionAdmission):
    jwksURL the manager's key set through its Service, issuer its base URL,
    audience its grant.audience — defaults as for klaus-gateway, the kagent
    block's own value stands per key; the kagent floor that takes the block,
    an issuer and the email claim are guarded (agent-platform.validateSessionAdmission).
  skill-manager: sources, the platform's skill source and skillManager.sources
    (agent-platform.skills.repositories; an own list fails); agent-manager
    skillManager.url (agent-platform.skillManager.url) in place of
    skills.repositories, from agent-platform.agentManager.skillManagerFloor
    (agent-platform.agentManager.viaSkillManager); the connectivity release
    its MCP backend entry, networkPolicy.mcpBackends.skill-manager
    (agent-platform.skillManager.mcpBackend), while the component is on.
  toolchain-manager: the login, the muster registration and its pin to the
    installation's agents GitHub App, and the sources with additionalSources
    after them, klausGateway.url and .audience while klaus-gateway takes its
    notices and asks (agent-platform.toolchainManager.derived); the connectivity
    release its MCP backend entry, networkPolicy.mcpBackends.toolchain-manager
    (agent-platform.toolchainManager.mcpBackend), and agent-manager
    muster.toolchainsToolsPrefix, x_<its MCPServer name>_ (from agent-manager
    agent-platform.agentManager.toolchainsFloor; an own value must agree),
    while the component is on. Then the toolchain sources' registries and
    toolchain-manager.registryPullSecret (agent-platform.toolchains.registries)
    on the other side of a toolchain: agent-manager toolchains.repository (the
    first source's registry, an own value stands) and
    toolchains.registryConfig.secretName (an own value must agree), and
    substrate atelet.imagePullSecrets (after the installation's own entries),
    each from the floor of that component's line that takes the key; kagent's
    controller.sessionToolImageRepositories comes from
    agent-platform.kagent.sessionToolImages.
  model-manager: kagent.disableWiring: true while components.kagent is off —
    on by default with no backend (giantswarm/agent-platform#329), the release
    must not wire ModelConfigs into a kagent the installation does not run;
    with kagent on the block's own value stands. Likewise muster.mcpServer.enabled:
    false while components.muster is off — the MCPServer CRD ships with muster,
    so the MCP surface follows it (the connectivity chart's muster peer policy
    reads the same toggle); the REST API stays. And oauth.enabled: false while
    muster's OAuth server is off (muster.muster.oauth.server.enabled, the
    platform's one login): a platform without a login has no issuer for a
    resource server to trust — the lab shape of examples/kind-lab-dex.yaml —
    the way the muster discovery label derives from the same toggle. The
    managers' login itself (oauth.dex.issuerURL, clientID, existingSecret,
    trustedAudiences, baseURL) is not derived here but on the shaped values
    (agent-platform.identity.apply), so the connectivity release guards and
    wires the same block.
  substrate: atelet.serviceAccount.annotations and
    ateApiServer.serviceAccount.annotations gain eks.amazonaws.com/role-arn,
    the IRSA role the store block renders, while it does (a differing explicit
    role fails the render); atelet.extraEnv and ateApiServer.extraEnv gain the
    S3 environment of the s3proxy façade (capz, or the façade alone) next to
    an installation's own entries (one of the derived names fails the render);
    postgres.connectionStringSecretRef, on the platform Cluster —
    the derived CNPG connection Secret <postgres.clusterName>-<key>-app
    (key uri) the connectivity release's hook writes into ate-system for the
    postgres.databases entry postgres.substrateDatabase names
    (agent-platform.substrate.postgresMode; the
    `auto` of substrate.postgres.enabled itself is resolved by
    agent-platform.shape.apply, with the other cluster-shape knobs), and
    postgres.readWriteRole and postgres.ownerRole, both the role that Secret
    logs in as (postgres.applicationDatabase.owner): ate-api-server runs
    SET ROLE on every connection, and the chart's default `postgres` is a
    role the Cluster's application role is not a member of (a differing
    explicit role fails the render). With agentPlatformOrganizations.enabled,
    credentialProvider.namespacePolicies: the installation's own policies,
    the ate-golden entry with allowedNamespaceSelector on the label
    agent-platform.giantswarm.io/organization (an entry added when none names ate-golden; a
    different selector there fails the render), and an ownNamespaceSelector
    entry on the same label, each derived entry once; a Substrate floor below
    1.12.0 fails the render. Always ateController.gvisorWorker.followRelease:
    true, so ate-controller runs every gVisor pool on its own release's
    ateom-gvisor and the workers follow the release Flux resolves, patches
    included (giantswarm/agent-platform#822; an own false fails the render). Its
    atelet.imageCache.pinnedImages is NOT derived here: the kagent release's
    ConfigMap kagent-images feeds it through the HelmRelease's valuesFrom
    (components.substrate.valuesFromRefs), so no copy of a digest lives here.
Usage: include "agent-platform.componentDerivedValues" (dict "root" $root "name" $key) | fromJson
*/}}
{{- define "agent-platform.componentDerivedValues" -}}
{{- $derived := dict -}}
{{- if eq .name "mcp-kubernetes" -}}
{{- $oauth := dig "mcpKubernetes" "oauth" dict (index .root.Values "mcp-kubernetes" | default dict) -}}
{{- if $oauth.enabled -}}
{{- $oauthDerived := dict -}}
{{- $kubernetes := index .root.Values "mcp-kubernetes" -}}
{{- $gateway := $kubernetes.gatewayAPI | default dict -}}
{{- if not (hasKey $gateway "enabled") -}}
{{- $baseURL := $oauth.baseURL | default (printf "https://%s.%s" ($kubernetes.fullnameOverride | default "mcp-kubernetes") .root.Values.global.domain) -}}
{{- $hostname := regexReplaceAll ":[0-9]+$" (urlParse $baseURL).host "" -}}
{{- $parents := .root.Values.ingress.parentRefs | default .root.Values.global.gatewayApi.parentRefs -}}
{{- if and (not .root.Values.ingress.parentRefs) .root.Values.gatewayApi.gateway.create -}}
{{- $parents = list (dict "name" .root.Values.gateway.name "namespace" .root.Release.Namespace "group" "gateway.networking.k8s.io" "kind" "Gateway" "sectionName" "https") -}}
{{- end -}}
{{- $_ := set $derived "gatewayAPI" (dict "enabled" true "httpRoute" (dict "parentRefs" $parents "hostnames" (list $hostname))) -}}
{{- end -}}
{{- if and .root.Values.gatewayApi.gateway.create (dig "gatewayAPI" "enabled" true $kubernetes) -}}
{{- $peers := dig "ciliumNetworkPolicy" "ingress" "gatewayPeers" list $kubernetes -}}
{{- $namespace := dig "agent-platform-connectivity" "targetNamespace" "" .root.Values.components | default (include "agent-platform.targetNamespace" .root) -}}
{{- $peer := dict "namespace" $namespace "matchLabels" (dict "gateway.networking.k8s.io/gateway-name" .root.Values.gateway.name) -}}
{{- if not (has $peer $peers) -}}{{- $peers = append $peers $peer -}}{{- end -}}
{{- $_ := set $derived "ciliumNetworkPolicy" (dict "ingress" (dict "gatewayPeers" $peers)) -}}
{{- end -}}
{{- $audience := $kubernetes.kubernetesAudience | default "" -}}
{{- if and $audience (eq ($oauth.provider | default "dex") "dex") (not (dig "dex" "kubernetesAuthenticatorClientID" "" $oauth)) -}}
{{- $_ := set $oauthDerived "dex" (dict "kubernetesAuthenticatorClientID" $audience) -}}
{{- end -}}
{{- $storage := $oauth.storage | default dict -}}
{{- $type := $storage.type | default "valkey" -}}
{{- if eq $type "valkey" -}}
{{- $own := $storage.valkey | default dict -}}
{{- $valkey := dict "keyPrefix" (printf "%s:mcp-kubernetes:" .root.Release.Namespace) -}}
{{- range $key, $value := dict "url" (include "agent-platform.valkeyAddress" .root) "existingSecret" (include "agent-platform.valkeySecretName" .root) "secretKeyPassword" (include "agent-platform.valkeyPasswordKey" .root) -}}
{{- if not (get $own $key) -}}{{- $_ := set $valkey $key $value -}}{{- end -}}
{{- end -}}
{{- if $own.keyPrefix -}}{{- $_ := set $valkey "keyPrefix" $own.keyPrefix -}}{{- end -}}
{{- if and (not $own.url) (ne (include "agent-platform.componentEnabled" (dict "root" .root "name" "valkey")) "true") -}}
{{- fail "mcp-kubernetes OAuth needs shared storage: enable the platform Valkey or set mcp-kubernetes.mcpKubernetes.oauth.storage.valkey.url" -}}
{{- end -}}
{{- $_ := set $oauthDerived "encryptionKey" true -}}
{{- $_ := set $oauthDerived "storage" (dict "type" "valkey" "valkey" $valkey) -}}
{{- end -}}
{{- if $oauthDerived -}}{{- $_ := set $derived "mcpKubernetes" (dict "oauth" $oauthDerived) -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- if eq .name "google-access-token-credential-provider" -}}
{{- /* The plugin resolves keys under the same atespace-to-namespace grants as
Substrate's bundled provider: one list, Substrate's, with the entries the
Organizations derive. The Substrate release's name and namespace tell the
plugin which egress gateway may call it. */ -}}
{{- $grants := dig "credentialProvider" "namespacePolicies" list (.root.Values.substrate | default dict) -}}
{{- $own := dig "namespacePolicies" list (index .root.Values "google-access-token-credential-provider" | default dict) -}}
{{- if and $own (ne (toJson $own) (toJson $grants)) -}}
{{- fail (printf "google-access-token-credential-provider.namespacePolicies (%s) differs from substrate.credentialProvider.namespacePolicies (%s): an atespace resolves Google service account keys under the grants it resolves every other Secret under — set substrate.credentialProvider.namespacePolicies and leave google-access-token-credential-provider.namespacePolicies unset" (toJson $own) (toJson $grants)) -}}
{{- end -}}
{{- $_ := set $derived "namespacePolicies" (include "agent-platform.credentialProvider.namespacePolicies" .root | fromJson).policies -}}
{{- $_ := set $derived "substrate" (dict "releaseName" "substrate" "namespace" (dig "substrate" "targetNamespace" "ate-system" .root.Values.components)) -}}
{{- /* From 0.3.0 the plugin's Secret reader is bound where the grants
point (agent-platform.credentialProvider.readerNamespaces); an older plugin's
schema refuses the key. An installation's own rbac.namespaces stays. */ -}}
{{- $ownRbac := dig "rbac" "namespaces" list (index .root.Values "google-access-token-credential-provider" | default dict) -}}
{{- $readers := (include "agent-platform.credentialProvider.readerNamespaces" .root | fromJson).namespaces -}}
{{- if and (not $ownRbac) $readers (include "agent-platform.componentFloorAtLeast" (dict "root" .root "name" "google-access-token-credential-provider" "version" "0.3.0")) -}}
{{- $_ := set $derived "rbac" (dict "namespaces" $readers) -}}
{{- end -}}
{{- end -}}
{{- if eq .name "agent-manager" -}}
{{- $sa := include "agent-platform.kagent.fluxServiceAccountName" .root -}}
{{- $own := dig "flux" "helmReleaseServiceAccount" "" (index .root.Values "agent-manager" | default dict) -}}
{{- if and $own (ne $own $sa) -}}
{{- fail (printf "agent-manager.flux.helmReleaseServiceAccount (%s) differs from kagent.fluxServiceAccountName (%s): the agents' HelmReleases have one tenant identity — set kagent.fluxServiceAccountName and leave agent-manager.flux.helmReleaseServiceAccount unset" $own $sa) -}}
{{- end -}}
{{- $_ := set $derived "flux" (dict "helmReleaseServiceAccount" $sa) -}}
{{- $url := include "agent-platform.musterMcpUrl" .root -}}
{{- $ownUrl := dig "muster" "url" "" (index .root.Values "agent-manager" | default dict) -}}
{{- if and $ownUrl (ne $ownUrl $url) -}}
{{- fail (printf "agent-manager.muster.url (%s) differs from the platform's muster MCP URL (%s): agent-manager composes every agent's RemoteMCPServer against the muster this chart installs — the URL follows muster.fullnameOverride and muster.service.port; leave agent-manager.muster.url unset" $ownUrl $url) -}}
{{- end -}}
{{- $musterValues := dict "url" $url -}}
{{- /* muster trusts a bound Session's actor JWT: every Session start_session
binds carries the agent's toolset, and agent-manager reports it as bound to
each session at its start (agent-manager 2.9.0, giantswarm/agent-manager#228). */ -}}
{{- $bearer := (include "agent-platform.muster.credentialProvider" .root | fromJson).actorBearer | default dict -}}
{{- $ownBearer := dig "muster" "actorBearer" nil (index .root.Values "agent-manager" | default dict) -}}
{{- if and (not (kindIs "invalid" $ownBearer)) (ne (toString $ownBearer) (toString (and $bearer.enabled true))) -}}
{{- fail (printf "agent-manager.muster.actorBearer (%v) differs from whether muster trusts the actor JWT (%v, muster.muster.credentialProvider.actorBearer.enabled, on with Substrate): agent-manager reports an agent's toolset as bound only where muster binds it; leave agent-manager.muster.actorBearer unset" $ownBearer (and $bearer.enabled true)) -}}
{{- end -}}
{{- if $bearer.enabled -}}
{{- include "agent-platform.validateToolsetBinding" .root -}}
{{- $_ := set $musterValues "actorBearer" true -}}
{{- end -}}
{{- /* The toolchain-manager's tools by the name muster gives them, while the
component is on: x_<its MCPServer name>_, whose list_toolchains start_session
asks as the caller. Only while the floor of components.agent-manager.versionRange
takes the key (agent-platform.agentManager.toolchainsFloor). */ -}}
{{- if include "agent-platform.componentEnabled" (dict "root" .root "name" "toolchain-manager") -}}
{{- $amFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig "agent-manager" "versionRange" "" .root.Values.components) | default "0.0.0") "" -}}
{{- if ge ((semver $amFloor).Compare (semver (include "agent-platform.agentManager.toolchainsFloor" .root))) 0 -}}
{{- $prefix := printf "x_%s_" (dig "muster" "mcpServer" "name" "toolchain-manager" (index .root.Values "toolchain-manager" | default dict)) -}}
{{- $ownPrefix := dig "muster" "toolchainsToolsPrefix" "" (index .root.Values "agent-manager" | default dict) -}}
{{- if and $ownPrefix (ne $ownPrefix $prefix) -}}
{{- fail (printf "agent-manager.muster.toolchainsToolsPrefix (%s) differs from the prefix muster gives the toolchain-manager's tools (%s, x_ and toolchain-manager.muster.mcpServer.name): start_session calls list_toolchains by that name — leave agent-manager.muster.toolchainsToolsPrefix unset" $ownPrefix $prefix) -}}
{{- end -}}
{{- $_ := set $musterValues "toolchainsToolsPrefix" $prefix -}}
{{- end -}}
{{- end -}}
{{- $_ := set $derived "muster" $musterValues -}}
{{- /* The installation's toolchains, while the toolchain-manager is on:
toolchains.repository the first source's registry (an own value stands), and
toolchains.registryConfig.secretName toolchain-manager.registryPullSecret, the
credentials a private source's images are read with, from the agent-manager
floor that takes the key (agent-platform.agentManager.registryConfigFloor). */ -}}
{{- with (include "agent-platform.toolchains.registries" .root | fromJson) -}}
{{- $ownTc := dig "toolchains" dict (index $.root.Values "agent-manager" | default dict) | default dict -}}
{{- $tc := dict -}}
{{- if and .registries (not $ownTc.repository) -}}
{{- $_ := set $tc "repository" (first .registries) -}}
{{- end -}}
{{- if and .pullSecret (include "agent-platform.componentFloorAtLeast" (dict "root" $.root "name" "agent-manager" "version" (include "agent-platform.agentManager.registryConfigFloor" $.root))) -}}
{{- $ownSecret := dig "registryConfig" "secretName" "" $ownTc -}}
{{- if and $ownSecret (ne $ownSecret .pullSecret) -}}
{{- fail (printf "agent-manager.toolchains.registryConfig.secretName (%s) differs from toolchain-manager.registryPullSecret (%s): agent-manager reads a toolchain with the credentials Substrate's atelet pulls it with — set toolchain-manager.registryPullSecret and leave agent-manager.toolchains.registryConfig.secretName unset" $ownSecret .pullSecret) -}}
{{- end -}}
{{- $_ := set $tc "registryConfig" (dict "secretName" .pullSecret) -}}
{{- end -}}
{{- with $tc -}}{{- $_ := set $derived "toolchains" . -}}{{- end -}}
{{- end -}}
{{- $target := include "agent-platform.kagentControllerTarget" .root -}}
{{- $ownTarget := dig "kagent" "controllerTarget" "" (index .root.Values "agent-manager" | default dict) -}}
{{- if and $ownTarget (ne $ownTarget $target) -}}
{{- fail (printf "agent-manager.kagent.controllerTarget (%s) differs from the platform's kagent controller target (%q): agent-manager's session tools reach the controller through the agentgateway data plane this chart installs, on kagent.controllerRoute; the target follows gateway.name and gateway.listeners[0].port; leave agent-manager.kagent.controllerTarget unset" $ownTarget $target) -}}
{{- end -}}
{{- $_ := set $derived "kagent" (dict "controllerTarget" $target) -}}
{{- $orgs := include "agent-platform.agentManager.organizations" .root | fromJson -}}
{{- $_ := set $derived "tenants" $orgs.tenants -}}
{{- /* Skills: through the skill-manager (skillManager.url) where it pins
them (agent-platform.agentManager.viaSkillManager), else the deprecated
in-process list of URLs (agent-platform.skills.repositories). */ -}}
{{- if include "agent-platform.agentManager.viaSkillManager" .root -}}
{{- with dig "skills" "repositories" list (index .root.Values "agent-manager" | default dict) -}}
{{- fail (printf "agent-manager.skills.repositories (%v) is set, but agent-manager takes its skill sources from the skill-manager (components.skill-manager): move the list to skillManager.sources" .) -}}
{{- end -}}
{{- $_ := set $derived "skillManager" (dict "url" (include "agent-platform.skillManager.url" .root)) -}}
{{- else -}}
{{- $_ := set $derived "skills" (dict "repositories" (include "agent-platform.skills.repositories" (dict "root" .root "consumer" "agent-manager") | fromJson).list) -}}
{{- end -}}
{{- /* The installation's name in the portal (agent ids are
<installation>/<namespace>/<name>), which get_info reports: from the release
that takes the key (agent-platform.agentManager.skillManagerFloor). */ -}}
{{- if include "agent-platform.componentFloorAtLeast" (dict "root" .root "name" "agent-manager" "version" (include "agent-platform.agentManager.skillManagerFloor" .root)) -}}
{{- $_ := set $derived "installation" (include "agent-platform.portalInstallationName" .root) -}}
{{- /* The default agent gets the installation's default model once, while
its modelConfig.name is empty (agent-platform.defaultAgent.derived):
agent-manager sets it, from the same release. */ -}}
{{- if include "agent-platform.componentEnabled" (dict "root" .root "name" "default-agent") -}}
{{- $_ := set $derived "defaultAgentModel" (dict "agent" "default-agent") -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if eq .name "default-agent" -}}
{{- $derived = include "agent-platform.defaultAgent.derived" .root | fromJson -}}
{{- end -}}
{{- if eq .name "agent-platform-connectivity" -}}
{{- /* Helm coalescing removes a defaulted key overridden with null. Forward
PostgreSQL's explicit unlimited sentinel so connectivity's own 4GB default
cannot silently reinstate a cap on the second render. */ -}}
{{- if not (hasKey (.root.Values.postgres | default dict) "maxSlotWalKeepSize") -}}
{{- $_ := set $derived "postgres" (dict "maxSlotWalKeepSize" "-1") -}}
{{- end -}}
{{- /* The namespace the workspace-manager release installs into, when it is
not the connectivity release's own: the connectivity release binds the
manager's ServiceAccount there (workspace-manager/kagent-sessions-rbac.yaml). */ -}}
{{- if and (dig "enabled" false (.root.Values.workspaces | default dict)) (include "agent-platform.componentEnabled" (dict "root" .root "name" "workspace-manager")) -}}
{{- $wmNs := dig "workspace-manager" "targetNamespace" "" .root.Values.components | default (include "agent-platform.targetNamespace" .root) -}}
{{- $connNs := dig "agent-platform-connectivity" "targetNamespace" "" .root.Values.components | default (include "agent-platform.targetNamespace" .root) -}}
{{- if ne $wmNs $connNs -}}
{{- $_ := set $derived "workspaceManager" (dict "namespace" $wmNs) -}}
{{- end -}}
{{- end -}}
{{- /* muster alone reaches the toolchain-manager's pods, while the component
is on: an MCP backend entry, whose ingress policy the connectivity chart
renders (networkPolicy.mcpBackends). */ -}}
{{- $mcpBackends := dict -}}
{{- with (include "agent-platform.toolchainManager.mcpBackend" .root | fromJson) -}}
{{- $_ := set $mcpBackends "toolchain-manager" . -}}
{{- end -}}
{{- /* And the skill-manager's, which agent-manager calls too
(agent-platform.skillManager.mcpBackend). */ -}}
{{- with (include "agent-platform.skillManager.mcpBackend" .root | fromJson) -}}
{{- $_ := set $mcpBackends "skill-manager" . -}}
{{- end -}}
{{- with $mcpBackends -}}
{{- $_ := set $derived "networkPolicy" (dict "mcpBackends" .) -}}
{{- end -}}
{{- /* agent-manager's migrate run pins through the skill-manager too: its
URL, its namespace and the service token's Secret, which the connectivity
release generates (agent-platform.skillManager.serviceToken). */ -}}
{{- if include "agent-platform.agentManager.viaSkillManager" .root -}}
{{- $smRef := dict "url" (include "agent-platform.skillManager.url" .root) "namespace" (dig "skill-manager" "targetNamespace" "" .root.Values.components | default (include "agent-platform.targetNamespace" .root)) -}}
{{- with include "agent-platform.skillManager.serviceToken" .root -}}
{{- $_ := set $smRef "serviceTokenSecret" . -}}
{{- end -}}
{{- $_ := set $derived "agentManager" (dict "skillManager" $smRef) -}}
{{- end -}}
{{- /* The portal's skills: from the skill-manager, through muster as the
person, where it reads them there (agent-platform.backstage.viaSkillManager);
it then needs GitHub only for the skill pull requests it opens. Else the
deprecated list it discovers itself (agent-platform.skills.repositories). */ -}}
{{- if include "agent-platform.backstage.viaSkillManager" .root -}}
{{- with dig "skillsRepositories" list (.root.Values.backstage | default dict) -}}
{{- fail (printf "backstage.skillsRepositories (%v) is set, but the portal reads its skills from the skill-manager (components.skill-manager): move the list to skillManager.sources" .) -}}
{{- end -}}
{{- $_ := set $derived "backstage" (dict "skillsRepositories" list "skillPullRequests" true) -}}
{{- else -}}
{{- $_ := set $derived "backstage" (dict "skillsRepositories" (include "agent-platform.skills.repositories" (dict "root" .root "consumer" "backstage") | fromJson).list) -}}
{{- end -}}
{{- /* agent-platform-operator's names, while the organizations are on: the
connectivity chart's policies, bindings and objects for the operator read
them from here (agent-platform.organizations.operator). Off, nothing: the
connectivity release's values stay those of a chart without the operator. */ -}}
{{- if include "agent-platform.organizations.on" .root -}}
{{- $_ := set $derived "agentPlatformOrganizations" (dict "operator" (include "agent-platform.organizations.operator" .root | fromJson)) -}}
{{- end -}}
{{- end -}}
{{- if eq .name "toolchain-manager" -}}
{{- $derived = include "agent-platform.toolchainManager.derived" .root | fromJson -}}
{{- end -}}
{{- if eq .name "skill-manager" -}}
{{- /* The skill sources: the platform's first, then skillManager.sources
(agent-platform.skills.repositories). */ -}}
{{- with dig "sources" list (index .root.Values "skill-manager" | default dict) -}}
{{- fail (printf "skill-manager.sources (%v) is set: the chart derives the skill-manager's sources from skillManager.sources — move the list there" .) -}}
{{- end -}}
{{- $_ := set $derived "sources" (include "agent-platform.skills.repositories" (dict "root" .root "consumer" "skill-manager") | fromJson).list -}}
{{- /* Its callers' namespaces, which its own NetworkPolicy admits
(agent-platform.skillManager.callerNamespaces), after the block's own. */ -}}
{{- $sm := index .root.Values "skill-manager" | default dict -}}
{{- $own := dig "networkPolicy" "ingressNamespaces" list $sm -}}
{{- $_ := set $derived "networkPolicy" (dict "ingressNamespaces" (concat $own (include "agent-platform.skillManager.callerNamespaces" .root | fromJson).list | uniq)) -}}
{{- /* The platform's own bearer, agent-manager's migrate (no person), while
agent-manager pins through it and OAuth is on: the Secret the connectivity
release generates (agent-platform.skillManager.serviceToken). */ -}}
{{- with include "agent-platform.skillManager.serviceToken" .root -}}
{{- $ownToken := dig "serviceToken" "secretName" "" $sm -}}
{{- if and $ownToken (ne $ownToken .) -}}
{{- fail (printf "skill-manager.serviceToken.secretName (%s) differs from the Secret the platform generates for agent-manager's migrate (%s): leave it unset" $ownToken .) -}}
{{- end -}}
{{- $_ := set $derived "serviceToken" (dict "secretName" .) -}}
{{- end -}}
{{- end -}}
{{- if eq .name "agent-platform-operator" -}}
{{- $derived = include "agent-platform.operator.derived" .root | fromJson -}}
{{- end -}}
{{- if eq .name "cluster-manager" -}}
{{- /* model-manager's namespace: where the model-manager component lands — the
platform's own namespace (gitops.targetNamespace, else the release namespace).
create_node_pool writes the kserve backend ConfigMap of model-manager's
runtime-registration contract there. */ -}}
{{- $ns := include "agent-platform.targetNamespace" .root -}}
{{- $own := dig "modelManager" "namespace" "" (index .root.Values "cluster-manager" | default dict) -}}
{{- if and $own (ne $own $ns) -}}
{{- fail (printf "cluster-manager.modelManager.namespace (%s) differs from the platform's namespace (%s), where the model-manager component lands: cluster-manager registers a serving cluster's kserve backend through model-manager's ConfigMap there — leave cluster-manager.modelManager.namespace unset" $own $ns) -}}
{{- end -}}
{{- $_ := set $derived "modelManager" (dict "namespace" $ns) -}}
{{- end -}}
{{- if eq .name "workspace-manager" -}}
{{- /* The workspaces' namespace: kagent's, where every Session runs and its
Harness mounts the workspace volume, so each workspace object, its volume and
its sync and cleanup Jobs live there too. */ -}}
{{- $ns := include "agent-platform.kagent.namespace" .root -}}
{{- $own := dig "workspaces" "namespace" "" (index .root.Values "workspace-manager" | default dict) -}}
{{- if and $own (ne $own $ns) -}}
{{- fail (printf "workspace-manager.workspaces.namespace (%s) differs from the kagent namespace (%s), where every Session runs and mounts its workspace: leave workspace-manager.workspaces.namespace unset" $own $ns) -}}
{{- end -}}
{{- $_ := set $derived "workspaces" (dict "namespace" $ns) -}}
{{- /* The kagent controller the manager lists every Session's last turn from
for the session directories' cleanup, and the namespace its NetworkPolicy
opens the egress to: a default, so an installation that reaches kagent
elsewhere sets workspace-manager.kagent.address (and namespace, port) itself.
Only while the floor of components.workspace-manager.versionRange takes the
keys (agent-platform.workspaceManager.kagentFloor): an earlier release's closed
schema refuses a kagent block. */ -}}
{{- $ownKagent := dig "kagent" dict (index .root.Values "workspace-manager" | default dict) -}}
{{- $wmFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig "workspace-manager" "versionRange" "" .root.Values.components) | default "0.0.0") "" -}}
{{- $takesKagent := ge ((semver $wmFloor).Compare (semver (include "agent-platform.workspaceManager.kagentFloor" .root))) 0 -}}
{{- with include "agent-platform.kagent.controllerAddress" .root -}}
{{- if and $takesKagent (not $ownKagent.address) -}}
{{- if and $ownKagent.namespace (ne (toString $ownKagent.namespace) $ns) -}}
{{- fail (printf "workspace-manager.kagent.namespace (%s) differs from the kagent namespace (%s) of the controller address this chart derives (%s): leave workspace-manager.kagent.namespace unset, or set workspace-manager.kagent.address too" (toString $ownKagent.namespace) $ns .) -}}
{{- end -}}
{{- $_ := set $derived "kagent" (dict "address" . "namespace" $ns) -}}
{{- end -}}
{{- end -}}
{{- /* The workspace StorageClass, one value for every consumer:
workspaces.storage.storageClassName, the class every workspace's
PersistentVolumeClaim names. */ -}}
{{- with dig "storage" "storageClassName" "" (.root.Values.workspaces | default dict) -}}
{{- $ownClass := dig "storage" "storageClassName" "" (index $.root.Values "workspace-manager" | default dict) -}}
{{- if and $ownClass (ne $ownClass .) -}}
{{- fail (printf "workspace-manager.storage.storageClassName (%s) differs from workspaces.storage.storageClassName (%s), the class every workspace volume is claimed from: leave workspace-manager.storage.storageClassName unset" $ownClass .) -}}
{{- end -}}
{{- $_ := set $derived "storage" (dict "storageClassName" .) -}}
{{- end -}}
{{- /* A Session's directory lives as long as the Session: kagent deletes an
idle Session after kagent.controller.sessionIdleTTL and its directory goes at
once, so that TTL is sessions.cleanupAfter unless the block sets a shorter one
(a longer one would never apply). 0 never deletes a Session and derives
nothing: the manager refuses a cleanupAfter of 0. */ -}}
{{- if include "agent-platform.componentEnabled" (dict "root" .root "name" "kagent") -}}
{{- $ttl := toString (dig "controller" "sessionIdleTTL" "" (.root.Values.kagent | default dict)) -}}
{{- $ttlSeconds := include "agent-platform.durationSeconds" $ttl -}}
{{- if and $ttl (not $ttlSeconds) -}}
{{- fail (printf "kagent.controller.sessionIdleTTL (%s) is not a Go duration such as 720h" $ttl) -}}
{{- end -}}
{{- if and $ttlSeconds (gt (float64 $ttlSeconds) 0.0) -}}
{{- $own := toString (dig "sessions" "cleanupAfter" "" (index .root.Values "workspace-manager" | default dict)) -}}
{{- if not $own -}}
{{- $_ := set $derived "sessions" (dict "cleanupAfter" $ttl) -}}
{{- else if gt (float64 (include "agent-platform.durationSeconds" $own | default "0")) (float64 $ttlSeconds) -}}
{{- fail (printf "workspace-manager.sessions.cleanupAfter (%s) is longer than kagent.controller.sessionIdleTTL (%s): kagent deletes the idle Session first and its directory with it, so the cleanup never applies — leave workspace-manager.sessions.cleanupAfter unset (it follows the TTL) or raise the TTL" $own $ttl) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- /* The Organizations whose members manage workspaces, from
workspaces.organizations: the manager checks a caller's groups against them. */ -}}
{{- with (include "agent-platform.workspaces.organizations" .root | fromJson) -}}
{{- $_ := set $derived "organizations" . -}}
{{- end -}}
{{- /* The public base URL the connectivity release routes the browser's
provider sign-in on, so the manager's callback URLs are the routed ones. */ -}}
{{- with (include "agent-platform.workspaceManager.baseURL" .root) -}}
{{- $_ := set $derived "oauth" (dict "baseURL" .) -}}
{{- end -}}
{{- /* The grant signing key: the block's own Secret reference, else the one
the connectivity release creates with providers and oauth.enabled
(workspaceManager.grantKey) — none without them, which the manager refuses. */ -}}
{{- with (include "agent-platform.workspaceManager.grantSigningKey" .root | fromJson) -}}
{{- if .name -}}
{{- $_ := set $derived "grant" (dict "signingKey" (dict "name" .name "key" .key)) -}}
{{- end -}}
{{- end -}}
{{- /* muster's pin of the registration to one provider instance's App: the
instance and the Secret with the App's OAuth client, the block's own or
derived (agent-platform.workspaceManager.musterPin). */ -}}
{{- with (include "agent-platform.workspaceManager.musterPin" .root | fromJson) -}}
{{- if and .provider .secretName -}}
{{- $server := dict "clientCredentialsSecretRef" (dict "name" .secretName) -}}
{{- if .issuer -}}{{- $_ := set $server "issuer" .issuer -}}{{- end -}}
{{- $_ := set $derived "muster" (dict "mcpServer" (dict "auth" (dict "provider" .provider "authorizationServer" $server))) -}}
{{- end -}}
{{- end -}}
{{- /* Without a pin, two or more instances with sign-in: the registration
receives the grants of each instance's App, side by side
(agent-platform.workspaceManager.providerApps). */ -}}
{{- with (include "agent-platform.workspaceManager.providerApps" .root | fromJson) -}}
{{- if .derived -}}
{{- $_ := set $derived "muster" (dict "mcpServer" (dict "auth" (dict "providerApps" .names))) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if eq .name "klaus-gateway" -}}
{{- $kg := .root.Values.klausGateway | default dict -}}
{{- /* Slack's agent picker preselects the default agent, the portal's starting
point too, while it is on (components.default-agent): <kagent namespace>/default-agent.
An own klausGateway.a2a.defaultAgent wins. */ -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" .root "name" "default-agent")) (not (dig "a2a" "defaultAgent" "" $kg)) -}}
{{- $_ := set $derived "a2a" (dict "defaultAgent" (printf "%s/default-agent" (include "agent-platform.kagent.namespace" .root))) -}}
{{- end -}}
{{- if and (eq (dig "routing" "store" "" $kg) "valkey") (include "agent-platform.componentEnabled" (dict "root" .root "name" "valkey")) -}}
{{- $own := dig "routing" "valkey" dict $kg -}}
{{- $valkey := dict -}}
{{- range $k, $v := dict "url" (include "agent-platform.valkeyAddress" .root) "existingSecret" (include "agent-platform.valkeySecretName" .root) "passwordKey" (include "agent-platform.valkeyPasswordKey" .root) -}}
{{- if and $v (not (dig $k "" $own)) -}}{{- $_ := set $valkey $k $v -}}{{- end -}}
{{- end -}}
{{- if $valkey -}}{{- $_ := set $derived "routing" (dict "valkey" $valkey) -}}{{- end -}}
{{- end -}}
{{- /* The workspace-manager's tools by the name muster gives them, while
workspaces are on: x_<the manager's MCPServer name>_, which the gateway calls
as the person. Only while the floor of components.klaus-gateway.versionRange
takes the key (agent-platform.klausGateway.workspacesFloor): an earlier
release's closed schema refuses a workspaces block. */ -}}
{{- if (.root.Values.workspaces | default dict).enabled -}}
{{- $kgFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig "klaus-gateway" "versionRange" "" .root.Values.components) | default "0.0.0") "" -}}
{{- if ge ((semver $kgFloor).Compare (semver (include "agent-platform.klausGateway.workspacesFloor" .root))) 0 -}}
{{- $prefix := printf "x_%s_" (dig "muster" "mcpServer" "name" "workspace-manager" (index .root.Values "workspace-manager" | default dict)) -}}
{{- $own := dig "workspaces" "toolsPrefix" "" $kg -}}
{{- if and $own (ne $own $prefix) -}}
{{- fail (printf "klausGateway.workspaces.toolsPrefix (%s) differs from the prefix muster gives the workspace-manager's tools (%s, x_ and workspace-manager.muster.mcpServer.name): the gateway calls them by that name — leave klausGateway.workspaces.toolsPrefix unset" $own $prefix) -}}
{{- end -}}
{{- $_ := set $derived "workspaces" (dict "toolsPrefix" $prefix) -}}
{{- end -}}
{{- end -}}
{{- /* The toolchain-manager posts its outdated notices through the
team-review endpoint as its own ServiceAccount
(agent-platform.toolchainManager.reviews): the callers the block lists, else
the klaus-gateway chart's default (Helm replaces a list, so the derived one
carries it), and the manager. */ -}}
{{- with (include "agent-platform.toolchainManager.reviews" .root | fromJson) -}}
{{- $callers := dig "reviews" "allowedCallers" (list "system:serviceaccount:giantswarm-platform-manager:giantswarm-platform-manager") $kg -}}
{{- if not (has .caller $callers) -}}{{- $callers = append $callers .caller -}}{{- end -}}
{{- $_ := set $derived "reviews" (dict "allowedCallers" $callers) -}}
{{- end -}}
{{- /* The egress refusal notices, while they are on
(agent-platform.klausGateway.refusalsOn): where the Substrate egress and the
kagent controller are, and the audience of the token the controller's session
reader admits, and the block's own keys (agentURLTemplate, window, …). An own
value that differs fails the render. components.klaus-gateway.omitKeys drops
the block otherwise: a klaus-gateway before 4.11.0 refuses it. */ -}}
{{- if include "agent-platform.klausGateway.refusalsOn" .root -}}
{{- $want := dict
  "egressService" (printf "%s/atenet-egress" (dig "substrate" "targetNamespace" "ate-system" .root.Values.components))
  "kagentTarget" (include "agent-platform.kagent.controllerAddress" .root | trimPrefix "grpc://")
  "kagentAudience" (include "agent-platform.kagent.tokenAudience" .root) -}}
{{- $own := dig "refusals" dict $kg -}}
{{- range $k, $v := $want -}}
{{- if and (dig $k "" $own) (ne (toString (dig $k "" $own)) $v) -}}
{{- fail (printf "klausGateway.refusals.%s (%s) differs from what the platform runs (%s): the gateway reads the egress and asks the kagent controller where the chart installs them — leave klausGateway.refusals.%s unset" $k (toString (dig $k "" $own)) $v $k) -}}
{{- end -}}
{{- end -}}
{{- $refusals := omit $own "enabled" -}}
{{- range $k, $v := $want -}}{{- $_ := set $refusals $k $v -}}{{- end -}}
{{- $_ := set $refusals "enabled" true -}}
{{- $_ := set $derived "refusals" $refusals -}}
{{- end -}}
{{- end -}}
{{- if eq .name "valkey" -}}
{{- $auth := dig "valkey" "auth" dict (.root.Values.valkey | default dict) -}}
{{- $out := dict -}}
{{- $secret := include "agent-platform.valkeySecretName" .root -}}
{{- if and $secret (not (dig "usersExistingSecret" "" $auth)) -}}{{- $_ := set $out "usersExistingSecret" $secret -}}{{- end -}}
{{- if and $secret (not (dig "aclUsers" "default" "passwordKey" "" $auth)) -}}
{{- $_ := set $out "aclUsers" (dict "default" (dict "passwordKey" (include "agent-platform.valkeyPasswordKey" .root))) -}}
{{- end -}}
{{- if $out -}}{{- $_ := set $derived "valkey" (dict "auth" $out) -}}{{- end -}}
{{- $kubernetes := index .root.Values "mcp-kubernetes" | default dict -}}
{{- $oauth := dig "mcpKubernetes" "oauth" dict $kubernetes -}}
{{- if and (eq (include "agent-platform.componentEnabled" (dict "root" .root "name" "mcp-kubernetes")) "true") $oauth.enabled (eq (dig "storage" "type" "valkey" $oauth) "valkey") -}}
{{- $clients := dig "ciliumNetworkPolicy" "ingress" "clients" list (.root.Values.valkey | default dict) -}}
{{- $reader := dict "namespace" "" "matchLabels" (dict "app.kubernetes.io/name" "mcp-kubernetes") -}}
{{- if not (has $reader $clients) -}}{{- $clients = append $clients $reader -}}{{- end -}}
{{- $_ := set $derived "ciliumNetworkPolicy" (dict "ingress" (dict "clients" $clients)) -}}
{{- end -}}
{{- end -}}
{{- if and (eq .name "kagent") (include "agent-platform.substrateStore.mode" .root) -}}
{{- $_ := set $derived "harness" (dict "snapshotLocation" (include "agent-platform.kagent.snapshotLocation" .root)) -}}
{{- end -}}
{{- if and (eq .name "kagent") .root.Values.postgres.enabled (ne (dig "databases" "kagent-v2" "enabled" true .root.Values.postgres) false) -}}
{{- /* The kagent line's v1.11 chart reads the controller's connection string
only from the Secret database.postgres.connectionStringSecretRef names and runs
SET ROLE database.postgres.role; the 1.10 line reads urlFile. Both shapes are
derived beside the installation's own urlFile, so either line installs
(giantswarm/agent-platform#977). The Secret is the one the connectivity release
derives for postgres.databases.kagent-v2 in the kagent namespace; the role is
the one CNPG creates, postgres.applicationDatabase.owner. An own value stands. */ -}}
{{- $pg := dig "database" "postgres" dict (.root.Values.kagent | default dict) -}}
{{- $out := dict -}}
{{- if not (dig "connectionStringSecretRef" "name" "" $pg) -}}
{{- $_ := set $out "connectionStringSecretRef" (dict "name" (printf "%s-kagent-v2-app" .root.Values.postgres.clusterName) "key" "uri") -}}
{{- end -}}
{{- if not $pg.role -}}
{{- $_ := set $out "role" (.root.Values.postgres.applicationDatabase.owner | default "kagent") -}}
{{- end -}}
{{- if $out -}}
{{- $_ := set $derived "database" (dict "postgres" $out) -}}
{{- end -}}
{{- end -}}
{{- if eq .name "kagent" -}}
{{- /* The worker image follows the chart's Substrate pin, not the kagent build's
stamp (giantswarm/agent-platform#466): a 0.0.30 worker under a 0.0.27 atelet
booted no golden actor (bundles/pause became bundles/_pause) and nothing named
the skew. The derived value lands over the forwarded block's copy; an own
value stands only while its tag is the pinned release. */ -}}
{{- $pin := include "agent-platform.substrate.pinnedVersion" .root -}}
{{- $image := include "agent-platform.substrate.workerImage" .root -}}
{{- $own := dig "substrateWorkerPool" "workerImage" "" (.root.Values.kagent | default dict) -}}
{{- if $own -}}
{{- $ownTag := regexFind ":[^:/@]+(@sha256:[0-9a-f]+)?$" $own | trimPrefix ":" | splitList "@" | first -}}
{{- if ne $ownTag $pin -}}
{{- fail (printf "kagent.substrateWorkerPool.workerImage (%s) does not carry the Substrate release this chart pins (%s, the floor of components.substrate.versionRange): the worker and the atelet are one Substrate release — leave it unset (the chart derives %s; a mirror sets substrate.image.registry) or name an ateom-gvisor image tagged %s" $own $pin $image $pin) -}}
{{- end -}}
{{- else -}}
{{- $_ := set $derived "substrateWorkerPool" (dict "workerImage" $image) -}}
{{- end -}}
{{- /* Workers only where atelet runs (giantswarm/agent-platform#756); an
installation's own podAffinity stands instead. */ -}}
{{- $affinity := include "agent-platform.substrate.workerPoolAteletAffinity" .root | fromJson -}}
{{- if and $affinity (not (dig "substrateWorkerPool" "template" "podAffinity" nil (.root.Values.kagent | default dict))) -}}
{{- $pool := get $derived "substrateWorkerPool" | default dict -}}
{{- $_ := set $pool "template" (dict "podAffinity" $affinity) -}}
{{- $_ := set $derived "substrateWorkerPool" $pool -}}
{{- end -}}
{{- /* Workers above the default priority 0, so a pod making room on a full
node (atelet) evicts the ordinary workloads first (giantswarm/agent-platform#999):
the PriorityClass the connectivity chart ships (kagent.substrateWorkerPool
.priorityClass); an installation's own template.priorityClassName stands
instead. */ -}}
{{- $pc := dig "substrateWorkerPool" "priorityClass" dict (.root.Values.kagent | default dict) -}}
{{- if and $pc.enabled $pc.name (not (dig "substrateWorkerPool" "template" "priorityClassName" "" (.root.Values.kagent | default dict))) -}}
{{- $pool := get $derived "substrateWorkerPool" | default dict -}}
{{- $template := get $pool "template" | default dict -}}
{{- $_ := set $template "priorityClassName" $pc.name -}}
{{- $_ := set $pool "template" $template -}}
{{- $_ := set $derived "substrateWorkerPool" $pool -}}
{{- end -}}
{{- /* The jwt Session admission a Session with a workspace passes: the
workspace-manager's key set, issuer and audience, while workspaces are on and
the manager signs grants (agent-platform.kagent.sessionAdmission); the block's
own value stands per key. Guarded first: the kagent floor that takes the
block, an issuer, the email claim, an own block set in part. */ -}}
{{- include "agent-platform.validateSessionAdmission" .root -}}
{{- $session := dict -}}
{{- with (include "agent-platform.kagent.sessionAdmission" .root | fromJson) -}}
{{- $_ := set $session "admission" (dict "jwt" .) -}}
{{- end -}}
{{- /* The actor-JWT providers follow muster and the ChatGPT login alone, not the
admission: a Session without a workspace whose creator binds its actor
(agent-manager's start_session) lists them too. */ -}}
{{- $providers := dict -}}
{{- with (include "agent-platform.kagent.musterActorJWTProvider" $.root | fromJson) -}}
{{- $_ := set $providers "muster" . -}}
{{- end -}}
{{- /* A person's own ChatGPT login: the credential-URI provider chatgpt
(agent-platform.chatgpt.personalLogin). */ -}}
{{- with (include "agent-platform.chatgpt.personalLogin" $.root | fromJson).provider -}}
{{- $_ := set $providers "chatgpt" . -}}
{{- end -}}
{{- with $providers -}}
{{- $_ := set $session "actorJWTProviders" . -}}
{{- end -}}
{{- with $session -}}
{{- /* The credential provider a Session's provider hosts resolve through:
muster's authority, which muster answers with the person's token
(muster.credentialProvider); an own value stands. */ -}}
{{- $_ := set $session "credentialAuthority" (dig "controller" "session" "credentialAuthority" (dig "muster" "credentialProvider" "authority" "muster.giantswarm.io" ($.root.Values.muster | default dict)) ($.root.Values.kagent | default dict)) -}}
{{- $controller := get $derived "controller" | default dict -}}
{{- $_ := set $controller "session" $session -}}
{{- $_ := set $derived "controller" $controller -}}
{{- end -}}
{{- /* The authorizer's derived keys and the controller's NetworkPolicy, in
the kubernetes authorization mode (agent-platform.kagent.authorization). */ -}}
{{- with (include "agent-platform.kagent.authorization" .root | fromJson) -}}
{{- $_ := set $derived "controller" (mergeOverwrite (get $derived "controller" | default dict) .) -}}
{{- end -}}
{{- /* The controller's verification of people's tokens in the trusted-proxy
mode (agent-platform.kagent.authentication), guarded first: the kagent floor
that takes the keys. */ -}}
{{- include "agent-platform.validateKagentAuthentication" .root -}}
{{- with (include "agent-platform.kagent.authentication" .root | fromJson) -}}
{{- $_ := set $derived "controller" (mergeOverwrite (get $derived "controller" | default dict) .) -}}
{{- end -}}
{{- /* The repositories a Session's tool images may come from: the toolchain
sources' registries (agent-platform.kagent.sessionToolImages). */ -}}
{{- with (include "agent-platform.kagent.sessionToolImages" .root | fromJson) -}}
{{- $_ := set $derived "controller" (mergeOverwrite (get $derived "controller" | default dict) .controller) -}}
{{- end -}}
{{- end -}}
{{- if eq .name "muster" -}}
{{- /* The identity provider's private CA (global.identity.ca) is what muster's
OAuth server trusts for its issuer: muster.extraCaFile.secret, unless the
installation names its own. Without it a lab Dex fails muster's OIDC discovery
and muster never turns Ready (giantswarm/agent-platform#309). */ -}}
{{- $ca := dig "identity" "ca" dict (.root.Values.global | default dict) -}}
{{- if and $ca.secretName (not (dig "muster" "extraCaFile" "secret" "name" "" (.root.Values.muster | default dict))) -}}
{{- $muster := get $derived "muster" | default dict -}}
{{- $_ := set $muster "extraCaFile" (dict "secret" (dict "name" $ca.secretName "key" ($ca.key | default "ca.crt"))) -}}
{{- $_ := set $derived "muster" $muster -}}
{{- end -}}
{{- /* muster serves the organizations' MCPServers by the namespace label
(agent-platform.muster.organizations). */ -}}
{{- with (include "agent-platform.muster.organizations" .root | fromJson) -}}
{{- $muster := get $derived "muster" | default dict -}}
{{- $_ := set $derived "muster" (mergeOverwrite $muster .) -}}
{{- end -}}
{{- /* muster's credential provider (agent-platform.muster.credentialProvider):
the workspace instances it releases, or the actor bearer alone. With
workspaces on and no releasable instance agent-platform.validateWorkspaceAuth
has failed the render. */ -}}
{{- $provider := include "agent-platform.muster.credentialProvider" .root | fromJson -}}
{{- if or $provider.releasable (dig "actorBearer" "enabled" false $provider) -}}
{{- $muster := get $derived "muster" | default dict -}}
{{- $_ := set $muster "credentialProvider" $provider -}}
{{- $_ := set $derived "muster" $muster -}}
{{- end -}}
{{- /* The workspace provider instances' Apps muster keeps, own ones first
(agent-platform.workspaceManager.providerApps). */ -}}
{{- $apps := (include "agent-platform.workspaceManager.providerApps" .root | fromJson).apps | default list -}}
{{- /* A person's own ChatGPT login: the App chatgpt after them, unless the
installation keeps its own (agent-platform.chatgpt.personalLogin). */ -}}
{{- with (include "agent-platform.chatgpt.personalLogin" .root | fromJson).app -}}
{{- $app := . -}}
{{- $all := $apps | default (dig "muster" "providerApps" list ($.root.Values.muster | default dict)) -}}
{{- $named := false -}}
{{- range $all -}}{{- if eq (toString .name) $app.name -}}{{- $named = true -}}{{- end -}}{{- end -}}
{{- $apps = ternary $all (append $all $app) $named -}}
{{- end -}}
{{- with $apps -}}
{{- $muster := get $derived "muster" | default dict -}}
{{- $_ := set $muster "providerApps" . -}}
{{- $_ := set $derived "muster" $muster -}}
{{- end -}}
{{- /* The customer's platform team writes the servers and workflows of
muster's namespace beside the Giant Swarm admin groups
(giantswarm/agent-platform#706): tenants.platformTeam is appended to both
editor bindings' subjects, so an installation names its team without
repeating the admin groups. */ -}}
{{- with (.root.Values.tenants | default dict).platformTeam -}}
{{- $team := . -}}
{{- $rbac := dict -}}
{{- range $role := list "mcpServerEditor" "workflowEditor" -}}
{{- $subjects := dig "rbac" $role "subjects" list ($.root.Values.muster | default dict) -}}
{{- range $team -}}{{- if not (has . $subjects) -}}{{- $subjects = append $subjects . -}}{{- end -}}{{- end -}}
{{- $_ := set $rbac $role (dict "subjects" $subjects) -}}
{{- end -}}
{{- $_ := set $derived "rbac" $rbac -}}
{{- end -}}
{{- with (include "agent-platform.muster.presetIcons" .root | fromJson) -}}
{{- $muster := get $derived "muster" | default dict -}}
{{- $_ := set $derived "muster" (mergeOverwrite $muster (dict "toolsetPresets" .)) -}}
{{- end -}}
{{- end -}}
{{- if and (eq .name "model-manager") (not (include "agent-platform.componentEnabled" (dict "root" .root "name" "kagent"))) -}}
{{- $_ := set $derived "kagent" (dict "disableWiring" true) -}}
{{- end -}}
{{- if and (eq .name "model-manager") (not (include "agent-platform.componentEnabled" (dict "root" .root "name" "muster"))) -}}
{{- $_ := set $derived "muster" (dict "mcpServer" (dict "enabled" false)) -}}
{{- end -}}
{{- if and (eq .name "model-manager") (not (dig "muster" "oauth" "server" "enabled" true (.root.Values.muster | default dict))) -}}
{{- $_ := set $derived "oauth" (dict "enabled" false) -}}
{{- end -}}
{{- if and (eq .name "substrate") (eq (include "agent-platform.substrateStore.crossplane" .root) "aws") -}}
{{- $arn := include "agent-platform.substrateStore.awsRoleArn" .root -}}
{{- range $key := list "atelet" "ateApiServer" -}}
{{- $own := dig $key "serviceAccount" "annotations" "eks.amazonaws.com/role-arn" "" ($.root.Values.substrate | default dict) -}}
{{- if and $own (ne $own $arn) -}}
{{- fail (printf "substrate.%s.serviceAccount.annotations[eks.amazonaws.com/role-arn] (%s) differs from the IRSA role kagent.harness.snapshotStore renders (%s): the store block names the role (crossplane.aws.roleName, else the bucket name) — leave the annotation unset" $key $own $arn) -}}
{{- end -}}
{{- $_ := set $derived $key (dict "serviceAccount" (dict "annotations" (dict "eks.amazonaws.com/role-arn" $arn))) -}}
{{- end -}}
{{- end -}}
{{- if and (eq .name "substrate") (include "agent-platform.substrateStore.s3proxy" .root) -}}
{{- $env := include "agent-platform.substrateStore.s3proxyEnv" .root | fromJsonArray -}}
{{- $names := list -}}{{- range $env -}}{{- $names = append $names .name -}}{{- end -}}
{{- range $key := list "atelet" "ateApiServer" -}}
{{- $own := dig $key "extraEnv" list ($.root.Values.substrate | default dict) -}}
{{- range $own -}}
{{- if has .name $names -}}
{{- fail (printf "substrate.%s.extraEnv names %s, which kagent.harness.snapshotStore derives for the s3proxy façade (AWS_ENDPOINT_URL, AWS_REGION, AWS_S3_USE_PATH_STYLE and the key pair from the Secret substrate-s3proxy) — leave the S3 variables to the store block" $key .name) -}}
{{- end -}}
{{- end -}}
{{- $_ := set $derived $key (dict "extraEnv" (concat $own $env)) -}}
{{- end -}}
{{- end -}}
{{- if and (eq .name "substrate") (eq (include "agent-platform.substrate.postgresMode" .root) "cnpg") -}}
{{- $ref := dict "name" (include "agent-platform.substrate.databaseSecretName" .root) "key" "uri" -}}
{{- $own := dig "postgres" "connectionStringSecretRef" dict (.root.Values.substrate | default dict) -}}
{{- $ownName := dig "name" "" $own -}}
{{- $ownKey := dig "key" "" $own -}}
{{- if or (and $ownName (ne $ownName $ref.name)) (and $ownKey (ne $ownKey $ref.key)) -}}
{{- fail (printf "substrate.postgres.connectionStringSecretRef (%s/%s) differs from the Secret the connectivity release derives for postgres.databases.%s (%s/%s): leave it unset — it follows postgres.clusterName and postgres.substrateDatabase — or name an external database in substrate.postgres.readWriteConnectionString" $ownName $ownKey (include "agent-platform.substrate.databaseKey" .root) $ref.name $ref.key) -}}
{{- end -}}
{{- $role := .root.Values.postgres.applicationDatabase.owner | default "kagent" -}}
{{- range $key := list "readWriteRole" "ownerRole" -}}
{{- $ownRole := dig "postgres" $key "" ($.root.Values.substrate | default dict) -}}
{{- if and $ownRole (ne $ownRole $role) -}}
{{- fail (printf "substrate.postgres.%s (%s) differs from the role the derived DSN logs in as, postgres.applicationDatabase.owner (%s): ate-api-server runs SET ROLE on every connection and the Cluster's application role is not a member of another — leave it unset" $key $ownRole $role) -}}
{{- end -}}
{{- end -}}
{{- $_ := set $derived "postgres" (dict "connectionStringSecretRef" $ref "readWriteRole" $role "ownerRole" $role) -}}
{{- end -}}
{{- if eq .name "substrate" -}}
{{- /* The workers run the release the control plane runs
(giantswarm/agent-platform#822): ate-controller starts every gVisor pool on
its own release's ateom-gvisor, so a Substrate patch Flux resolves within the
range rolls the pool with the atelet, no chart release. Set here rather than
left to the Substrate chart's default; an own false fails the render. */ -}}
{{- if eq (toString (dig "ateController" "gvisorWorker" "followRelease" true (.root.Values.substrate | default dict))) "false" -}}
{{- fail "substrate.ateController.gvisorWorker.followRelease is false: the workers would run the WorkerPool's spec.workerImage (the floor of components.substrate.versionRange) while the atelet runs the release Flux resolves, so a Substrate patch would run a newer atelet beside an older worker — leave it unset; the chart sets it (giantswarm/agent-platform#822)" -}}
{{- end -}}
{{- $_ := set $derived "ateController" (dict "gvisorWorker" (dict "followRelease" true)) -}}
{{- /* atelet pulls a Session's tool images with
toolchain-manager.registryPullSecret, after the installation's own entries,
while the toolchain-manager is on, from the Substrate floor that takes the key
(agent-platform.substrate.ateletPullSecretsFloor). */ -}}
{{- $pullSecret := (include "agent-platform.toolchains.registries" .root | fromJson).pullSecret -}}
{{- if and $pullSecret (include "agent-platform.componentFloorAtLeast" (dict "root" .root "name" "substrate" "version" (include "agent-platform.substrate.ateletPullSecretsFloor" .root))) -}}
{{- $atelet := get $derived "atelet" | default dict -}}
{{- $own := dig "atelet" "imagePullSecrets" list (.root.Values.substrate | default dict) -}}
{{- $_ := set $atelet "imagePullSecrets" (uniq (concat $own (list (dict "name" $pullSecret)))) -}}
{{- $_ := set $derived "atelet" $atelet -}}
{{- end -}}
{{- end -}}
{{- if and (eq .name "substrate") (include "agent-platform.organizations.on" .root) -}}
{{- /* A Substrate floor below 1.12.0 fails: its provider refuses the
selectors agent-platform.credentialProvider.namespacePolicies derives. */ -}}
{{- $pin := include "agent-platform.substrate.pinnedVersion" .root -}}
{{- if semverCompare "<1.12.0-0" $pin -}}
{{- fail (printf "%s needs Substrate 1.12.0 or later, whose credential provider reads namespace policies by label: components.substrate.versionRange selects %s, whose provider refuses the policy file at start" "agentPlatformOrganizations.enabled" $pin) -}}
{{- end -}}
{{- $_ := set $derived "credentialProvider" (dict "namespacePolicies" (include "agent-platform.credentialProvider.namespacePolicies" .root | fromJson).policies) -}}
{{- end -}}
{{- if eq .name "substrate" -}}
{{- /* From 1.18.0 the credential provider's Secret reader is bound where the
grants point (agent-platform.credentialProvider.readerNamespaces); an older
chart ignores the key and keeps it cluster-wide. An installation's own
credentialProvider.rbac.namespaces stays. */ -}}
{{- $ownRbac := dig "credentialProvider" "rbac" "namespaces" list (.root.Values.substrate | default dict) -}}
{{- $readers := (include "agent-platform.credentialProvider.readerNamespaces" .root | fromJson).namespaces -}}
{{- if and (not $ownRbac) $readers (include "agent-platform.componentFloorAtLeast" (dict "root" .root "name" "substrate" "version" "1.18.0")) -}}
{{- $cp := get $derived "credentialProvider" | default dict -}}
{{- $_ := set $cp "rbac" (dict "namespaces" $readers) -}}
{{- $_ := set $derived "credentialProvider" $cp -}}
{{- end -}}
{{- end -}}
{{- if and (eq .name "kserve-llmisvc-resources") (include "agent-platform.componentEnabled" (dict "root" .root "name" "modelServing")) -}}
{{- /* The models Gateway (modelServing.modelsGateway, rendered by the
connectivity release in the platform's namespace) is the Gateway every
LLMInferenceService route attaches to: the llm-d controller reads it from the
shared inferenceservice-config ConfigMap its own release renders. */ -}}
{{- $mg := dig "modelsGateway" dict (.root.Values.modelServing | default dict) -}}
{{- if $mg.enabled -}}
{{- $gw := printf "%s/%s" (include "agent-platform.targetNamespace" .root) ($mg.name | default "models") -}}
{{- $own := dig "kserve" "controller" "gateway" "ingressGateway" "kserveGateway" "" (index .root.Values "kserve-llmisvc-resources" | default dict) -}}
{{- if and $own (ne $own $gw) -}}
{{- fail (printf "kserve-llmisvc-resources.kserve.controller.gateway.ingressGateway.kserveGateway (%s) differs from the models Gateway the connectivity release renders (%s): every LLMInferenceService route attaches to modelServing.modelsGateway — set modelServing.modelsGateway.name, or modelsGateway.enabled: false to bring a Gateway of your own, and leave the kserve-llmisvc-resources copy unset" $own $gw) -}}
{{- end -}}
{{- $_ := set $derived "kserve" (dict "controller" (dict "gateway" (dict "ingressGateway" (dict "kserveGateway" $gw)))) -}}
{{- end -}}
{{- end -}}
{{- $derived | toJson -}}
{{- end -}}

{{/*
The kagent controller's authorizer keys and NetworkPolicy the kagent release
receives in the kubernetes authorization mode
(kagent.controller.authorization.mode; giantswarm/agent-platform#706), as a
partial controller block:
- authorization.includeNamespaces: the kagent namespace, the platform tenant,
  while the block's own list is empty;
- authorization.namespaceSelector: the label of the organizations' namespaces
  (agent-platform.orgNamespaces.label); an own value that differs fails;
- authorization.serviceAccountTokenAudience, with workspaces on: the audience
  of the projected token workspace-manager calls the controller with
  (workspace-manager.kagent.tokenAudience, else kagent, that chart's default);
  an own value that differs fails the render, since the controller's
  TokenReview would refuse every call of the manager;
- networkPolicy: enabled, `from` the controller API's callers beside kagent's
  UI (the kagent chart admits it itself): the agentgateway data plane
  (gateway.name, in the connectivity release's namespace), Substrate's egress
  gateway (atenet-egress, in Substrate's namespace) with Substrate on, and
  workspace-manager (its pods, in its release's namespace) with workspaces on;
  then the block's own peers, each once. An own `enabled: false` fails the
  render: whoever reaches the API port picks whose RBAC applies. So does a
  workspace-manager range whose floor is below
  agent-platform.workspaceManager.tokenFloor (no ServiceAccount token).
Emits {} in the noop mode, and with kagent off.
Usage: include "agent-platform.kagent.authorization" . | fromJson
*/}}
{{- define "agent-platform.kagent.authorization" -}}
{{- $out := dict -}}
{{- $kagent := .Values.kagent | default dict -}}
{{- $authz := dig "controller" "authorization" dict $kagent -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) (eq (toString (dig "mode" "" $authz)) "kubernetes") -}}
{{- $a := dict -}}
{{- if not (dig "includeNamespaces" list $authz) -}}
{{- $_ := set $a "includeNamespaces" (list (include "agent-platform.kagent.namespace" .)) -}}
{{- end -}}
{{- $label := include "agent-platform.orgNamespaces.label" . -}}
{{- $ownSel := toString (dig "namespaceSelector" "" $authz) -}}
{{- if and $ownSel (ne $ownSel $label) -}}
{{- fail (printf "kagent.controller.authorization.namespaceSelector (%s) differs from the label of the organizations' namespaces (%s): a person's agent list ranges over the namespaces the platform's policies admit — leave it unset" $ownSel $label) -}}
{{- end -}}
{{- $_ := set $a "namespaceSelector" $label -}}
{{- $wmOn := and (dig "enabled" false (.Values.workspaces | default dict)) (include "agent-platform.componentEnabled" (dict "root" . "name" "workspace-manager")) -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- if $wmOn -}}
{{- $audience := dig "kagent" "tokenAudience" "" $wm | default "kagent" -}}
{{- $own := toString (dig "serviceAccountTokenAudience" "" $authz) -}}
{{- if and $own (ne $own $audience) -}}
{{- fail (printf "kagent.controller.authorization.serviceAccountTokenAudience (%s) differs from the audience of workspace-manager's token (%s, workspace-manager.kagent.tokenAudience): the controller's TokenReview would refuse every call of the manager — leave kagent.controller.authorization.serviceAccountTokenAudience unset, it follows workspace-manager.kagent.tokenAudience" $own $audience) -}}
{{- end -}}
{{- $_ := set $a "serviceAccountTokenAudience" $audience -}}
{{- $wmFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig "workspace-manager" "versionRange" "" .Values.components) | default "0.0.0") "" -}}
{{- if lt ((semver $wmFloor).Compare (semver (include "agent-platform.workspaceManager.tokenFloor" .))) 0 -}}
{{- fail (printf "components.workspace-manager.versionRange (floor %s) admits a workspace-manager before %s, which calls the kagent controller without a ServiceAccount token, so the kubernetes authorization mode refuses its Session listing and no session directory is cleaned up — raise the floor, or set kagent.controller.authorization.mode: noop" $wmFloor (include "agent-platform.workspaceManager.tokenFloor" .)) -}}
{{- end -}}
{{- end -}}
{{- $refusals := include "agent-platform.klausGateway.refusalsOn" . -}}
{{- if $refusals -}}
{{- $reader := printf "%s/%s" (include "agent-platform.klausGateway.namespace" .) (include "agent-platform.klausGateway.name" .) -}}
{{- $ownReader := toString (dig "sessionReaderServiceAccount" "" $authz) -}}
{{- if and $ownReader (ne $ownReader $reader) -}}
{{- fail (printf "kagent.controller.authorization.sessionReaderServiceAccount (%s) differs from klaus-gateway's ServiceAccount (%s), which reads the Session of every egress refusal — leave it unset, or set klausGateway.refusals.enabled: false" $ownReader $reader) -}}
{{- end -}}
{{- $_ := set $a "sessionReaderServiceAccount" $reader -}}
{{- $_ := set $a "serviceAccountTokenAudience" (include "agent-platform.kagent.tokenAudience" .) -}}
{{- end -}}
{{- if $a -}}{{- $_ := set $out "authorization" $a -}}{{- end -}}
{{- $np := dig "controller" "networkPolicy" dict $kagent -}}
{{- if eq (toString (dig "enabled" "" $np)) "false" -}}
{{- fail "kagent.controller.networkPolicy.enabled is false with kagent.controller.authorization.mode kubernetes: the controller trusts the user a caller names, so every pod that reaches its API port could pick whose RBAC applies — leave it unset (the chart turns it on and admits the platform's callers), add a caller to kagent.controller.networkPolicy.from, or set kagent.controller.authorization.mode: noop" -}}
{{- end -}}
{{- $connNs := dig "agent-platform-connectivity" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- $peers := list (dict "namespaceSelector" (dict "matchLabels" (dict "kubernetes.io/metadata.name" $connNs)) "podSelector" (dict "matchLabels" (dict "gateway.networking.k8s.io/gateway-name" .Values.gateway.name))) -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "substrate") -}}
{{- $peers = append $peers (dict "namespaceSelector" (dict "matchLabels" (dict "kubernetes.io/metadata.name" (dig "substrate" "targetNamespace" "ate-system" .Values.components))) "podSelector" (dict "matchLabels" (dict "app" "atenet-egress"))) -}}
{{- end -}}
{{- if $wmOn -}}
{{- $wmNs := dig "workspace-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- $peers = append $peers (dict "namespaceSelector" (dict "matchLabels" (dict "kubernetes.io/metadata.name" $wmNs)) "podSelector" (dict "matchLabels" (dict "app.kubernetes.io/name" ($wm.nameOverride | default "workspace-manager")))) -}}
{{- end -}}
{{- if $refusals -}}
{{- $peers = append $peers (dict "namespaceSelector" (dict "matchLabels" (dict "kubernetes.io/metadata.name" (include "agent-platform.klausGateway.namespace" .))) "podSelector" (dict "matchLabels" (dict "app.kubernetes.io/name" (include "agent-platform.klausGateway.name" .)))) -}}
{{- end -}}
{{- if include "agent-platform.organizations.on" . -}}
{{- $operator := include "agent-platform.organizations.operatorServiceAccount" . | fromJson -}}
{{- $peers = append $peers (dict "namespaceSelector" (dict "matchLabels" (dict "kubernetes.io/metadata.name" $operator.namespace)) "podSelector" (dict "matchLabels" (include "agent-platform.organizations.operator" . | fromJson).podLabels)) -}}
{{- end -}}
{{- range (dig "from" list $np) -}}
{{- if not (has . $peers) -}}{{- $peers = append $peers . -}}{{- end -}}
{{- end -}}
{{- $_ := set $out "networkPolicy" (dict "enabled" true "from" $peers) -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
The kagent controller's verification of people's tokens, which the kagent
release receives in the trusted-proxy authentication mode
(kagent.controller.auth.mode), as a partial controller block:
- auth.issuer: the issuer the controller route's AgentgatewayPolicy
  kagent-controller-jwt verifies, kagent.controllerRoute.jwtAuthentication
  .issuer, else global.identity.issuerUrl;
- auth.jwksURL: the key set that policy fetches, from
  kagent.controllerRoute.jwtAuthentication.jwks: https://<host>[:<port>]<path>
  with TLS (jwks.tls.enabled, or port 443), else http://<host>:<port><path>;
- auth.jwksAllowHTTP: true beside a derived plain-http jwksURL (the in-cluster
  Dex serves no TLS).
The controller then checks the signature, iss and exp of a person's token
against the issuer's keys before it reads a claim. Each key the block sets
stands, and the derived jwksAllowHTTP accompanies only the derived jwksURL.
Emits {} without an issuer or a JWKS host, in another mode and with kagent off.
A derived https jwksURL verified against a private CA (jwks.tls.caSecretName,
or global.identity.ca.secretName under jwks.tls.enabled) fails the render: the
controller trusts the system roots only, so it names the URL to set instead.
Usage: include "agent-platform.kagent.authentication" . | fromJson
*/}}
{{- define "agent-platform.kagent.authentication" -}}
{{- $out := dict -}}
{{- $kagent := .Values.kagent | default dict -}}
{{- $own := dig "controller" "auth" dict $kagent | default dict -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) (eq (toString (dig "mode" "" $own)) "trusted-proxy") -}}
{{- $jwt := dig "controllerRoute" "jwtAuthentication" dict $kagent | default dict -}}
{{- $issuer := toString ($own.issuer | default ($jwt.issuer | default (dig "identity" "issuerUrl" "" (.Values.global | default dict)))) -}}
{{- $jwks := $jwt.jwks | default dict -}}
{{- $host := $jwks.host | default "" | toString | lower | trimSuffix "." -}}
{{- $url := "" -}}
{{- $tls := false -}}
{{- if $host -}}
{{- $port := $jwks.port | default 443 | int -}}
{{- $tls = or (dig "tls" "enabled" false $jwks) (eq $port 443) -}}
{{- $path := printf "/%s" ($jwks.path | default "/keys" | toString | trimPrefix "/") -}}
{{- if $tls -}}
{{- $url = printf "https://%s%s%s" $host (ternary "" (printf ":%d" $port) (eq $port 443)) $path -}}
{{- else -}}
{{- $url = printf "http://%s:%d%s" $host $port $path -}}
{{- end -}}
{{- end -}}
{{- if and $issuer ($own.jwksURL | default $url) -}}
{{- $a := dict -}}
{{- if not $own.issuer -}}{{- $_ := set $a "issuer" $issuer -}}{{- end -}}
{{- if not $own.jwksURL -}}
{{- $ca := dig "tls" "caSecretName" "" $jwks -}}
{{- if and (not $ca) (dig "tls" "enabled" false $jwks) -}}
{{- $ca = dig "identity" "ca" "secretName" "" (.Values.global | default dict) -}}
{{- end -}}
{{- if and $tls $ca -}}
{{- fail (printf "the kagent controller verifies people's tokens against %s, whose certificate the CA in Secret %s signs, but the controller trusts the system roots only: set kagent.controller.auth.jwksURL to a key set the controller can fetch (the issuer's in-cluster Service on plain http, with kagent.controller.auth.jwksAllowHTTP: true)" $url $ca) -}}
{{- end -}}
{{- $_ := set $a "jwksURL" $url -}}
{{- if and (not $tls) (not (hasKey $own "jwksAllowHTTP")) -}}{{- $_ := set $a "jwksAllowHTTP" true -}}{{- end -}}
{{- end -}}
{{- with $a -}}{{- $_ := set $out "auth" . -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
The first release of the kagent line whose controller verifies a person's
token against the issuer's keys (controller.auth.issuer, jwksURL and
jwksAllowHTTP; giantswarm/kagent-upstream#837). An earlier chart ignores the
keys and its controller reads the claims of a token it never verified, so with
them set the render fails under that floor
(agent-platform.validateKagentAuthentication). One line, no comment inside the
define.
*/}}
{{- define "agent-platform.kagent.authenticationFloor" -}}1.24.1{{- end -}}

{{/*
The guards of the kagent controller's verification of people's tokens, run
while the kagent component renders (agent-platform.componentDerivedValues):
- with an issuer on the release (own or agent-platform.kagent.authentication)
  in the trusted-proxy mode, the floor of components.kagent.versionRange is at
  least agent-platform.kagent.authenticationFloor; a release candidate of it
  passes.
Emits nothing; fails naming the key and the fix.
*/}}
{{- define "agent-platform.validateKagentAuthentication" -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "kagent") -}}
{{- $own := dig "controller" "auth" dict (.Values.kagent | default dict) | default dict -}}
{{- $mode := toString (dig "mode" "" $own) -}}
{{- $derived := (include "agent-platform.kagent.authentication" . | fromJson).auth | default dict -}}
{{- if and (eq $mode "trusted-proxy") (or $own.issuer $derived.issuer) -}}
{{- $floor := include "agent-platform.kagent.authenticationFloor" . -}}
{{- $range := dig "kagent" "versionRange" "" .Values.components -}}
{{- $have := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $range | default "0.0.0") "" -}}
{{- if lt ((semver $have).Compare (semver $floor)) 0 -}}
{{- fail (printf "components.kagent.versionRange %q admits a kagent release below %s, the first whose controller verifies people's tokens against the issuer's keys: in the trusted-proxy mode this chart sets kagent.controller.auth.issuer and jwksURL on the kagent release, which an earlier chart ignores; move the floor to %s or later" $range $floor $floor) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The workspace-manager's public base URL, without a trailing slash:
workspace-manager.oauth.baseURL, else
https://<workspace-manager.fullnameOverride>.<global.domain> (the component
chart's own derivation). The connectivity release routes the browser's
provider sign-in on its host (workspaceManager.route), the component release
receives it as oauth.baseURL, NOTES prints it. Empty when neither is set.
*/}}
{{- define "agent-platform.workspaceManager.baseURL" -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- $url := dig "oauth" "baseURL" "" $wm -}}
{{- if and (not $url) .Values.global.domain -}}
{{- $url = printf "https://%s.%s" ($wm.fullnameOverride | default "workspace-manager") .Values.global.domain -}}
{{- end -}}
{{- $url | trimSuffix "/" -}}
{{- end -}}

{{/*
The key the workspace-manager signs its workspace grants with, as the
component release receives it (workspace-manager.grant.signingKey, a Secret
reference {name, key}): the block's own when it names one; else, with
provider instances, oauth.enabled and workspaceManager.grantKey.create, the
Secret the connectivity release creates (workspaceManager.grantKey.secretName
and .key); else empty — the manager refuses a key without providers and
OAuth. The connectivity chart derives the same reference for the Secret it
creates (templates/workspace-manager/_helpers.tpl, grantSigningKey), so both
name one Secret. Emits JSON: {name, key}, or {}.
*/}}
{{- define "agent-platform.workspaceManager.grantSigningKey" -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- $own := dig "grant" "signingKey" dict $wm | default dict -}}
{{- $gk := dig "grantKey" dict (.Values.workspaceManager | default dict) -}}
{{- $out := dict -}}
{{- if and (kindIs "map" $own) (or $own.name $own.key) -}}
{{- $out = dict "name" (toString ($own.name | default "")) "key" (toString ($own.key | default "")) -}}
{{- else if and $wm.providers (dig "oauth" "enabled" false $wm) (dig "create" true $gk) -}}
{{- $out = dict "name" (toString (dig "secretName" "" $gk)) "key" (toString (dig "key" "" $gk)) -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
muster's pin of the workspace-manager's registration, with provider instances
and oauth.enabled (nothing otherwise): the provider instance whose App the
person grants once in muster (muster.mcpServer.auth.provider) and the Secret
with that App's OAuth client under client-id and client-secret, which muster
reads (muster.mcpServer.auth.authorizationServer.clientCredentialsSecretRef.name),
and the issuer muster files each person's grant of that App under
(muster.mcpServer.auth.authorizationServer.issuer). The block's own value
stands; else the provider is the only instance of kind github, the Secret that
of the instance's values.oauth.clientSecret when its key is client-secret,
muster's default key, and the issuer <values.url, default https://github.com>/apps/<values.app.id>
of a github instance: an identity only, unique per App on its host, since the
workspace-manager chart pins the endpoints and checks GitHub's own `iss`
(expectedIssuer), so muster discovers nothing under it. Any is empty when
neither applies; agent-platform.validateWorkspaceAuth then fails naming the
key. Emits JSON {provider, secretName, issuer}, or {}.
Usage: include "agent-platform.workspaceManager.musterPin" . | fromJson
*/}}
{{- define "agent-platform.workspaceManager.musterPin" -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- $out := dict -}}
{{- if and $wm.providers (dig "oauth" "enabled" false $wm) (not (include "agent-platform.workspaceManager.providerApps" . | fromJson).derived) -}}
{{- $auth := dig "muster" "mcpServer" "auth" dict $wm | default dict -}}
{{- $provider := toString ($auth.provider | default "") -}}
{{- if not $provider -}}
{{- $github := list -}}
{{- range $wm.providers -}}{{- if eq (toString .kind) "github" -}}{{- $github = append $github (toString .name) -}}{{- end -}}{{- end -}}
{{- if eq (len $github) 1 -}}{{- $provider = first $github -}}{{- end -}}
{{- end -}}
{{- $secret := toString (dig "authorizationServer" "clientCredentialsSecretRef" "name" "" $auth) -}}
{{- if and $provider (not $secret) -}}
{{- range $wm.providers -}}
{{- if eq (toString .name) $provider -}}
{{- $oauth := (.values | default dict).oauth | default dict -}}
{{- $client := ternary $oauth.clientSecret dict (kindIs "map" $oauth) | default dict -}}
{{- if and (kindIs "map" $client) (eq (toString ($client.key | default "")) "client-secret") -}}
{{- $secret = toString ($client.name | default "") -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $issuer := toString (dig "authorizationServer" "issuer" "" $auth) -}}
{{- if and $provider (not $issuer) -}}
{{- range $wm.providers -}}
{{- $v := .values | default dict -}}
{{- $id := toString (dig "app" "id" "" $v) -}}
{{- if and (eq (toString .name) $provider) (eq (toString .kind) "github") $id -}}
{{- $issuer = printf "%s/apps/%s" (trimSuffix "/" (toString ($v.url | default "https://github.com"))) $id -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $out = dict "provider" $provider "secretName" $secret "issuer" $issuer -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
What the toolchain-manager release receives beyond its block, while
components.toolchain-manager is on; each key the block sets stands:
- auth.dex.issuerURL: global.identity.issuerUrl, else muster's login
  (muster.muster.oauth.server.dex.issuerUrl, with the dex provider on); none
  fails the render, since the chart would serve its tools unauthenticated;
- auth.trustedAudiences: [global.identity.clientId, else the login's
  clientId]; none fails the render;
- auth.dex.caSecret: global.identity.ca (secretName, key default ca.crt), the
  private CA of the issuer;
- muster.mcpServer.enabled: whether the muster component is on (the
  MCPServer CRD ships with it), forced false while it is off;
- muster.mcpServer.authorizationServer: the registration pinned to the
  installation's agents GitHub App, the App of the workspace-manager's github
  provider instance (agent-platform.workspaceManager.musterPin) while
  workspaces are on: its issuer, GitHub's endpoints on the instance's url
  (default https://github.com) and, on github.com, the iss GitHub names
  (https://github.com/login/oauth), and the App's client Secret (client-id,
  client-secret) in the workspace-manager's namespace; muster files a person's
  grant under the issuer, so one grant serves both registrations;
- sources: the block's sources followed by additionalSources, while
  additionalSources names any; a repository named twice fails the render;
- muster.mcpUrl, muster's MCP endpoint (agent-platform.musterMcpUrl), and
  muster.agentManagerToolsPrefix, x_<agent-manager's MCPServer name>_ while
  agent-manager and muster are on, else empty (deprecate_toolchain then not
  served), from the toolchain-manager floor
  agent-platform.toolchainManager.deprecateFloor;
- klausGateway.url, klaus-gateway's Service, and klausGateway.audience, its
  reviews.audience, while the gateway takes the manager's notices and asks
  (agent-platform.toolchainManager.reviews), else nothing (the manager then
  posts nothing).
Emits JSON, {} while the component is off.
Usage: include "agent-platform.toolchainManager.derived" . | fromJson
*/}}
{{- define "agent-platform.toolchainManager.derived" -}}
{{- $out := dict -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "toolchain-manager") -}}
{{- $tm := index .Values "toolchain-manager" | default dict -}}
{{- $identity := dig "identity" dict (.Values.global | default dict) -}}
{{- $server := dig "muster" "oauth" "server" dict (.Values.muster | default dict) -}}
{{- $login := dict -}}
{{- if and (dig "enabled" true $server) (eq (toString (dig "provider" "dex" $server)) "dex") -}}
{{- $login = dig "dex" dict $server -}}
{{- end -}}
{{- $ownDex := dig "auth" "dex" dict $tm | default dict -}}
{{- $dex := dict -}}
{{- $issuer := toString ($ownDex.issuerURL | default ($identity.issuerUrl | default ($login.issuerUrl | default ""))) -}}
{{- if not $issuer -}}
{{- fail "components.toolchain-manager needs the platform's login: set global.identity.issuerUrl (or muster.muster.oauth.server.dex.issuerUrl), or toolchain-manager.auth.dex.issuerURL; without an issuer the chart serves its tools to anyone who reaches the Service" -}}
{{- end -}}
{{- if not $ownDex.issuerURL -}}{{- $_ := set $dex "issuerURL" $issuer -}}{{- end -}}
{{- with $identity.ca -}}
{{- if and .secretName (not (dig "caSecret" "name" "" $ownDex)) -}}
{{- $_ := set $dex "caSecret" (dict "name" .secretName "key" (.key | default "ca.crt")) -}}
{{- end -}}
{{- end -}}
{{- $auth := dict -}}
{{- with $dex -}}{{- $_ := set $auth "dex" . -}}{{- end -}}
{{- if not (dig "auth" "trustedAudiences" list $tm) -}}
{{- $client := toString ($identity.clientId | default ($login.clientId | default "")) -}}
{{- if not $client -}}
{{- fail "components.toolchain-manager needs the platform's OAuth client: set global.identity.clientId (or muster.muster.oauth.server.dex.clientId), or toolchain-manager.auth.trustedAudiences" -}}
{{- end -}}
{{- $_ := set $auth "trustedAudiences" (list $client) -}}
{{- end -}}
{{- with $auth -}}{{- $_ := set $out "auth" . -}}{{- end -}}
{{- $ownMcp := dig "muster" "mcpServer" dict $tm | default dict -}}
{{- $mcp := dict -}}
{{- $musterOn := include "agent-platform.componentEnabled" (dict "root" . "name" "muster") -}}
{{- if not $musterOn -}}
{{- $_ := set $mcp "enabled" false -}}
{{- else if not (hasKey $ownMcp "enabled") -}}
{{- $_ := set $mcp "enabled" true -}}
{{- end -}}
{{- if and $musterOn (not $ownMcp.authorizationServer) (dig "enabled" false (.Values.workspaces | default dict)) -}}
{{- $pin := include "agent-platform.workspaceManager.musterPin" . | fromJson -}}
{{- if and $pin.provider $pin.secretName $pin.issuer -}}
{{- $url := "https://github.com" -}}
{{- range (index .Values "workspace-manager" | default dict).providers -}}
{{- if eq (toString .name) $pin.provider -}}{{- $url = trimSuffix "/" (toString ((.values | default dict).url | default $url)) -}}{{- end -}}
{{- end -}}
{{- $ns := dig "workspace-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- $as := dict "issuer" $pin.issuer "authorizationEndpoint" (printf "%s/login/oauth/authorize" $url) "tokenEndpoint" (printf "%s/login/oauth/access_token" $url) "clientCredentialsSecretRef" (dict "name" $pin.secretName "namespace" $ns "clientIdKey" "client-id" "clientSecretKey" "client-secret") -}}
{{- if eq $url "https://github.com" -}}{{- $_ := set $as "expectedIssuer" "https://github.com/login/oauth" -}}{{- end -}}
{{- $_ := set $mcp "authorizationServer" $as -}}
{{- end -}}
{{- end -}}
{{- $muster := dict -}}
{{- with $mcp -}}{{- $_ := set $muster "mcpServer" . -}}{{- end -}}
{{- /* deprecate_toolchain asks agent-manager through muster, as the person,
which agents and Sessions use a toolchain: muster's MCP endpoint and
agent-manager's tool prefix, empty while either is off (the tool is then not
served). Only while the floor of components.toolchain-manager.versionRange
takes the keys (agent-platform.toolchainManager.deprecateFloor). */ -}}
{{- $tmFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig "toolchain-manager" "versionRange" "" .Values.components) | default "0.0.0") "" -}}
{{- if ge ((semver $tmFloor).Compare (semver (include "agent-platform.toolchainManager.deprecateFloor" .))) 0 -}}
{{- $ownMuster := dig "muster" dict $tm | default dict -}}
{{- if not (hasKey $ownMuster "mcpUrl") -}}{{- $_ := set $muster "mcpUrl" (include "agent-platform.musterMcpUrl" .) -}}{{- end -}}
{{- if not (hasKey $ownMuster "agentManagerToolsPrefix") -}}
{{- $amPrefix := "" -}}
{{- if and $musterOn (include "agent-platform.componentEnabled" (dict "root" . "name" "agent-manager")) -}}
{{- $amPrefix = printf "x_%s_" (dig "muster" "mcpServer" "name" "agent-manager" (index .Values "agent-manager" | default dict)) -}}
{{- end -}}
{{- $_ := set $muster "agentManagerToolsPrefix" $amPrefix -}}
{{- end -}}
{{- end -}}
{{- with $muster -}}{{- $_ := set $out "muster" . -}}{{- end -}}
{{- with (include "agent-platform.toolchainManager.reviews" . | fromJson) -}}
{{- $ownKg := dig "klausGateway" dict $tm | default dict -}}
{{- $kgValues := dict -}}
{{- if not $ownKg.url -}}{{- $_ := set $kgValues "url" .url -}}{{- end -}}
{{- if not $ownKg.audience -}}{{- $_ := set $kgValues "audience" .audience -}}{{- end -}}
{{- with $kgValues -}}{{- $_ := set $out "klausGateway" . -}}{{- end -}}
{{- end -}}
{{- with $tm.additionalSources -}}
{{- $sources := concat ($tm.sources | default list) . -}}
{{- $seen := dict -}}
{{- range $sources -}}
{{- $repo := toString (.repository | default "") -}}
{{- if hasKey $seen $repo -}}
{{- fail (printf "toolchain-manager: the source %s is named twice (sources and additionalSources); name each repository once" $repo) -}}
{{- end -}}
{{- $_ := set $seen $repo true -}}
{{- end -}}
{{- $_ := set $out "sources" $sources -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
The registries the installation's toolchains are pulled from, while
components.toolchain-manager is on: every source's registry, sources then
additionalSources, each once (registries, the first the sources' own), and
toolchain-manager.registryPullSecret (pullSecret), the one
kubernetes.io/dockerconfigjson Secret with read credentials for the private
ones. They wire the other side of a toolchain: agent-manager reads a
toolchain's image with them and Substrate's atelet pulls it
(agent-platform.componentDerivedValues). Emits JSON, {} while the component is
off.
Usage: include "agent-platform.toolchains.registries" $root | fromJson
*/}}
{{- define "agent-platform.toolchains.registries" -}}
{{- $out := dict -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "toolchain-manager") -}}
{{- $tm := index .Values "toolchain-manager" | default dict -}}
{{- $registries := list -}}
{{- range concat ($tm.sources | default list) ($tm.additionalSources | default list) -}}
{{- with toString (.registry | default "") -}}{{- $registries = append $registries . -}}{{- end -}}
{{- end -}}
{{- with uniq $registries -}}{{- $_ := set $out "registries" . -}}{{- end -}}
{{- with toString ($tm.registryPullSecret | default "") -}}{{- $_ := set $out "pullSecret" . -}}{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
Whether the floor of components.<name>.versionRange is at least version, a
release candidate of it included: "true", else empty (a range without a floor
too).
Usage: include "agent-platform.componentFloorAtLeast" (dict "root" $root "name" "<component>" "version" "X.Y.Z")
*/}}
{{- define "agent-platform.componentFloorAtLeast" -}}
{{- $floor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig .name "versionRange" "" .root.Values.components)) "" -}}
{{- if and $floor (ge ((semver $floor).Compare (semver .version)) 0) -}}true{{- end -}}
{{- end -}}

{{/*
The toolchain-manager's MCP backend entry for the connectivity release
(networkPolicy.mcpBackends.toolchain-manager), while the component is on: its
pods in the namespace its release lands in, on the port the manager listens
on, so the connectivity chart's ingress policy admits muster and the
namespace's own pods only. Emits JSON, {} while the component is off.
Usage: include "agent-platform.toolchainManager.mcpBackend" . | fromJson
*/}}
{{- define "agent-platform.toolchainManager.mcpBackend" -}}
{{- $out := dict -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "toolchain-manager") -}}
{{- $ns := dig "toolchain-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- $out = dict "namespace" $ns "ports" (list 8080) "podSelector" (dict "app.kubernetes.io/name" "toolchain-manager") -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
Where the toolchain-manager posts its outdated notices: klaus-gateway's
team-review endpoint, while the
component and klaus-gateway are on, klausGateway.reviews.enabled is true and
the floor of components.toolchain-manager.versionRange is at or above
agent-platform.toolchainManager.reviewsFloor. url is the gateway's Service
(klausGateway.fullnameOverride, its namespace, klausGateway.server.port,
default 8080), audience its reviews.audience (default klaus-gateway) and
caller the manager's ServiceAccount as the gateway's TokenReview names it
(system:serviceaccount:<its namespace>:toolchain-manager). Emits JSON, {}
otherwise.
Usage: include "agent-platform.toolchainManager.reviews" . | fromJson
*/}}
{{- define "agent-platform.toolchainManager.reviews" -}}
{{- $out := dict -}}
{{- $kg := .Values.klausGateway | default dict -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "toolchain-manager")) (include "agent-platform.componentEnabled" (dict "root" . "name" "klaus-gateway")) (eq (toString (dig "reviews" "enabled" false $kg)) "true") -}}
{{- $tmFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig "toolchain-manager" "versionRange" "" .Values.components) | default "0.0.0") "" -}}
{{- if ge ((semver $tmFloor).Compare (semver (include "agent-platform.toolchainManager.reviewsFloor" .))) 0 -}}
{{- $url := printf "http://%s.%s.svc.cluster.local:%v" (include "agent-platform.klausGateway.name" .) (include "agent-platform.klausGateway.namespace" .) (dig "server" "port" 8080 $kg) -}}
{{- $tmNs := dig "toolchain-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- $out = dict "url" $url "audience" (toString (dig "reviews" "audience" "klaus-gateway" $kg)) "caller" (printf "system:serviceaccount:%s:toolchain-manager" $tmNs) -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
muster's provider Apps of the workspace provider instances, GitHub and GitLab
side by side, while workspaces are on with provider instances and
oauth.enabled: the person grants each instance's App once in muster, muster
attaches the token of every App they granted to the workspace-manager's calls
(X-Muster-Grant-<instance>) and releases it to a Session's git and API egress
under the instance's name. names are the instances the registration receives
the grants of: workspace-manager.muster.mcpServer.auth.providerApps, else,
without an own pin (auth.provider), every instance with person sign-in (a
values.oauth.clientSecret with key client-secret, muster's default key) once
there are two or more — derived true, and then nothing pins the registration
(agent-platform.workspaceManager.musterPin): one instance with sign-in keeps
the pin, so a single-provider installation renders as before. apps is the
list muster keeps (muster.muster.providerApps): every own App, then one per
named instance the own list lacks — kind github: issuer <url>/apps/<app.id>
(the pin's form; the only github instance keeps the pin's own
auth.authorizationServer.issuer and clientCredentialsSecretRef.name, so its
grants stay filed where they are), GitHub's endpoints on <url> (default
https://github.com) and, on github.com, the iss GitHub names in its answer
(https://github.com/login/oauth); kind gitlab: issuer <url> (default
https://gitlab.com), GitLab's endpoints on it (/oauth/authorize, /oauth/token,
revocationEndpoint /oauth/revoke),
values.oauth.scopes (default api read_user read_repository write_repository,
the API and git as the person) and gitUser oauth2; each with the instance's
client Secret in the workspace-manager's namespace. unresolved names the
instances neither own nor derived (agent-platform.validateWorkspaceAuth fails
on them). Emits JSON {names, apps, derived, unresolved}, or {}.
Usage: include "agent-platform.workspaceManager.providerApps" . | fromJson
*/}}
{{- define "agent-platform.workspaceManager.providerApps" -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- $out := dict -}}
{{- if and (.Values.workspaces | default dict).enabled $wm.providers (dig "oauth" "enabled" false $wm) -}}
{{- $auth := dig "muster" "mcpServer" "auth" dict $wm | default dict -}}
{{- /* The instance a pin would take (the only one of kind github) keeps the
pin's own issuer and client Secret, so its grants stay filed where they are. */ -}}
{{- $github := list -}}
{{- range $wm.providers -}}{{- if eq (toString .kind) "github" -}}{{- $github = append $github (toString .name) -}}{{- end -}}{{- end -}}
{{- $pinned := ternary (first $github) "" (eq (len $github) 1) -}}
{{- $ownIssuer := toString (dig "authorizationServer" "issuer" "" $auth) -}}
{{- $ownSecret := toString (dig "authorizationServer" "clientCredentialsSecretRef" "name" "" $auth) -}}
{{- $clients := dict -}}
{{- range $wm.providers -}}
{{- $oauth := (.values | default dict).oauth -}}
{{- $client := dict -}}
{{- if kindIs "map" $oauth -}}{{- $client = $oauth.clientSecret | default dict -}}{{- end -}}
{{- if and $pinned $ownSecret (eq (toString .name) $pinned) -}}
{{- $_ := set $clients $pinned $ownSecret -}}
{{- else if and (kindIs "map" $client) $client.name (eq (toString ($client.key | default "")) "client-secret") -}}
{{- $_ := set $clients (toString .name) (toString $client.name) -}}
{{- end -}}
{{- end -}}
{{- $names := list -}}
{{- range ($auth.providerApps | default list) -}}{{- $names = append $names (toString .) -}}{{- end -}}
{{- $derived := false -}}
{{- if and (not $names) (not $auth.provider) (ge (len $clients) 2) -}}
{{- range $wm.providers -}}{{- if hasKey $clients (toString .name) -}}{{- $names = append $names (toString .name) -}}{{- end -}}{{- end -}}
{{- $derived = true -}}
{{- end -}}
{{- if $names -}}
{{- $ns := dig "workspace-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- $apps := list -}}
{{- $own := list -}}
{{- range (dig "muster" "providerApps" list (.Values.muster | default dict)) -}}
{{- $apps = append $apps . -}}{{- $own = append $own (toString .name) -}}
{{- end -}}
{{- $unresolved := list -}}
{{- range $name := $names -}}
{{- if not (has $name $own) -}}
{{- $app := dict -}}
{{- range $wm.providers -}}
{{- if and (eq (toString .name) $name) (hasKey $clients $name) -}}
{{- $v := .values | default dict -}}
{{- $ref := dict "name" (get $clients $name) "namespace" $ns -}}
{{- $scopes := toString (dig "oauth" "scopes" "" $v) -}}
{{- if eq (toString .kind) "github" -}}
{{- $url := trimSuffix "/" (toString ($v.url | default "https://github.com")) -}}
{{- $issuer := "" -}}
{{- if eq $name $pinned -}}{{- $issuer = $ownIssuer -}}{{- end -}}
{{- with toString (dig "app" "id" "" $v) -}}{{- $issuer = $issuer | default (printf "%s/apps/%s" $url .) -}}{{- end -}}
{{- with $issuer -}}
{{- $app = dict "name" $name "issuer" . "authorizationEndpoint" (printf "%s/login/oauth/authorize" $url) "tokenEndpoint" (printf "%s/login/oauth/access_token" $url) "clientCredentialsSecretRef" $ref -}}
{{- if eq $url "https://github.com" -}}{{- $_ := set $app "expectedIssuer" "https://github.com/login/oauth" -}}{{- end -}}
{{- if $scopes -}}{{- $_ := set $app "scopes" $scopes -}}{{- end -}}
{{- end -}}
{{- else if eq (toString .kind) "gitlab" -}}
{{- $url := trimSuffix "/" (toString ($v.url | default "https://gitlab.com")) -}}
{{- $app = dict "name" $name "issuer" $url "authorizationEndpoint" (printf "%s/oauth/authorize" $url) "tokenEndpoint" (printf "%s/oauth/token" $url) "revocationEndpoint" (printf "%s/oauth/revoke" $url) "clientCredentialsSecretRef" $ref "scopes" ($scopes | default "api read_user read_repository write_repository") "gitUser" "oauth2" -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if $app -}}{{- $apps = append $apps $app -}}{{- else -}}{{- $unresolved = append $unresolved $name -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $out = dict "names" $names "apps" $apps "derived" $derived "unresolved" $unresolved -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
muster's credential provider while Substrate and muster's OAuth server are on:
muster answers agent-manager's session bindings and, with workspaces on, the
egress gateway's credential fetches for a workspace Session's provider hosts
(ate-secret://muster.giantswarm.io/<provider instance>/<git|api>). Without
workspaces it releases nothing and serves the actor bearer alone, so every
Session agent-manager starts calls muster with its Actor's JWT, never with the
person's forwarded token; without the actor bearer there is nothing to serve
and it emits {}. muster serves FetchSecret on Substrate's
pod certificates, which only a cluster running Substrate issues, and answers
the gateway's pod identity alone
(spiffe://cluster.local/ns/<substrate targetNamespace>/sa/atenet-egress).
releasable, the provider instances whose grants muster releases, is the
instance muster's registration of the workspace-manager is pinned to under its
App's issuer, own or derived (agent-platform.workspaceManager.musterPin), and
every provider App muster keeps under its issuer, with gitUsers the git user
of each App that names one (agent-platform.workspaceManager.providerApps):
the same instance names the Session's credential URIs and agent-manager's
binding carry. actorBearer: muster serves a Session's own MCP calls as the person the
Session's actor is bound to, verifying the actor JWT Substrate's egress gateway
injects against the issuer ate-api-server signs it as and ate-idp-server serves
(the Substrate line from 1.13.0; substrate.ateApi.actorJWTIssuer, else the idp
Service of the release `substrate`, https://idp.<substrate namespace>.svc), for
muster's own audience (its oauth.server.baseUrl, the muster chart's default);
only a binding that lists the reserved provider `muster` is served.
muster.credentialProvider's own keys stand. muster refuses a credential
provider that releases nothing, so with workspaces on an empty releasable
fails the render (agent-platform.validateWorkspaceAuth). Emits JSON, {} with
Substrate, muster or muster's OAuth server off, and without workspaces when
the actor bearer is off.
Usage: include "agent-platform.muster.credentialProvider" . | fromJson
*/}}
{{- define "agent-platform.muster.credentialProvider" -}}
{{- $provider := dict -}}
{{- $muster := dig "muster" dict (.Values.muster | default dict) | default dict -}}
{{- $workspaces := (.Values.workspaces | default dict).enabled | default false -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "substrate")) (include "agent-platform.componentEnabled" (dict "root" . "name" "muster")) (or $workspaces (dig "oauth" "server" "enabled" false $muster)) -}}
{{- $substrateNs := dig "substrate" "targetNamespace" "ate-system" (.Values.components | default dict) -}}
{{- $own := dig "muster" "credentialProvider" dict (.Values.muster | default dict) | default dict -}}
{{- $issuer := dig "ateApi" "actorJWTIssuer" "" (.Values.substrate | default dict) | default (printf "https://idp.%s.svc" $substrateNs) -}}
{{- $provider = dict "enabled" true "gatewayIdentity" (printf "spiffe://cluster.local/ns/%s/sa/atenet-egress" $substrateNs) "actorBearer" (dict "enabled" true "issuer" $issuer) -}}
{{- if $workspaces -}}
{{- $releasable := dict -}}
{{- $gitUsers := dict -}}
{{- $pin := include "agent-platform.workspaceManager.musterPin" . | fromJson -}}
{{- if and $pin.provider $pin.issuer -}}
{{- $_ := set $releasable $pin.provider $pin.issuer -}}
{{- end -}}
{{- range $app := (include "agent-platform.workspaceManager.providerApps" . | fromJson).apps -}}
{{- $_ := set $releasable (toString $app.name) (trimSuffix "/" (toString $app.issuer)) -}}
{{- with $app.gitUser -}}{{- $_ := set $gitUsers (toString $app.name) (toString .) -}}{{- end -}}
{{- end -}}
{{- if $releasable -}}{{- $_ := set $provider "releasable" $releasable -}}{{- end -}}
{{- if $gitUsers -}}{{- $_ := set $provider "gitUsers" $gitUsers -}}{{- end -}}
{{- end -}}
{{- $provider = mergeOverwrite $provider $own -}}
{{- /* mergeOverwrite never lets a false win: an own actorBearer.enabled: false turns it off. */ -}}
{{- $ownBearer := $own.actorBearer | default dict -}}
{{- if and (kindIs "map" $ownBearer) (hasKey $ownBearer "enabled") -}}
{{- $_ := set $provider.actorBearer "enabled" $ownBearer.enabled -}}
{{- end -}}
{{- if not (or $workspaces $provider.releasable $provider.actorBearer.enabled) -}}
{{- $provider = dict -}}
{{- end -}}
{{- end -}}
{{- $provider | toJson -}}
{{- end -}}

{{/*
kagent's reserved actor-JWT provider `muster` (kagent.controller.session
.actorJWTProviders.muster, the kagent line from 1.17.0): while muster trusts the
actor JWT (agent-platform.muster.credentialProvider's actorBearer on), kagent
adds `muster` to every Session admitted with a workspace grant, and to every
Session a binding caller (agent-manager's start_session) creates without one,
and compiles it
into an actor_jwt rule on muster's host, so Substrate's egress gateway hands
muster the Session Actor's JWT and muster serves the Session's person.
hostname is the host of the in-cluster MCP URL every agent's RemoteMCPServer
targets (agent-platform.musterMcpUrl); audience is the one muster verifies, its
own actorBearer.audience, else its oauth.server.baseUrl. An own key of the
kagent block's muster entry stands. Emits JSON, {} with the actor bearer or
muster off, or without an audience (kagent's controller refuses an entry
without one, and muster verifies none then).
Usage: include "agent-platform.kagent.musterActorJWTProvider" . | fromJson
*/}}
{{- define "agent-platform.kagent.musterActorJWTProvider" -}}
{{- $entry := dict -}}
{{- $bearer := (include "agent-platform.muster.credentialProvider" . | fromJson).actorBearer | default dict -}}
{{- $url := include "agent-platform.musterMcpUrl" . -}}
{{- if and $bearer.enabled $url -}}
{{- $muster := dig "muster" dict (.Values.muster | default dict) | default dict -}}
{{- $audience := $bearer.audience | default (dig "oauth" "server" "baseUrl" "" $muster) -}}
{{- $own := dig "controller" "session" "actorJWTProviders" "muster" dict (.Values.kagent | default dict) | default dict -}}
{{- $entry = mergeOverwrite (dict "hostname" (urlParse $url).hostname "audience" $audience) $own -}}
{{- end -}}
{{- if $entry.audience -}}
{{- $entry | toJson -}}
{{- else -}}
{}
{{- end -}}
{{- end -}}


{{/*
A person's own ChatGPT login (giantswarm/giantswarm#38687): a ModelConfig with
credentialType chatgptOAuth and no apiKeySecret, declared with the agents, is
the model "ChatGPT (your subscription)", whose codex turns run on the ChatGPT
subscription the Session's person connected in muster. The ModelConfig is the
only switch: wherever the platform carries the login, this chart derives:
- muster's provider App `chatgpt` (muster.providerApps, flow
  chatgptDeviceCode: OpenAI's device-code sign-in, the Codex CLI's public
  client), which keeps each person's login as their grant, refreshes it as its
  only refresher and releases its access token to the egress gateway as
  ate-secret://<authority>/chatgpt/api for a Session bound to that person;
- kagent's installation provider `chatgpt` (controller.session
  .actorJWTProviders.chatgpt: host chatgpt.com, path prefix /backend-api/codex/,
  scheme Bearer), which every bound Session is admitted with and the egress
  gateway resolves by credential URI at muster's authority.
An own key of the kagent block's chatgpt entry stands; an own muster App named
chatgpt stands in place of the derived one.
The platform carries the login when all of these hold, and the chart derives
nothing otherwise (a chatgptOAuth ModelConfig there finds no login at run time):
- kagent and muster are on;
- muster's credential provider is on (workspaces.enabled with Substrate on,
  agent-platform.muster.credentialProvider) and kagent's Session admission is
  derived (a grant signing key, agent-platform.kagent.sessionAdmission), which
  carries the credential authority the provider resolves at;
- muster keeps tokens encrypted (muster.muster.oauth.server.encryptionKey): a
  person's ChatGPT login is never stored unencrypted;
- muster's OAuth client role is on (muster.muster.oauth.mcpClient.enabled),
  which the muster chart needs for any provider App;
- components.kagent.versionRange and components.kagent-crds.versionRange admit
  no release before agent-platform.kagent.chatgptPersonalLoginFloor (a
  ModelConfig without apiKeySecret, the credential-URI Session provider), and
  components.muster.versionRange none before agent-platform.muster.chatgptAppFloor
  (the device-code App).
Emits JSON {app, provider}, or {}.
Usage: include "agent-platform.chatgpt.personalLogin" . | fromJson
*/}}
{{- define "agent-platform.chatgpt.personalLogin" -}}
{{- $on := and (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) (include "agent-platform.componentEnabled" (dict "root" . "name" "muster")) -}}
{{- if $on -}}
{{- $on = and ((.Values.workspaces | default dict).enabled) ((include "agent-platform.muster.credentialProvider" . | fromJson).enabled) (include "agent-platform.kagent.sessionAdmission" . | fromJson) -}}
{{- end -}}
{{- $muster := dig "muster" dict (.Values.muster | default dict) | default dict -}}
{{- $on = and $on (dig "oauth" "server" "encryptionKey" false $muster) (dig "oauth" "mcpClient" "enabled" false $muster) -}}
{{- if $on -}}
{{- range $c, $floor := dict "kagent" (include "agent-platform.kagent.chatgptPersonalLoginFloor" $) "kagent-crds" (include "agent-platform.kagent.chatgptPersonalLoginFloor" $) "muster" (include "agent-platform.muster.chatgptAppFloor" $) -}}
{{- $have := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig $c "versionRange" "" $.Values.components) | default "0.0.0") "" -}}
{{- if lt ((semver $have).Compare (semver $floor)) 0 -}}{{- $on = false -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- if $on -}}
{{- $own := dig "controller" "session" "actorJWTProviders" "chatgpt" dict (.Values.kagent | default dict) | default dict -}}
{{- $provider := mergeOverwrite (dict "hostname" "chatgpt.com" "pathPrefix" "/backend-api/codex/" "scheme" "Bearer") $own -}}
{{- dict "app" (dict "name" "chatgpt" "flow" "chatgptDeviceCode") "provider" $provider | toJson -}}
{{- else -}}
{}
{{- end -}}
{{- end -}}

{{/*
The first kagent release (and its kagent-crds) that admits a ChatGPT login
without apiKeySecret and admits every bound Session with a credential-URI
provider (giantswarm/kagent-upstream#823), and the first muster release with the
ChatGPT provider App that files the person's grant (giantswarm/muster#1639,
giantswarm/muster#1653). One line each, no comment inside
the define.
*/}}
{{- define "agent-platform.kagent.chatgptPersonalLoginFloor" -}}1.24.0{{- end -}}
{{- define "agent-platform.muster.chatgptAppFloor" -}}5.52.5{{- end -}}
{{/*
The guards of the workspace-manager's provider authorization, while workspaces
are on, here where a failure is seen instead of inside the component release:
- with provider instances and oauth.enabled: the floor of
  components.workspace-manager.versionRange at
  agent-platform.workspaceManager.musterGrantFloor; muster's pin
  (agent-platform.workspaceManager.musterPin) names a provider instance of
  workspace-manager.providers and a Secret with the App's OAuth client, and
  muster.mcpServer.auth.authorizationServer.issuer is set or derived — without the pin no
  person has a provider token and every workspace is refused;
- with provider Apps (agent-platform.workspaceManager.providerApps): each
  named instance is one of workspace-manager.providers and has an App, own or
  derived; the floors of components.workspace-manager.versionRange and
  components.muster.versionRange at
  agent-platform.workspaceManager.providerAppsFloor and
  agent-platform.muster.providerAppsFloor; muster's OAuth client role on
  (muster.muster.oauth.mcpClient.enabled), which the muster chart needs for
  them. Derived Apps replace the pin, whose guards then do not apply;
- with Substrate on: muster's credential provider
  (agent-platform.muster.credentialProvider) releases an instance, pinned or
  own — muster refuses it with an empty releasable;
- workspace-manager.grant.signingKey, when set, only with providers and
  oauth.enabled (the manager refuses to start with a key without them), and
  the reference the manager gets names a Secret and a data key.
Emits nothing; fails naming the key and the fix.
*/}}
{{- define "agent-platform.validateWorkspaceAuth" -}}
{{- if (.Values.workspaces | default dict).enabled -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- if and $wm.providers (dig "oauth" "enabled" false $wm) -}}
{{- $range := dig "workspace-manager" "versionRange" "" .Values.components -}}
{{- $wmFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $range | default "0.0.0") "" -}}
{{- $floor := include "agent-platform.workspaceManager.musterGrantFloor" . -}}
{{- if lt ((semver $wmFloor).Compare (semver $floor)) 0 -}}
{{- fail (printf "components.workspace-manager.versionRange (%s) admits releases before %s, whose manager keeps each person's provider sign-in in a store of its own that this chart no longer feeds: the person's provider token is muster's grant of the provider instance's App from %s on — raise the floor to %s" $range $floor $floor $floor) -}}
{{- end -}}
{{- $pin := include "agent-platform.workspaceManager.musterPin" . | fromJson -}}
{{- $names := list -}}
{{- range $wm.providers -}}{{- $names = append $names (toString .name) -}}{{- end -}}
{{- $apps := include "agent-platform.workspaceManager.providerApps" . | fromJson -}}
{{- if $apps.names -}}
{{- range $apps.names -}}
{{- if not (has . $names) -}}
{{- fail (printf "workspace-manager.muster.mcpServer.auth.providerApps names %q, no provider instance of workspace-manager.providers (%s)" . (join ", " $names)) -}}
{{- end -}}
{{- end -}}
{{- range $apps.unresolved -}}
{{- fail (printf "muster keeps no App of provider instance %s: muster.muster.providerApps has no entry named %s, and the instance has no values.oauth.clientSecret with key client-secret (the Secret with the App's OAuth client under client-id and client-secret, which muster reads) or, of kind github, no values.app.id (its App's issuer) to derive one from — set them, or add the App to muster.muster.providerApps" . .) -}}
{{- end -}}
{{- $appsFloor := include "agent-platform.workspaceManager.providerAppsFloor" . -}}
{{- if lt ((semver $wmFloor).Compare (semver $appsFloor)) 0 -}}
{{- fail (printf "components.workspace-manager.versionRange (%s) admits releases before %s, which take no person's token per provider instance from muster's provider Apps (%s): raise the floor to %s" $range $appsFloor (join ", " $apps.names) $appsFloor) -}}
{{- end -}}
{{- $musterRange := dig "muster" "versionRange" "" .Values.components -}}
{{- $musterFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $musterRange | default "0.0.0") "" -}}
{{- $musterAppsFloor := include "agent-platform.muster.providerAppsFloor" . -}}
{{- if lt ((semver $musterFloor).Compare (semver $musterAppsFloor)) 0 -}}
{{- fail (printf "components.muster.versionRange (%s) admits releases before %s, which keep no provider Apps (muster.providerApps) for the workspace provider instances (%s): raise the floor to %s" $musterRange $musterAppsFloor (join ", " $apps.names) $musterAppsFloor) -}}
{{- end -}}
{{- if not (dig "muster" "oauth" "mcpClient" "enabled" false (.Values.muster | default dict)) -}}
{{- fail (printf "muster keeps the provider Apps of the workspace provider instances (%s), whose sign-in is muster's OAuth client role, but muster.muster.oauth.mcpClient.enabled is off: the muster chart refuses its provider Apps without it — set it (with muster.muster.oauth.mcpClient.publicUrl, muster's public URL)" (join ", " $apps.names)) -}}
{{- end -}}
{{- end -}}
{{- if not $apps.derived -}}
{{- if not $pin.provider -}}
{{- fail (printf "workspace-manager.muster.mcpServer.auth.provider is empty and the provider instances (%s) have not exactly one of kind github to pin by default: name the instance whose App the person grants in muster" (join ", " $names)) -}}
{{- end -}}
{{- if not (has $pin.provider $names) -}}
{{- fail (printf "workspace-manager.muster.mcpServer.auth.provider %q names no provider instance of workspace-manager.providers (%s)" $pin.provider (join ", " $names)) -}}
{{- end -}}
{{- if not $pin.secretName -}}
{{- fail (printf "workspace-manager.muster.mcpServer.auth.authorizationServer.clientCredentialsSecretRef.name is empty and provider instance %s has no values.oauth.clientSecret with key client-secret to take it from: name the Secret with the App's OAuth client under client-id and client-secret, which muster reads" $pin.provider) -}}
{{- end -}}
{{- if not $pin.issuer -}}
{{- fail (printf "workspace-manager.muster.mcpServer.auth.authorizationServer.issuer is empty and provider instance %s is no github instance with values.app.id to take it from: muster files each person's grant of the instance's App under that issuer, the App's own identity; set it" $pin.provider) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $provider := include "agent-platform.muster.credentialProvider" . | fromJson -}}
{{- if and $provider (not $provider.releasable) -}}
{{- fail "workspaces.enabled with Substrate on, but muster releases no provider instance's grant: without workspace-manager.providers and workspace-manager.oauth.enabled muster's registration of the workspace-manager is pinned to no instance, so muster.muster.credentialProvider.releasable is empty, muster refuses its credential provider, and agent-manager's session bindings (/session-bindings) answer 404 — add the provider instances with oauth.enabled (muster then releases the pinned instance's grants), or name the instances in muster.muster.credentialProvider.releasable (<instance>: <its App's issuer>)" -}}
{{- end -}}
{{- $grant := dig "grant" "signingKey" dict $wm | default dict -}}
{{- if and (kindIs "map" $grant) (or $grant.name $grant.key) (not (and $wm.providers (dig "oauth" "enabled" false $wm))) -}}
{{- fail (printf "workspace-manager.grant.signingKey names %s/%s but the manager refuses a grant signing key without provider instances and oauth.enabled (--grant-signing-key needs providers and --enable-oauth): add workspace-manager.providers, or leave the key empty" (toString ($grant.name | default "")) (toString ($grant.key | default ""))) -}}
{{- end -}}
{{- with (include "agent-platform.workspaceManager.grantSigningKey" . | fromJson) -}}
{{- if .name -}}
{{- if not (regexMatch "^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$" .name) -}}
{{- fail (printf "workspace-manager.grant.signingKey.name %q is not a Secret name (a DNS subdomain)" .name) -}}
{{- end -}}
{{- if not (regexMatch "^[-._a-zA-Z0-9]+$" .key) -}}
{{- fail (printf "workspace-manager.grant.signingKey.key %q is not a Secret data key (letters, digits, -, _ and .): the entry of Secret %s holding the PEM private key" .key .name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The floors of the toolset bound to a Session (giantswarm/giantswarm#38688):
agent-manager from 2.9.0 sends the agent's toolset with the Session binding
and its chart takes muster.actorBearer; muster from 5.49.0 stores it, and an
earlier muster refuses such a binding, so a Session would not start. One line
each, no comment inside the define.
*/}}
{{- define "agent-platform.agentManager.toolsetBindingFloor" -}}2.9.0{{- end -}}
{{- define "agent-platform.muster.toolsetBindingFloor" -}}5.49.0{{- end -}}

{{/*
While muster trusts the actor JWT, agent-manager is told so
(muster.actorBearer) and binds every Session with the agent's toolset: the
floors of components.agent-manager.versionRange and components.muster.versionRange
must admit only releases that do. Emits nothing; fails naming the key and the fix.
*/}}
{{- define "agent-platform.validateToolsetBinding" -}}
{{- range $name := list "agent-manager" "muster" -}}
{{- $floor := include (printf "agent-platform.%s.toolsetBindingFloor" (ternary "agentManager" "muster" (eq $name "agent-manager"))) $ -}}
{{- $range := dig $name "versionRange" "" $.Values.components -}}
{{- $have := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $range | default "0.0.0") "" -}}
{{- if lt ((semver $have).Compare (semver $floor)) 0 -}}
{{- fail (printf "components.%s.versionRange %q admits a release below %s: while muster trusts the actor JWT (muster.muster.credentialProvider.actorBearer, on with Substrate), agent-manager 2.9.0 binds every Session with the agent's toolset and muster 5.49.0 stores it — an older agent-manager chart refuses muster.actorBearer, an older muster refuses the binding and the Session does not start; move the floor to %s or later" $name $range $floor $floor) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The first release of the kagent line (giantswarm/kagent-upstream) whose chart
takes controller.session.admission.jwt: the jwt Session admission a create
that names a volume source passes with the workspace-manager's grant. An
earlier chart ignores the block, so with the admission derived (below) every
Session naming a workspace volume would be refused: the render fails under
that floor (agent-platform.validateSessionAdmission). One line, no comment
inside the define.
*/}}
{{- define "agent-platform.kagent.sessionAdmissionFloor" -}}1.6.0{{- end -}}

{{/*
The workspace-manager's key set as kagent's controller reads it in-cluster:
http://<workspace-manager.fullnameOverride>.<the manager's namespace>.svc:<workspace-manager.service.port>/.well-known/jwks.json
— the Service the connectivity chart's policies target (its name and port as
the component chart renders them; kagent-controller-to-workspace-manager
admits the controller there), in the namespace the component's release
installs into (components.workspace-manager.targetNamespace, else the
platform's); plain http, since the controller and the manager share the
cluster and the key set is public by design. Empty while the component is off.
Usage: include "agent-platform.workspaceManager.jwksURL" .
*/}}
{{- define "agent-platform.workspaceManager.jwksURL" -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "workspace-manager") -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- $ns := dig "workspace-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- printf "http://%s.%s.svc:%v/.well-known/jwks.json" ($wm.fullnameOverride | default "workspace-manager") $ns (dig "service" "port" 8080 $wm) -}}
{{- end -}}
{{- end -}}

{{/*
kagent's jwt Session admission as the kagent release receives it
(kagent.controller.session.admission.jwt: jwksURL, issuer, audience), while
kagent and the workspace-manager are on and the manager signs grants (the
reference agent-platform.workspaceManager.grantSigningKey resolves, so the
manager serves authorize_workspace and its key set): the key set through the
manager's Service (agent-platform.workspaceManager.jwksURL), the issuer the
manager writes into every grant's iss (its base URL,
agent-platform.workspaceManager.baseURL) and the audience it writes into aud
(workspace-manager.grant.audience; kagent, the chart's default). A value the
kagent block sets for one of the three stands, the rest is derived: the kagent
chart needs all three together. With the derived key set (derived, or an own
jwksURL that names the same URL), allowHTTP is true:
the kagent chart from 1.11.5 refuses a plain http jwksURL without it, and this
one is the manager's own Service, which serves no TLS and which the controller
reaches in-cluster (kagent-controller-to-workspace-manager); an own allowHTTP
stands.
Another own jwksURL carries no derived allowHTTP, so an external key set stays
https unless the kagent block opts in itself. Emits JSON {jwksURL, issuer,
audience[, allowHTTP]}, or {}
while nothing is derived (the switch off, no grant key, kagent off): the kagent
block's own admission, if any, then reaches the release as written.
Usage: include "agent-platform.kagent.sessionAdmission" . | fromJson
*/}}
{{- define "agent-platform.kagent.sessionAdmission" -}}
{{- $out := dict -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) (include "agent-platform.componentEnabled" (dict "root" . "name" "workspace-manager")) -}}
{{- $key := include "agent-platform.workspaceManager.grantSigningKey" . | fromJson -}}
{{- if $key.name -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- $own := dig "controller" "session" "admission" "jwt" dict (.Values.kagent | default dict) | default dict -}}
{{- $derived := dict "jwksURL" (include "agent-platform.workspaceManager.jwksURL" .) "issuer" (include "agent-platform.workspaceManager.baseURL" .) "audience" (toString (dig "grant" "audience" "kagent" $wm)) -}}
{{- range $k, $v := $derived -}}
{{- $_ := set $out $k (toString (dig $k "" $own) | default $v) -}}
{{- end -}}
{{- if eq $out.jwksURL $derived.jwksURL -}}
{{- $_ := set $out "allowHTTP" (dig "allowHTTP" true $own) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
The guards of kagent's jwt Session admission, run while the kagent component
renders (agent-platform.componentDerivedValues):
- with the admission derived, the kagent range's floor is at least
  agent-platform.kagent.sessionAdmissionFloor, the first chart that takes the
  block (an earlier one ignores it and refuses every Session naming a volume);
- with the admission derived, the grants have an issuer: workspace-manager
  .oauth.baseURL or global.domain (the manager refuses to start without one);
- with the admission derived, kagent.controller.auth.userIdClaim is email, the
  claim the workspace-manager names the person by in every grant's sub, which
  the controller compares with the caller that claim derives: another claim
  admits nobody;
- without it, an own kagent.controller.session.admission.jwt names all three
  of jwksURL, issuer and audience or none: the kagent chart refuses a part.
Emits nothing; fails naming the key and the fix.
*/}}
{{- define "agent-platform.validateSessionAdmission" -}}
{{- $adm := include "agent-platform.kagent.sessionAdmission" . | fromJson -}}
{{- $kagent := .Values.kagent | default dict -}}
{{- if $adm -}}
{{- $floor := include "agent-platform.kagent.sessionAdmissionFloor" . -}}
{{- $range := dig "kagent" "versionRange" "" .Values.components -}}
{{- $have := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $range | default "0.0.0") "" -}}
{{- if lt ((semver $have).Compare (semver $floor)) 0 -}}
{{- fail (printf "components.kagent.versionRange %q admits a kagent release below %s, the first whose chart takes controller.session.admission.jwt: with workspaces.enabled and a grant signing key this chart derives kagent's jwt Session admission (the workspace-manager's key set, issuer and audience) onto the kagent release, which an earlier chart ignores, so every Session naming a workspace volume would be refused — move the floor to %s or later" $range $floor $floor) -}}
{{- end -}}
{{- if not $adm.issuer -}}
{{- fail "kagent's Session admission has no issuer: the workspace-manager names its base URL as every grant's iss and refuses to start without one — set global.domain (the base URL is then https://<workspace-manager.fullnameOverride>.<global.domain>) or workspace-manager.oauth.baseURL" -}}
{{- end -}}
{{- $claim := toString (dig "controller" "auth" "userIdClaim" "" $kagent) -}}
{{- if ne $claim "email" -}}
{{- fail (printf "kagent.controller.auth.userIdClaim is %q but the workspace-manager's grant names the person by email (its sub), which kagent's Session admission compares with the caller that claim derives, so a Session with a workspace would admit nobody: with workspaces.enabled and a grant signing key keep the chart's email" $claim) -}}
{{- end -}}
{{- else -}}
{{- $own := dig "controller" "session" "admission" "jwt" dict $kagent | default dict -}}
{{- $set := list -}}
{{- range $k := list "jwksURL" "issuer" "audience" -}}{{- if toString (dig $k "" $own) -}}{{- $set = append $set $k -}}{{- end -}}{{- end -}}
{{- if and $set (ne (len $set) 3) -}}
{{- fail (printf "kagent.controller.session.admission.jwt sets %s but the kagent chart needs jwksURL, issuer and audience together; this chart derives the three from the workspace-manager with workspaces.enabled and a grant signing key, and fills what the block leaves unset only then — set all three, or none" (join ", " $set)) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Drop the keys named by dotted `paths` from `vals` when their value is empty (an
empty string, list or map), at any depth; a parent left empty goes with it. For a component chart that stamps a
default at publish and would take an empty override as THE value (the kagent
chart's substrateWorkerPool.workerImage, harness.image), or for a HelmRelease
whose spec.values must not shadow what its valuesFrom supplies (Flux lets
spec.values win: the substrate release's atelet.imageCache.pinnedImages).
Emits JSON. Usage: include "agent-platform.omitEmpty" (dict "vals" $vals "paths" $c.omitEmptyKeys) | fromJson
*/}}
{{- define "agent-platform.omitEmpty" -}}
{{- $vals := .vals -}}
{{- range .paths -}}
{{- $vals = include "agent-platform.omitEmptyPath" (dict "vals" $vals "segs" (splitList "." .)) | fromJson -}}
{{- end -}}
{{- $vals | toJson -}}
{{- end -}}

{{/*
Drop the key at a dotted path from `vals` (components.yaml omitKeys): a
top-level key, or a nested one — `harness.snapshotStore` — whose parent then
stays only while it still holds other keys. Emits the JSON of the result.
Usage: include "agent-platform.omitPath" (dict "vals" $vals "path" "a.b")
*/}}
{{- define "agent-platform.omitPath" -}}
{{- $segs := splitList "." .path -}}
{{- $vals := .vals -}}
{{- if eq (len $segs) 1 -}}
{{- $vals = omit $vals (first $segs) -}}
{{- else if kindIs "map" (index $vals (first $segs)) -}}
{{- $child := include "agent-platform.omitPath" (dict "vals" (index $vals (first $segs)) "path" (join "." (rest $segs))) | fromJson -}}
{{- if empty $child }}{{- $vals = omit $vals (first $segs) }}{{- else }}{{- $_ := set $vals (first $segs) $child }}{{- end -}}
{{- end -}}
{{- $vals | toJson -}}
{{- end -}}

{{- define "agent-platform.omitEmptyPath" -}}
{{- $vals := .vals -}}
{{- $key := first .segs -}}
{{- if hasKey $vals $key -}}
{{- if eq (len .segs) 1 -}}
{{- if empty (index $vals $key) }}{{- $vals = omit $vals $key }}{{- end -}}
{{- else if kindIs "map" (index $vals $key) -}}
{{- $child := include "agent-platform.omitEmptyPath" (dict "vals" (index $vals $key) "segs" (rest .segs)) | fromJson -}}
{{- if empty $child }}{{- $vals = omit $vals $key }}{{- else }}{{- $_ := set $vals $key $child }}{{- end -}}
{{- end -}}
{{- end -}}
{{- $vals | toJson -}}
{{- end -}}

{{/*
Where Agent Substrate's control-plane database lives: "bundled" (the substrate
chart's single-instance StatefulSet — substrate.postgres.enabled true, or `auto`
while neither of the other two applies), "external" (an explicit
substrate.postgres.readWriteConnectionString, or substrate.postgres.connectionStringSecretRef
naming a Secret that holds one), "cnpg" (the platform's CNPG Cluster,
postgres.enabled, through the postgres.databases entry postgres.substrateDatabase
names and its derived Secret),
or "" when none of the three holds (substrate.postgres.enabled false without a
Cluster or a connection string) — which validateSubstrate refuses. The
connectivity chart carries the same helper and resolves `auto` the same way.
Usage: include "agent-platform.substrate.postgresMode" .
*/}}
{{- define "agent-platform.substrate.postgresMode" -}}
{{- $sub := .Values.substrate | default dict -}}
{{- $bundled := dig "postgres" "enabled" "auto" $sub | toString -}}
{{- if dig "postgres" "connectionString" "" $sub -}}
{{- fail "substrate.postgres.connectionString is gone from the Substrate chart since 1.6.0, which reads substrate.postgres.readWriteConnectionString (and ownerConnectionString, defaulting to it): rename the key" -}}
{{- end -}}
{{- $conn := dig "postgres" "readWriteConnectionString" "" $sub -}}
{{- $ref := dig "postgres" "connectionStringSecretRef" dict $sub -}}
{{- $refOn := or (dig "enabled" false $ref) (dig "name" "" $ref) -}}
{{- $cnpg := and .Values.postgres.enabled (ne (dig "databases" (include "agent-platform.substrate.databaseKey" .) "enabled" true .Values.postgres) false) -}}
{{- if not (has $bundled (list "auto" "true" "false")) -}}
{{- fail (printf "substrate.postgres.enabled must be one of auto, true, false (got %s)" $bundled) -}}
{{- end -}}
{{- if or (eq $bundled "true") (and (eq $bundled "auto") (not $conn) (not $cnpg) (not $refOn)) -}}bundled
{{- else if $conn -}}external
{{- else if $cnpg -}}cnpg
{{- else if $refOn -}}external
{{- end -}}
{{- end -}}

{{/*
The derived CNPG connection Secret of the Substrate database entry, as the
connectivity release names it: <postgres.clusterName>-<postgres.substrateDatabase>-app.
*/}}
{{- define "agent-platform.substrate.databaseSecretName" -}}
{{- printf "%s-%s-app" .Values.postgres.clusterName (include "agent-platform.substrate.databaseKey" .) -}}
{{- end -}}

{{/*
The postgres.databases key of Substrate's control-plane database
(postgres.substrateDatabase).
*/}}
{{- define "agent-platform.substrate.databaseKey" -}}
{{- .Values.postgres.substrateDatabase | default "substrate" -}}
{{- end -}}

{{/*
Refuse a postgres.substrateDatabase that names no postgres.databases entry.
*/}}
{{- define "agent-platform.substrate.validateDatabaseKey" -}}
{{- $key := include "agent-platform.substrate.databaseKey" . -}}
{{- if not (hasKey (.Values.postgres.databases | default dict) $key) -}}
{{- fail (printf "postgres.substrateDatabase (%s) names no postgres.databases entry: add postgres.databases.%s (name, component substrate, secretNamespaces [ate-system]) or name an existing key" $key $key) -}}
{{- end -}}
{{- end -}}

{{/*
Agent Substrate's snapshot store, kagent.harness.snapshotStore: the connectivity
chart renders the S3 bucket and the IRSA role, or the Azure account behind the
s3proxy façade (its templates/substrate/
crossplane-aws.yaml, the same helpers there); this chart derives what the two
consumers read from it — kagent.harness.snapshotLocation for the kagent release,
the role annotation of the substrate release's atelet and ate-api-server
ServiceAccounts (componentDerivedValues).
*/}}

{{/* The provider while the Crossplane block renders the store (kagent on, crossplane on): aws or capz; else "". */}}
{{- define "agent-platform.substrateStore.crossplane" -}}
{{- $xp := dig "harness" "snapshotStore" "crossplane" dict (.Values.kagent | default dict) -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) $xp.enabled -}}
{{- $xp.provider -}}
{{- end -}}
{{- end -}}

{{- define "agent-platform.substrateStore.block" -}}
{{- dig "harness" "snapshotStore" dict (.Values.kagent | default dict) | toJson -}}
{{- end -}}

{{/*
How the platform reaches the snapshot store while kagent is on: "aws" (the
Crossplane S3 bucket, IRSA), "capz" (the Crossplane Azure account behind the
s3proxy façade, Workload Identity), "s3proxy" (the façade alone, in front of an
account provisioned by hand or a lab's Azurite, an account key); "" when the
installation names its own store.
*/}}
{{- define "agent-platform.substrateStore.mode" -}}
{{- $store := include "agent-platform.substrateStore.block" . | fromJson -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "kagent") -}}
{{- if dig "crossplane" "enabled" false $store -}}{{- $store.crossplane.provider -}}
{{- else if dig "s3proxy" "enabled" false $store -}}s3proxy{{- end -}}
{{- end -}}
{{- end -}}

{{/* Truthy while the s3proxy façade renders: mode capz or s3proxy. */}}
{{- define "agent-platform.substrateStore.s3proxy" -}}
{{- $mode := include "agent-platform.substrateStore.mode" . -}}
{{- if or (eq $mode "capz") (eq $mode "s3proxy") -}}true{{- end -}}
{{- end -}}

{{/*
The Azure Blob store behind the façade, as JSON {endpoint, account, container}:
with provider capz the Crossplane block's account and container
(https://<account>.blob.core.windows.net) — an explicit s3proxy.azure.* that
disagrees fails the render; with the façade alone, s3proxy.azure.* verbatim.
*/}}
{{- define "agent-platform.substrateStore.azure" -}}
{{- $store := include "agent-platform.substrateStore.block" . | fromJson -}}
{{- $own := dig "s3proxy" "azure" dict $store -}}
{{- $az := dict "endpoint" ($own.endpoint | default "") "account" ($own.account | default "") "container" ($own.container | default "") -}}
{{- if eq (include "agent-platform.substrateStore.mode" .) "capz" -}}
{{- $capz := $store.crossplane.capz -}}
{{- $derived := dict "endpoint" (printf "https://%s.blob.core.windows.net" $capz.storageAccountName) "account" $capz.storageAccountName "container" $capz.containerName -}}
{{- range $k, $v := $derived -}}
{{- $o := index $az $k -}}
{{- if and $o (ne $o $v) -}}
{{- fail (printf "kagent.harness.snapshotStore.s3proxy.azure.%s (%s) differs from what kagent.harness.snapshotStore.crossplane.capz renders (%s): the capz block names the account and the container — leave s3proxy.azure.%s unset" $k $o $v $k) -}}
{{- end -}}
{{- end -}}
{{- $az = $derived -}}
{{- end -}}
{{- $az | toJson -}}
{{- end -}}

{{/* The snapshot location the store implies: s3://<bucket, or the container behind the façade>/<prefix> (no prefix: s3://<name>). */}}
{{- define "agent-platform.substrateStore.location" -}}
{{- $store := include "agent-platform.substrateStore.block" . | fromJson -}}
{{- $prefix := $store.prefix | default "" | trimAll "/" -}}
{{- $name := "" -}}
{{- if include "agent-platform.substrateStore.s3proxy" . -}}
{{- $name = (include "agent-platform.substrateStore.azure" . | fromJson).container -}}
{{- else -}}
{{- $name = $store.crossplane.aws.bucketName -}}
{{- end -}}
{{- printf "s3://%s" $name -}}{{- with $prefix }}/{{ . }}{{- end -}}
{{- end -}}

{{/* The façade's one name: its Deployment, Service, ServiceAccount, PodDisruptionBudget and the key-pair Secret (in the release namespace and in ate-system). */}}
{{- define "agent-platform.substrateStore.s3proxyName" -}}substrate-s3proxy{{- end -}}

{{/* The URL Substrate reaches the façade at: its Service in the release namespace, port 80. */}}
{{- define "agent-platform.substrateStore.s3proxyUrl" -}}
{{- $namespace := dig "agent-platform-connectivity" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- printf "http://%s.%s.svc:80" (include "agent-platform.substrateStore.s3proxyName" .) $namespace -}}
{{- end -}}

{{/*
The S3 environment Substrate's atelet and ate-api-server get for the façade —
the shape the substrate chart gives them for its bundled store (AWS_REGION
names the SigV4 scope only; s3proxy reads it from the request), the key pair
from the Secret in ate-system. A JSON list of EnvVars.
*/}}
{{- define "agent-platform.substrateStore.s3proxyEnv" -}}
{{- $secret := include "agent-platform.substrateStore.s3proxyName" . -}}
{{- list
  (dict "name" "AWS_REGION" "value" "us-east-1")
  (dict "name" "AWS_ENDPOINT_URL" "value" (include "agent-platform.substrateStore.s3proxyUrl" .))
  (dict "name" "AWS_S3_USE_PATH_STYLE" "value" "true")
  (dict "name" "AWS_ACCESS_KEY_ID" "valueFrom" (dict "secretKeyRef" (dict "name" $secret "key" "accessKeyId")))
  (dict "name" "AWS_SECRET_ACCESS_KEY" "valueFrom" (dict "secretKeyRef" (dict "name" $secret "key" "secretAccessKey")))
  | toJson -}}
{{- end -}}

{{/* The capz identity's name: workloadIdentity.identityName, else <containerName>-identity. */}}
{{- define "agent-platform.substrateStore.capzIdentityName" -}}
{{- $capz := (include "agent-platform.substrateStore.block" . | fromJson).crossplane.capz -}}
{{- $capz.workloadIdentity.identityName | default (printf "%s-identity" $capz.containerName) -}}
{{- end -}}

{{/* The Secret provider-kubernetes writes the identity's clientId and tenantId into; the s3proxy pods read it. */}}
{{- define "agent-platform.substrateStore.capzIdentitySecret" -}}
{{- printf "%s-azure-identity" (include "agent-platform.substrateStore.s3proxyName" .) -}}
{{- end -}}

{{/*
The store block's guards, the same in both charts: the provider, the inputs
each provider and the façade require, the account name's shape, the endpoint's
scheme, the bundled store off while the façade is on, an explicit
snapshotLocation agreeing with the derived one.
*/}}
{{- define "agent-platform.substrateStore.validate" -}}
{{- $store := include "agent-platform.substrateStore.block" . | fromJson -}}
{{- $xp := $store.crossplane | default dict -}}
{{- $mode := include "agent-platform.substrateStore.mode" . -}}
{{- if $xp.enabled -}}
{{- if not (has $xp.provider (list "aws" "capz")) -}}
{{- fail (printf "kagent.harness.snapshotStore.crossplane.provider=%s is not supported; the chart provisions the snapshot store on aws (S3 + IRSA) and capz (Azure Blob behind the s3proxy façade, Workload Identity) — elsewhere name the store in kagent.harness.snapshotLocation and its access in substrate.atelet.extraEnv / substrate.ateApiServer.extraEnv, or front an Azure Blob account provisioned by hand with kagent.harness.snapshotStore.s3proxy" $xp.provider) -}}
{{- end -}}
{{- range $k := list "providerConfigRef" "region" -}}
{{- if not (index $xp $k) -}}
{{- fail (printf "kagent.harness.snapshotStore.crossplane.%s is required when kagent.harness.snapshotStore.crossplane.enabled" $k) -}}
{{- end -}}
{{- end -}}
{{- if eq $xp.provider "aws" -}}
{{- range $k := list "bucketName" "accountId" "oidcProvider" -}}
{{- if not (index $xp.aws $k) -}}
{{- fail (printf "kagent.harness.snapshotStore.crossplane.aws.%s is required for provider aws" $k) -}}
{{- end -}}
{{- end -}}
{{- if not (regexMatch "^[0-9]{12}$" (toString $xp.aws.accountId)) -}}
{{- fail (printf "kagent.harness.snapshotStore.crossplane.aws.accountId (%v) must be the 12-digit AWS account id, quoted as a string" $xp.aws.accountId) -}}
{{- end -}}
{{- end -}}
{{- if eq $xp.provider "capz" -}}
{{- $capz := $xp.capz | default dict -}}
{{- range $k := list "storageAccountName" "containerName" "resourceGroup" "subscriptionId" -}}
{{- if not (index $capz $k) -}}
{{- fail (printf "kagent.harness.snapshotStore.crossplane.capz.%s is required for provider capz" $k) -}}
{{- end -}}
{{- end -}}
{{- if not (regexMatch "^[a-z0-9]{3,24}$" $capz.storageAccountName) -}}
{{- fail (printf "kagent.harness.snapshotStore.crossplane.capz.storageAccountName (%s) must be 3 to 24 lowercase letters and digits (an Azure storage account name)" $capz.storageAccountName) -}}
{{- end -}}
{{- if not (dig "workloadIdentity" "oidcIssuerUrl" "" $capz) -}}
{{- fail "kagent.harness.snapshotStore.crossplane.capz.workloadIdentity.oidcIssuerUrl is required for provider capz: the cluster's service-account issuer the FederatedIdentityCredential trusts (the apiserver's --service-account-issuer)" -}}
{{- end -}}
{{- if not (dig "workloadIdentity" "providerKubernetes" "providerConfigRef" "" $capz) -}}
{{- fail "kagent.harness.snapshotStore.crossplane.capz.workloadIdentity.providerKubernetes.providerConfigRef is required for provider capz: provider-kubernetes bridges the identity's generated ids into the RoleAssignment and into the s3proxy pods' Secret" -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if and $xp.enabled (eq $xp.provider "aws") (dig "s3proxy" "enabled" false $store) -}}
{{- fail "kagent.harness.snapshotStore.s3proxy.enabled is on next to crossplane.provider aws: the façade fronts Azure Blob and has no place in front of an S3 bucket — turn it off (it is on by itself with provider capz)" -}}
{{- end -}}
{{- if include "agent-platform.substrateStore.s3proxy" . -}}
{{- $az := include "agent-platform.substrateStore.azure" . | fromJson -}}
{{- $keyRef := dig "s3proxy" "azure" "accountKeySecretRef" dict $store -}}
{{- range $k := list "endpoint" "account" "container" -}}
{{- if not (index $az $k) -}}
{{- fail (printf "kagent.harness.snapshotStore.s3proxy.azure.%s is required while kagent.harness.snapshotStore.s3proxy is on without the capz Crossplane block: the façade needs the Azure Blob account it fronts" $k) -}}
{{- end -}}
{{- end -}}
{{- if eq $mode "capz" -}}
{{- if or $keyRef.name $keyRef.key -}}
{{- fail "kagent.harness.snapshotStore.s3proxy.azure.accountKeySecretRef is set next to crossplane.provider capz: the façade runs as the Workload Identity the capz block renders and never reads an account key — leave accountKeySecretRef unset" -}}
{{- end -}}
{{- else -}}
{{- if not (and $keyRef.name $keyRef.key) -}}
{{- fail "kagent.harness.snapshotStore.s3proxy.azure.accountKeySecretRef.name and .key are required while the façade runs without the capz Crossplane block: it reaches the account with an account key from that Secret (release namespace)" -}}
{{- end -}}
{{- end -}}
{{- if not (regexMatch "^https?://" $az.endpoint) -}}
{{- fail (printf "kagent.harness.snapshotStore.s3proxy.azure.endpoint (%s) must be an http(s) URL (https://<account>.blob.core.windows.net)" $az.endpoint) -}}
{{- end -}}
{{- if dig "rustfs" "enabled" false (.Values.substrate | default dict) -}}
{{- fail "substrate.rustfs.enabled is on while kagent.harness.snapshotStore.s3proxy renders the façade: the substrate chart sets the S3 environment for its bundled store and the derived one for the façade would repeat the variables — turn substrate.rustfs.enabled off" -}}
{{- end -}}
{{- end -}}
{{- if $mode -}}
{{- $explicit := dig "harness" "snapshotLocation" "" (.Values.kagent | default dict) -}}
{{- $derived := include "agent-platform.substrateStore.location" . -}}
{{- if and $explicit (ne $explicit $derived) -}}
{{- fail (printf "kagent.harness.snapshotLocation (%s) differs from the location kagent.harness.snapshotStore renders (%s): the store block names the bucket and the prefix — leave kagent.harness.snapshotLocation unset, or turn kagent.harness.snapshotStore.crossplane.enabled off and name an existing store" $explicit $derived) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/* The store's role name: aws.roleName or the bucket name. */}}
{{- define "agent-platform.substrateStore.awsRoleName" -}}
{{- $aws := (include "agent-platform.substrateStore.block" . | fromJson).crossplane.aws -}}
{{- $aws.roleName | default $aws.bucketName -}}
{{- end -}}

{{/* The role's ARN: arn:aws (arn:aws-cn in the China partition), the account, the store's role name. */}}
{{- define "agent-platform.substrateStore.awsRoleArn" -}}
{{- include "agent-platform.substrateStore.awsRoleArnOf" (dict "root" . "role" (include "agent-platform.substrateStore.awsRoleName" .)) -}}
{{- end -}}

{{/*
The ARN of a role in the store's account: arn:aws (arn:aws-cn in the China
partition), the account, the role name given.
Usage: include "agent-platform.substrateStore.awsRoleArnOf" (dict "root" $ "role" $name)
*/}}
{{- define "agent-platform.substrateStore.awsRoleArnOf" -}}
{{- $xp := (include "agent-platform.substrateStore.block" .root | fromJson).crossplane -}}
{{- if not (regexMatch "^[0-9]{12}$" (toString $xp.aws.accountId)) -}}
{{- fail (printf "kagent.harness.snapshotStore.crossplane.aws.accountId (%v) must be the 12-digit AWS account id, quoted as a string" $xp.aws.accountId) -}}
{{- end -}}
{{- $partition := "arn:aws" -}}{{- if hasPrefix "cn-" $xp.region }}{{- $partition = "arn:aws-cn" }}{{- end -}}
{{- printf "%s:iam::%s:role/%s" $partition $xp.aws.accountId .role -}}
{{- end -}}

{{/*
The platform Harness's snapshot location: kagent.harness.snapshotLocation when
set, else the one kagent.harness.snapshotStore renders (the bucket on aws, the
container behind the façade on capz or with s3proxy alone); "" with neither
(validateSubstrate refuses that with kagent on). An explicit value that
disagrees with the store's fails the render (agent-platform.substrateStore.validate).
*/}}
{{- define "agent-platform.kagent.snapshotLocation" -}}
{{- if include "agent-platform.substrateStore.mode" . -}}
{{- include "agent-platform.substrateStore.location" . -}}
{{- else -}}
{{- dig "harness" "snapshotLocation" "" (.Values.kagent | default dict) -}}
{{- end -}}
{{- end -}}

{{/*
Agent Substrate is kagent API v2's runtime: refuse the shapes that install a
kagent with nothing to run agents on, or a Substrate with nothing to start
against, at render time — and, where the render is live, a cluster that cannot
run it.
  * kagent on with substrate or substrate-crds switched off (both follow kagent
    unless switched explicitly).
  * kagent on without a snapshot location — neither kagent.harness.snapshotLocation
    nor kagent.harness.snapshotStore.crossplane: the platform Harness's
    snapshotPolicy.location is the installation's snapshot store — an S3 bucket
    on CAPA with IRSA (the store block provisions it), an S3-compatible store
    with its endpoint in substrate.atelet.extraEnv, a lab's in-cluster store —
    and has no default.
  * Substrate on with no control-plane database: neither the bundled
    StatefulSet, nor an explicit readWriteConnectionString, nor the platform's CNPG
    Cluster with the postgres.databases entry postgres.substrateDatabase names.
  * Substrate on the platform's CNPG Cluster with postgres.substrateDatabase
    naming no postgres.databases entry.
  * Substrate on under a LIVE render (the Helm CLI, --dry-run=server,
    helm-controller: .Capabilities.APIVersions then lists kinds, which Helm's
    offline set never does — so `helm template` and CI, which see no cluster,
    are never refused) of a cluster that does not serve
    certificates.k8s.io/v1beta1 PodCertificateRequest: Substrate's atelet,
    ate-api-server and atenet get their identities through it. That is
    Kubernetes 1.35 with the PodCertificateRequest, ClusterTrustBundle and
    ClusterTrustBundleProjection feature gates on kube-apiserver and
    kube-controller-manager; the same three gates on every kubelet cannot be
    seen from the apiserver, the message says so.
*/}}
{{- define "agent-platform.validateSubstrate" -}}
{{- include "agent-platform.substrateStore.validate" . -}}
{{- $kagent := eq (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) "true" -}}
{{- $substrate := eq (include "agent-platform.componentEnabled" (dict "root" . "name" "substrate")) "true" -}}
{{- $crds := eq (include "agent-platform.componentEnabled" (dict "root" . "name" "substrate-crds")) "true" -}}
{{- if and $kagent (not (and $substrate $crds)) -}}
{{- fail "components.kagent.enabled is true but components.substrate.enabled or components.substrate-crds.enabled is not: kagent API v2 runs every agent as an Agent Substrate actor and has no runtime without it; turn both on (they follow components.kagent when left unset)" -}}
{{- end -}}
{{- if and $substrate (not $crds) -}}
{{- fail "components.substrate.enabled is true but components.substrate-crds.enabled is not: the substrate chart's WorkerPool, SandboxConfig and CSIDriverConfig objects need the ate.dev CRDs the substrate-crds chart renders; turn both on" -}}
{{- end -}}
{{- if and $kagent (not (include "agent-platform.kagent.snapshotLocation" .)) -}}
{{- fail "kagent.harness.snapshotLocation is required when components.kagent is on: the Substrate snapshot location the platform Harness writes the actors' snapshots to (snapshotPolicy.location), an object-store URL such as s3://<bucket>/<prefix> — the installation's S3 bucket (IRSA on CAPA; kagent.harness.snapshotStore.crossplane provisions it and derives the location), an S3-compatible store with its endpoint and credentials in substrate.atelet.extraEnv, or a lab's in-cluster store (substrate.rustfs.enabled: true, s3://ate-snapshots/<prefix>)" -}}
{{- end -}}
{{- if $substrate -}}
{{- include "agent-platform.substrate.validateRange" . -}}
{{- end -}}
{{- if and $substrate (not (include "agent-platform.substrate.postgresMode" .)) -}}
{{- fail "components.substrate is on but Agent Substrate's control plane has no database: turn postgres.enabled on (the platform's CNPG Cluster; the postgres.databases entry postgres.substrateDatabase names renders the Database and the connectivity release derives the connection Secret), or substrate.postgres.enabled (the chart's bundled single-instance StatefulSet, a lab's shape), or name an external database in substrate.postgres.connectionStringSecretRef (a Secret in ate-system holding the connection string) or substrate.postgres.readWriteConnectionString" -}}
{{- end -}}
{{- if and $substrate (eq (include "agent-platform.substrate.postgresMode" .) "cnpg") -}}
{{- include "agent-platform.substrate.validateDatabaseKey" . -}}
{{- end -}}
{{- if and $substrate (.Capabilities.APIVersions.Has "v1/Namespace") -}}
{{- if not (.Capabilities.APIVersions.Has "certificates.k8s.io/v1beta1/PodCertificateRequest") -}}
{{- fail (printf "Agent Substrate (components.substrate) needs a cluster that serves certificates.k8s.io/v1beta1 PodCertificateRequest, and this one (Kubernetes %s) does not: Substrate's atelet, ate-api-server and atenet take their identities from it. That is Kubernetes 1.35 with the feature gates PodCertificateRequest, ClusterTrustBundle and ClusterTrustBundleProjection on kube-apiserver and kube-controller-manager — and on every kubelet, which the apiserver cannot show; turn all three on for all three components (on a Giant Swarm cluster the cluster chart's internal.advancedConfiguration.{controlPlane.apiServer,controlPlane.controllerManager,kubelet}.featureGates until giantswarm/cluster#1005 is the default) and let the nodes roll before turning kagent on" .Capabilities.KubeVersion.Version) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The floor of a Flux semver range as the roster carries it (components.<name>
.versionRange): the version of its `>=` (or `>`, `^`, `~`, `=`) term, or the
range itself when it is one exact version (a BOM pin, `1.0.0`). Empty for
a range without a floor (`0.x`, `*`, a `<` term alone) — the caller decides what
that means. Terms are separated by spaces or commas (Masterminds/semver, which
source-controller uses).
Usage: include "agent-platform.semverRangeFloor" "<range>"
*/}}
{{- define "agent-platform.semverRangeFloor" -}}
{{- $floor := "" -}}
{{- range splitList " " (. | replace "," " " | trim) -}}
{{- $term := trim . -}}
{{- if and (not $floor) $term (not (hasPrefix "<" $term)) -}}
{{- $v := $term | trimPrefix ">=" | trimPrefix ">" | trimPrefix "^" | trimPrefix "~" | trimPrefix "=" | trimPrefix "v" -}}
{{- if regexMatch "^[0-9]+\\.[0-9]+\\.[0-9]+(-[0-9A-Za-z.-]+)?$" $v -}}
{{- $floor = $v -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $floor -}}
{{- end -}}

{{/*
The Substrate release this chart pins: the floor of components.substrate
.versionRange (an exact pin is its own floor). The gVisor worker image every
kagent WorkerPool runs is derived from it (agent-platform.substrate.workerImage),
so a range without a floor fails the render here, naming the shape the range
takes (giantswarm/agent-platform#466).
Usage: include "agent-platform.substrate.pinnedVersion" $root
*/}}
{{- define "agent-platform.substrate.pinnedVersion" -}}
{{- $range := dig "substrate" "versionRange" "" .Values.components -}}
{{- $floor := include "agent-platform.semverRangeFloor" $range -}}
{{- if not $floor -}}
{{- fail (printf "components.substrate.versionRange %q has no floor: the Substrate worker image the kagent WorkerPool runs (ateom-gvisor) is derived from the range's floor, so the range is one exact version or `>=X.Y.Z <X.(Y+1).0` (giantswarm/agent-platform#466)" $range) -}}
{{- end -}}
{{- $floor -}}
{{- end -}}

{{/*
The gVisor worker image of the Substrate release this chart pins:
<substrate.image.registry>/<substrate.image.repository>/ateom-gvisor:<agent-platform.substrate.pinnedVersion>
— the registry and repository the substrate block names for the control
plane's images (a mirror sets them there, once, for both), the tag the
atelet's. Every release of the line publishes atelet and ateom-gvisor under
the same tag.
Usage: include "agent-platform.substrate.workerImage" $root
*/}}
{{- define "agent-platform.substrate.workerImage" -}}
{{- $image := dig "image" (dict) (.Values.substrate | default dict) -}}
{{- $registry := dig "registry" "gsoci.azurecr.io" $image -}}
{{- $repository := dig "repository" "giantswarm/substrate" $image -}}
{{- printf "%s/%s/ateom-gvisor:%s" (trimSuffix "/" $registry) (trimAll "/" $repository) (include "agent-platform.substrate.pinnedVersion" .) -}}
{{- end -}}

{{/*
Fail the render when components.substrate.versionRange could resolve to a
Substrate release of another runtime contract than the one it pins
(giantswarm/agent-platform#466). The worker image follows the range's FLOOR and
the atelet follows what Flux RESOLVES, so the two are one runtime only while the
range confines one contract — and the line changes one only in a minor: a patch
release is carried patches or a rebuild on the same upstream pin (the worker and
atelet bundle layout stays), a re-pin onto another upstream release is at least
a minor. So the range is an exact version (a BOM pin, `1.0.0`) or a floor with
the ceiling of its own minor, `>=X.Y.Z <X.(Y+1).0` — and no `-0` anywhere: Flux's
Masterminds semver skips every prerelease while no bound of a range carries one
and evaluates them all once one does, so `<1.1.0-0` would admit the line's dev
builds. A later patch of the pinned minor reaches the control plane and, through
ate-controller's followRelease, the workers with it (giantswarm/agent-platform#822);
a `1.1.0` never reaches either. `0.x`, `~1.0.0`, `^1.0.0`, `<1.1.0`, a `-0` bound, a
`<=` ceiling, a patch ceiling and the former `>=X.Y.Z-gs.N <X.Y.(Z+1)-0` are
refused. Called by
agent-platform.validateSubstrate while components.substrate is on.
*/}}
{{- define "agent-platform.substrate.validateRange" -}}
{{- $range := dig "substrate" "versionRange" "" .Values.components | replace "," " " | trim -}}
{{- $terms := list -}}
{{- range splitList " " $range -}}{{- if . -}}{{- $terms = append $terms . -}}{{- end -}}{{- end -}}
{{- $version := "^[0-9]+\\.[0-9]+\\.[0-9]+(-[0-9A-Za-z.-]+)?$" -}}
{{- $ok := false -}}
{{- if and (eq (len $terms) 1) (regexMatch $version (first $terms)) -}}
{{- $ok = true -}}
{{- else if and (eq (len $terms) 2) (hasPrefix ">=" (first $terms)) (hasPrefix "<" (last $terms)) (not (hasPrefix "<=" (last $terms))) -}}
{{- $floor := trimPrefix ">=" (first $terms) -}}
{{- if regexMatch $version $floor -}}
{{- $parts := splitList "." (first (splitList "-" $floor)) -}}
{{- $ok = eq (trimPrefix "<" (last $terms)) (printf "%s.%d.0" (index $parts 0) (add1 (atoi (index $parts 1)))) -}}
{{- end -}}
{{- end -}}
{{- if not $ok -}}
{{- fail (printf "components.substrate.versionRange %q does not confine one Substrate release and its patches: the kagent WorkerPool's worker image (ateom-gvisor) follows the range's floor, the atelet follows the release Flux resolves, and only a minor of the line changes the runtime contract the two share — so the range is one exact version (1.0.0) or a floor with the ceiling of its own minor and no -0 bound (>=1.0.0 <1.1.0 — a -0 anywhere makes Flux evaluate the line's dev builds against the range); a worker and an atelet of different contracts boot no golden actor (giantswarm/agent-platform#466)" $range) -}}
{{- end -}}
{{- end -}}

{{/*
The first release of the Substrate line (giantswarm/substrate, the chart
components.substrate pins) whose WorkerPool CRD carries spec.template
.topologySpreadConstraints and spec.template.podAntiAffinity — the carried patch
tracked as giantswarm/giantswarm#37797 (#37742 row 46), in every release of the
line's stable semver. agent-platform.validateWorkerPool refuses the two keys
while components.substrate.versionRange's floor is below it — every earlier
release prunes them silently — and forwards them verbatim from it on
(giantswarm/agent-platform#472). One line, no comment inside the define:
tests/verify-workerpool.py reads the value from this file.
*/}}
{{- define "agent-platform.substrate.workerPoolSpreadFloor" -}}1.0.0{{- end -}}

{{/*
The first release of the Substrate line whose WorkerPool CRD carries
spec.template.podAffinity (giantswarm/substrate#98). From it on the chart
derives the worker pods' preferred affinity to the atelet on their node
(agent-platform.substrate.workerPoolAteletAffinity) and forwards an
installation's own podAffinity; below it agent-platform.validateWorkerPool
refuses the key, which every earlier release prunes silently
(giantswarm/agent-platform#756). One line, no comment inside the define:
tests/verify-workerpool.py reads the value from this file.
*/}}
{{- define "agent-platform.substrate.workerPoolAffinityFloor" -}}1.3.0{{- end -}}

{{/*
The worker pods' preferred affinity to the atelet pod on their node, as JSON
({} while the pinned Substrate release predates
agent-platform.substrate.workerPoolAffinityFloor; a release candidate of that
release carries the field too). A worker runs sandboxes only
through its node's atelet: when the atelet DaemonSet rolls on a node without
spare CPU, a worker scheduled in the gap takes the CPU the old atelet pod
freed, and under a non-preempting atelet class the new atelet pod stays
Pending and the substrate release's upgrade times out
(giantswarm/agent-platform#756). The term, weight 100, steers a worker to a node
where an atelet pod is bound whenever one has room; a running worker is never
evicted by it. It is preferred, not required: Karpenter cannot see a
DaemonSet's pods on a node it has not launched, so a required term is
unsatisfiable on new capacity and a worker that fits no existing node would
stay Pending for good (giantswarm/agent-platform#798). Karpenter relaxes a
preferred term and launches the node. atelet's pods carry app: atelet in
components.substrate.targetNamespace.
Usage: include "agent-platform.substrate.workerPoolAteletAffinity" $root | fromJson
*/}}
{{- define "agent-platform.substrate.workerPoolAteletAffinity" -}}
{{- $pin := regexReplaceAll "-.*$" (include "agent-platform.substrate.pinnedVersion" .) "" -}}
{{- if lt ((semver $pin).Compare (semver (include "agent-platform.substrate.workerPoolAffinityFloor" .))) 0 -}}
{{- dict | toJson -}}
{{- else -}}
{{- $term := dict "topologyKey" "kubernetes.io/hostname" "namespaces" (list (dig "substrate" "targetNamespace" "ate-system" .Values.components)) "labelSelector" (dict "matchLabels" (dict "app" "atelet")) -}}
{{- dict "preferredDuringSchedulingIgnoredDuringExecution" (list (dict "weight" 100 "podAffinityTerm" $term)) | toJson -}}
{{- end -}}
{{- end -}}

{{/*
The first release of the Substrate line whose chart bounds the egress
gateway's ephemeral storage itself: atenetEgress.resources,
atenetEgress.extProc.resources and atenetEgress.drainSignal.sizeLimit
(giantswarm/substrate#255). From it on the substrate: block's keys reach the
chart; below it agent-platform.substrate.egressStoragePatch applies the same
bound as a postRenderer (giantswarm/agent-platform#880). One line, no comment
inside the define: tests/verify-substrate-egress-ephemeral-storage.py reads
the value from this file.
*/}}
{{- define "agent-platform.substrate.egressStorageFloor" -}}1.8.0{{- end -}}

{{/*
The Flux postRenderer that bounds the atenet-egress Deployment's ephemeral
storage while the pinned Substrate release predates
agent-platform.substrate.egressStorageFloor, as JSON ({} from the floor on,
and with every knob of substrate.atenetEgress null): one kustomize
strategic-merge patch on the Deployment the substrate release renders — its
containers agentgateway and ext-proc merged by name with
substrate.atenetEgress.resources and .extProc.resources, its volume
drain-signal with substrate.atenetEgress.drainSignal.sizeLimit. Those names
are upstream's canonical ate-system render, unchanged across the line's
releases, and components.substrate.versionRange confines one minor
(agent-platform.substrate.validateRange), so a Substrate patch within it keeps
them; a re-pin past the floor retires the patch and the chart renders the
bound from the forwarded keys. Kyverno's require-emptydir-requests-and-limits
skips a volume that carries a sizeLimit and otherwise requires
ephemeral-storage requests and limits on every container mounting it; the
patch sets both, as the hook Jobs do.
Usage: include "agent-platform.substrate.egressStoragePatch" $root | fromJson
*/}}
{{- define "agent-platform.substrate.egressStoragePatch" -}}
{{- $pin := regexReplaceAll "-.*$" (include "agent-platform.substrate.pinnedVersion" .) "" -}}
{{- $egress := dig "atenetEgress" dict (.Values.substrate | default dict) | default dict -}}
{{- $gateway := dig "resources" dict $egress | default dict -}}
{{- $extProc := dig "resources" dict (dig "extProc" dict $egress | default dict) | default dict -}}
{{- $sizeLimit := dig "sizeLimit" "" (dig "drainSignal" dict $egress | default dict) | default "" -}}
{{- $spec := dict -}}
{{- $containers := list -}}
{{- with $gateway }}{{ $containers = append $containers (dict "name" "agentgateway" "resources" .) }}{{ end -}}
{{- with $extProc }}{{ $containers = append $containers (dict "name" "ext-proc" "resources" .) }}{{ end -}}
{{- with $containers }}{{ $_ := set $spec "containers" . }}{{ end -}}
{{- with $sizeLimit }}{{ $_ := set $spec "volumes" (list (dict "name" "drain-signal" "emptyDir" (dict "sizeLimit" .))) }}{{ end -}}
{{- if or (not $spec) (ge ((semver $pin).Compare (semver (include "agent-platform.substrate.egressStorageFloor" .))) 0) -}}
{{- dict | toJson -}}
{{- else -}}
{{- $patch := dict "apiVersion" "apps/v1" "kind" "Deployment" "metadata" (dict "name" "atenet-egress") "spec" (dict "template" (dict "spec" $spec)) -}}
{{- dict "kustomize" (dict "patches" (list (dict "target" (dict "kind" "Deployment" "name" "atenet-egress") "patch" (toYaml $patch)))) | toJson -}}
{{- end -}}
{{- end -}}

{{/*
The first release of the kagent line whose controller-extensions image runs the
line's own migrations and accepts a person's token of any client of the issuer
(giantswarm/kagent-upstream#872, giantswarm/kagent-upstream#884). An earlier image
migrates the database without the line's tables or refuses every person's token
until an audience is listed, so with the controller on controller-extensions the
render fails under that floor (agent-platform.kagent.extensions). One line, no comment
inside the define.
*/}}
{{- define "agent-platform.kagent.extensionsFloor" -}}1.26.2{{- end -}}

{{/*
The first release of the kagent line whose controller mounts the tool images a
Session is created with (controller.sessionToolImageRepositories and
sessionToolImageEgressOrigins; giantswarm/kagent-upstream#879). One line, no
comment inside the define.
*/}}
{{- define "agent-platform.kagent.sessionToolImagesFloor" -}}1.26.0{{- end -}}

{{/*
The repositories the kagent controller admits a Session's tool images from,
while the toolchain-manager component is on and components.kagent.versionRange
is at least agent-platform.kagent.sessionToolImagesFloor (a release candidate of
it included): the registry of every toolchain source the installation offers
(toolchain-manager.sources and additionalSources), as the release's controller
values ({controller: {sessionToolImageRepositories}}, or {} otherwise). An own
kagent.controller.sessionToolImageRepositories stands. The egress origins the
toolchains need are the installation's own
(kagent.controller.sessionToolImageEgressOrigins): without them a toolchain that
names an origin is refused at the Session's start.
Usage: include "agent-platform.kagent.sessionToolImages" $root | fromJson
*/}}
{{- define "agent-platform.kagent.sessionToolImages" -}}
{{- $out := dict -}}
{{- $own := dig "controller" "sessionToolImageRepositories" list (.Values.kagent | default dict) -}}
{{- if and (not $own) (include "agent-platform.componentEnabled" (dict "root" . "name" "toolchain-manager")) (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) -}}
{{- $range := dig "kagent" "versionRange" "" .Values.components -}}
{{- $have := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $range | default "0.0.0") "" -}}
{{- if ge ((semver $have).Compare (semver (include "agent-platform.kagent.sessionToolImagesFloor" .))) 0 -}}
{{- $tm := index .Values "toolchain-manager" | default dict -}}
{{- $repositories := list -}}
{{- range concat ($tm.sources | default list) ($tm.additionalSources | default list) -}}
{{- with .registry -}}{{- $repositories = append $repositories (toString .) -}}{{- end -}}
{{- end -}}
{{- with ($repositories | uniq) -}}
{{- $_ := set $out "controller" (dict "sessionToolImageRepositories" .) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
The settings of the kagent-extensions binary, while the kagent release's
controller runs it (kagent.controller.image.repository
giantswarm/kagent/controller-extensions, which the kagent line publishes with
each release), as JSON ({env: [the binary's variables]}, or {} otherwise):
agent-platform.shape.apply adds them to kagent.controller.env after the
cluster shape has resolved its own entries.

The binary identifies callers from their bearer token alone and authorizes them
with SubjectAccessReviews (giantswarm/kagent-extensions). Its settings are the
controller's own, as the release receives them (an own value, else the derived
one), set as its KAGENT_EXTENSIONS_* variables:
- the people's issuer: controller.auth.issuer and jwksURL
  (agent-platform.kagent.authentication), a token of any of its clients, as
  the controller route's JWT policy accepts;
- the user ID claim controller.auth.userIdClaim (sub when empty), and
  controller.authorization's groupsClaim, usernamePrefix and groupsPrefix;
- the namespaces a collection read ranges over: namespaceSelector and
  includeNamespaces;
- the machine callers: workspace-manager's ServiceAccount while workspaces are
  on, with the audience of its token (serviceAccountTokenAudience), and the
  session reader, klaus-gateway's ServiceAccount while refusal notices are on.
The release keeps the kubernetes authorization mode, so the kagent chart still
grants the controller its reviews and renders its NetworkPolicy.

Fails the render, naming the key: another authorization mode than kubernetes,
another authentication mode than trusted-proxy, no issuer or key set, a
components.kagent.versionRange below agent-platform.kagent.extensionsFloor.
Usage: include "agent-platform.kagent.extensions" $root | fromJson
*/}}
{{- define "agent-platform.kagent.extensions" -}}
{{- $kagent := .Values.kagent | default dict -}}
{{- $repository := "giantswarm/kagent/controller-extensions" -}}
{{- if not (and (eq (toString (dig "controller" "image" "repository" "" $kagent)) $repository) (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent"))) -}}
{{- dict | toJson -}}
{{- else -}}
{{- $floor := include "agent-platform.kagent.extensionsFloor" . -}}
{{- $range := dig "kagent" "versionRange" "" .Values.components -}}
{{- $have := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $range | default "0.0.0") "" -}}
{{- if lt ((semver $have).Compare (semver $floor)) 0 -}}
{{- fail (printf "kagent.controller.image.repository %s needs components.kagent.versionRange at %s or later (it is %q): an earlier controller-extensions image migrates the database without the kagent line's own migrations: or run the line's own controller, kagent.controller.image.repository giantswarm/kagent/controller" $repository $floor $range) -}}
{{- end -}}
{{- $authz := merge (deepCopy (dig "controller" "authorization" dict $kagent | default dict)) ((include "agent-platform.kagent.authorization" . | fromJson).authorization | default dict) -}}
{{- $auth := merge (deepCopy (dig "controller" "auth" dict $kagent | default dict)) ((include "agent-platform.kagent.authentication" . | fromJson).auth | default dict) -}}
{{- if ne (toString (dig "mode" "" $authz)) "kubernetes" -}}
{{- fail (printf "kagent.controller.image.repository %s needs kagent.controller.authorization.mode kubernetes (it is %q): the kagent chart grants the controller its TokenReviews and SubjectAccessReviews and renders its NetworkPolicy only in that mode: or run the line's own controller, kagent.controller.image.repository giantswarm/kagent/controller" $repository (toString (dig "mode" "" $authz))) -}}
{{- end -}}
{{- if ne (toString (dig "mode" "" $auth)) "trusted-proxy" -}}
{{- fail (printf "kagent.controller.image.repository %s needs kagent.controller.auth.mode trusted-proxy (it is %q): the chart takes the binary's issuer and key set from that mode's controller.auth.issuer and jwksURL: or run the line's own controller, kagent.controller.image.repository giantswarm/kagent/controller" $repository (toString (dig "mode" "" $auth))) -}}
{{- end -}}
{{- if not (and $auth.issuer $auth.jwksURL) -}}
{{- fail (printf "kagent.controller.image.repository %s needs the people's issuer and key set: set global.identity.issuerUrl and kagent.controllerRoute.jwtAuthentication.jwks, or kagent.controller.auth.issuer and jwksURL: or run the line's own controller, kagent.controller.image.repository giantswarm/kagent/controller" $repository) -}}
{{- end -}}
{{- $callers := list -}}
{{- if and (dig "enabled" false (.Values.workspaces | default dict)) (include "agent-platform.componentEnabled" (dict "root" . "name" "workspace-manager")) -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- $sa := dig "serviceAccount" dict $wm | default dict -}}
{{- $saName := dig "name" "" $sa | default (ternary ($wm.fullnameOverride | default "workspace-manager") "default" (ne (toString (dig "create" true $sa)) "false")) -}}
{{- $wmNs := dig "workspace-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- $callers = append $callers (printf "%s/%s" $wmNs $saName) -}}
{{- end -}}
{{- /* agent-platform-operator, while agentPlatformOrganizations.enabled is on:
it lists and deletes a deleted organization's Sessions as its own
ServiceAccount (connectivity organization-erasure/kagent-sessions-rbac.yaml),
and from 0.4.0 lists whether a live organization with a ModelConfig and no
Agent has a session (its worker replica rule, agent-platform-operator#50). */ -}}
{{- if include "agent-platform.organizations.on" . -}}
{{- $op := include "agent-platform.organizations.operatorServiceAccount" . | fromJson -}}
{{- $callers = append $callers (printf "%s/%s" $op.namespace $op.name) -}}
{{- end -}}
{{- $settings := list
  (dict "name" "KAGENT_EXTENSIONS_OIDC_ISSUERS" "value" (list (dict "issuer" $auth.issuer "jwksURL" $auth.jwksURL) | toJson))
  (dict "name" "KAGENT_EXTENSIONS_OIDC_USERNAME_CLAIM" "value" (toString ($auth.userIdClaim | default "sub")))
  (dict "name" "KAGENT_EXTENSIONS_OIDC_GROUPS_CLAIM" "value" (toString (dig "groupsClaim" "" $authz)))
  (dict "name" "KAGENT_EXTENSIONS_OIDC_USERNAME_PREFIX" "value" (toString (dig "usernamePrefix" "" $authz)))
  (dict "name" "KAGENT_EXTENSIONS_OIDC_GROUPS_PREFIX" "value" (toString (dig "groupsPrefix" "" $authz)))
  (dict "name" "KAGENT_EXTENSIONS_AUTHORIZATION_MODE" "value" "kubernetes")
  (dict "name" "KAGENT_EXTENSIONS_NAMESPACE_SELECTOR" "value" (toString (dig "namespaceSelector" "" $authz)))
  (dict "name" "KAGENT_EXTENSIONS_INCLUDE_NAMESPACE" "value" (join "," (dig "includeNamespaces" list $authz)))
  (dict "name" "KAGENT_EXTENSIONS_MACHINE_AUDIENCE" "value" (include "agent-platform.kagent.tokenAudience" .))
  (dict "name" "KAGENT_EXTENSIONS_MACHINE_CALLER" "value" (join "," $callers))
  (dict "name" "KAGENT_EXTENSIONS_SESSION_READER" "value" (toString (dig "sessionReaderServiceAccount" "" $authz))) -}}
{{- dict "env" $settings | toJson -}}
{{- end -}}
{{- end -}}

{{/*
Fail the render when kagent.substrateWorkerPool.template would not reach the
cluster as written (giantswarm/agent-platform#457, #472). The kagent chart
forwards the template verbatim into WorkerPool.spec.template (toYaml), and the
WorkerPool CRD is a structural schema without preserve-unknown-fields, so what
the schema does not know is PRUNED at admission — the values look applied and
do nothing — and what it knows but cannot type fails only when helm-controller
applies the kagent release, on every installation that carries it. Named here,
at the render, instead:
  - a nodeSelector value that is not a string — the CPU generation pin written
    `karpenter.k8s.aws/instance-generation: 6` instead of "6" (nodeSelector is
    map[string]string);
  - `topologySpreadConstraints` and `podAntiAffinity`, which the Substrate line
    carries only from the release agent-platform.substrate.workerPoolSpreadFloor
    names (1.0.0), and `podAffinity`, only from
    agent-platform.substrate.workerPoolAffinityFloor (1.3.0): refused while
    components.substrate.versionRange's floor is below the key's release,
    forwarded verbatim from it on;
  - any other key WorkerPool.spec.template does not have (labels, annotations,
    nodeSelector, tolerations, priorityClassName, nodeAffinity, resources are
    the fields of the pinned line; a typo such as `nodeSelectors` would be
    pruned in silence).
*/}}
{{- define "agent-platform.validateWorkerPool" -}}
{{- $template := dig "substrateWorkerPool" "template" (dict) .Values.kagent -}}
{{- $known := list "labels" "annotations" "nodeSelector" "tolerations" "priorityClassName" "nodeAffinity" "resources" -}}
{{- $spread := include "agent-platform.substrate.workerPoolSpreadFloor" . -}}
{{- $gated := dict "topologySpreadConstraints" $spread "podAntiAffinity" $spread "podAffinity" (include "agent-platform.substrate.workerPoolAffinityFloor" .) -}}
{{- $range := dig "substrate" "versionRange" "" .Values.components -}}
{{- $floor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $range) "" -}}
{{- range $key, $value := $template -}}
{{- if hasKey $gated $key -}}
{{- $spreadFloor := get $gated $key -}}
{{- if not $spreadFloor -}}
{{- fail (printf "kagent.substrateWorkerPool.template.%s is set, but no release of the Substrate line (components.substrate.versionRange %q, giantswarm/substrate) carries WorkerPool.spec.template.%s yet: the apiserver prunes the value silently (the CRD is a structural schema), so the render refuses it until the release that carries the field is out (giantswarm/agent-platform#472, giantswarm/giantswarm#37797); remove the key" $key $range $key) -}}
{{- else if not $floor -}}
{{- fail (printf "kagent.substrateWorkerPool.template.%s needs the Substrate line at %s or later (the release whose WorkerPool CRD carries spec.template.%s), and components.substrate.versionRange %q has no floor to check that against: pin a range with a >= floor (README \"Agent Substrate\") or remove the key" $key $spreadFloor $key $range) -}}
{{- else if lt ((semver $floor).Compare (semver $spreadFloor)) 0 -}}
{{- fail (printf "kagent.substrateWorkerPool.template.%s needs the Substrate line at %s or later (the release whose WorkerPool CRD carries spec.template.%s), and components.substrate.versionRange %q has the floor %s: below it the apiserver prunes the value silently. Move components.substrate.versionRange and components.substrate-crds.versionRange to that release (with the kagent pin, README \"Agent Substrate\") or remove the key" $key $spreadFloor $key $range $floor) -}}
{{- end -}}
{{- else if not (has $key $known) -}}
{{- fail (printf "kagent.substrateWorkerPool.template.%s is not a WorkerPool.spec.template field of the Substrate line (labels, annotations, nodeSelector, tolerations, priorityClassName, nodeAffinity, resources): the apiserver would prune it silently; remove or rename the key" $key) -}}
{{- end -}}
{{- end -}}
{{- range $key, $value := dig "nodeSelector" (dict) $template -}}
{{- if not (kindIs "string" $value) -}}
{{- fail (printf "kagent.substrateWorkerPool.template.nodeSelector.%s is %v (%s), not a string: a nodeSelector value is a string (WorkerPool.spec.template.nodeSelector is map[string]string), so quote it — the CPU generation pin is karpenter.k8s.aws/instance-generation: \"6\"" $key $value (kindOf $value)) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Fail the render when a component's on/off toggle is still set the old way, inside
the component's own values block. Those blocks are additionalProperties: true, so
a leftover `enabled` key validates and is then ignored — the component silently
falls back to the `components.<name>.enabled` default, which is off for five of
the six. This turns that into a loud failure naming the new key.
Neither this chart nor the connectivity chart has a Helm dependency, so no chart
default is ever coalesced into these blocks: a legacy key can only be the
operator's and is reported whatever its value, whether the component is on or
off. (An umbrella that feeds these blocks to real Helm dependencies sees
klaus-gateway's own `enabled: true` default coalesced in while that dependency is
on and has to special-case it; nothing here does.) The removed `mcps:` block
needs no entry: the root schema rejects it already.
*/}}
{{- define "agent-platform.validateRemovedComponents" -}}
{{- /* The classic KServe controller (InferenceService, ClusterServingRuntime)
went with the classic serving path: every served model is an
LLMInferenceService on the llm-d control plane (components.kserve-llmisvc-crd,
kserve-llmisvc-resources, kserve-runtime-configs). A roster entry or a values
block for the removed components is refused, not ignored — an entry without a
chart would otherwise pass as a feature switch and silently install nothing
where the operator asked for a controller. */ -}}
{{- $found := list -}}
{{- range $name := list "kserve-crd" "kserve-resources" -}}
{{- if hasKey ($.Values.components | default dict) $name -}}
{{- $found = append $found (printf "components.%s" $name) -}}
{{- end -}}
{{- if hasKey $.Values $name -}}
{{- $found = append $found (printf "%s (the chart's values block)" $name) -}}
{{- end -}}
{{- end -}}
{{- with $found -}}
{{- fail (printf "the classic KServe controller was removed with the classic InferenceService serving path and its keys are refused: %s. The llm-d control plane is components.kserve-llmisvc-crd + components.kserve-llmisvc-resources (which renders the shared inferenceservice-config, Issuer and ClusterStorageContainer itself) + components.kserve-runtime-configs; drop the keys (see UPGRADE.md)" (join ", " .)) -}}
{{- end -}}
{{- end -}}

{{- define "agent-platform.validateRemovedBackstageKeys" -}}
{{- /* The backstage block takes any key (its schema skips properties), and a key
outside components.backstage.omitKeys reaches the backstage chart, whose schema
rejects it only when its HelmRelease installs; refused here instead. */ -}}
{{- if hasKey ($.Values.backstage | default dict) "catalogs" -}}
{{- fail "backstage.catalogs is removed (giantswarm/backstage-catalogs#705): the portal creates agents through agent-manager's MCP tools and registers no agent-deployment scaffolder template. Remove backstage.catalogs from the values." -}}
{{- end -}}
{{- end -}}

{{- define "agent-platform.validateRemovedModelKeys" -}}
{{- /* The kagent block takes any key (its schema skips properties), so a
removed key would pass the schema and be forwarded or ignored in silence;
refused here instead. */ -}}
{{- $found := list -}}
{{- range list "providers" "defaultModelConfig" "modelConfigs" -}}
{{- if hasKey ($.Values.kagent | default dict) . -}}
{{- $found = append $found (printf "kagent.%s" .) -}}
{{- end -}}
{{- end -}}
{{- with $found -}}
{{- fail (printf "%s: removed, the chart declares no model. Declare each model as a ModelConfig object (api.kagent.dev/v1alpha3) in GitOps next to the agents, and annotate the namespace's default agent-platform.giantswarm.io/is-default-model-config: \"true\"; remove the keys from the values (see UPGRADE.md)" (join ", " .)) -}}
{{- end -}}
{{- end -}}

{{- define "agent-platform.validateLegacyToggles" -}}
{{- $moved := list
      (list "agentgateway" "components.agentgateway.enabled")
      (list "valkey" "components.valkey.enabled")
      (list "kagent" "components.kagent.enabled")
      (list "klausGateway" "components.klaus-gateway.enabled")
      (list "agentSandbox" "components.agent-sandbox.enabled") -}}
{{- $found := list -}}
{{- range $moved -}}
{{- if hasKey (index $.Values (first .) | default dict) "enabled" -}}
{{- $found = append $found (printf "%s.enabled -> %s" (first .) (last .)) -}}
{{- end -}}
{{- end -}}
{{- with $found -}}
{{- fail (printf "component toggles moved into components.<name>.enabled and the old keys are ignored; move %s (see UPGRADE.md)" (join ", " .)) -}}
{{- end -}}
{{- end -}}

{{/*
The kagent line ships its CRDs as the kagent-crds chart (a roster entry the
kagent release dependsOn, the kserve-llmisvc-crd shape). kagent on with kagent-crds off
would install a controller without its CRDs and fail every kagent CR the
connectivity release renders at apply time ("no matches for kind"); refuse it
at render time instead.
*/}}
{{/*
In the one ingress topology the public /mcp reaches the agentgateway data
plane, whose only route to muster is the hostless HTTPRoute the
agent-platform-mcps release renders (viaMuster). muster on with that release
off would install a /mcp that reaches nothing; refuse it at render time.
*/}}
{{- define "agent-platform.validateMusterRoute" -}}
{{- if and (eq (include "agent-platform.componentEnabled" (dict "root" . "name" "muster")) "true")
           (ne (include "agent-platform.componentEnabled" (dict "root" . "name" "agent-platform-mcps")) "true") -}}
{{- fail "components.agent-platform-mcps.enabled must be true while muster is on: its HTTPRoute is the agentgateway data plane's only route to muster, so /mcp would reach nothing" -}}
{{- end -}}
{{- end -}}

{{- define "agent-platform.validateKagentCrds" -}}
{{- if and (eq (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) "true")
           (ne (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent-crds")) "true") -}}
{{- fail "components.kagent.enabled is true but components.kagent-crds.enabled is not: the kagent line ships its CRDs as the kagent-crds chart, which the kagent release and the connectivity release's kagent CRs depend on; turn both on" -}}
{{- end -}}
{{- end -}}

{{/*
The kagent line's charts from 1.16.0 carry no kagent-tools or kmcp subchart:
the switch would render nothing, so an installation that turns one on is told
at render time instead of running without the server it asked for.
*/}}
{{- define "agent-platform.validateKagentSubcharts" -}}
{{- range $sub := list "kagent-tools" "kmcp" -}}
{{- if dig $sub "enabled" false ($.Values.kagent | default dict) -}}
{{- fail (printf "kagent.%s.enabled is true, but the kagent line's charts from 1.16.0 carry no %s subchart; muster-registered MCP servers cover it — turn it off" $sub $sub) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Workspaces are one switch, workspaces.enabled: the workspace-manager component
follows it, and so does every later workspace piece. An explicit
components.workspace-manager.enabled that disagrees with the switch fails the
render, either way round. The switch on with the kagent component off fails
the render too: the workspaces' namespace is kagent's (every Session runs and
mounts its workspace there), so the workspace-manager release would apply its
sync ServiceAccount and Roles into a namespace that does not exist. With the
switch on, every credential of the
workspace-manager block is a Secret reference ({name, key}), never a value:
the provider instances' (any key of a provider's values named privateKey,
clientSecret, secret, token, password or apiKey, at any depth) and the grant
signing key.
*/}}
{{- define "agent-platform.validateWorkspaces" -}}
{{- $on := (.Values.workspaces | default dict).enabled | default false -}}
{{- $c := index .Values.components "workspace-manager" | default dict -}}
{{- if and (hasKey $c "enabled") (ne (toString $c.enabled) (toString $on)) -}}
{{- fail (printf "components.workspace-manager.enabled is %v but workspaces.enabled is %v: workspaces are one switch — set workspaces.enabled and leave components.workspace-manager.enabled unset" $c.enabled $on) -}}
{{- end -}}
{{- if $on -}}
{{- if ne (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) "true" -}}
{{- fail "workspaces.enabled is true but components.kagent.enabled is not: workspaces need the agents — they live in the kagent namespace, where every Session runs and mounts its workspace, and the workspace-manager's sync ServiceAccount, Roles and volumes go there; turn components.kagent.enabled on, or workspaces off" -}}
{{- end -}}
{{- include "agent-platform.workspaces.storage.validate" . -}}
{{- include "agent-platform.workspaces.substrate.validate" . -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- $names := dict -}}
{{- range $i, $p := ($wm.providers | default list) -}}
{{- if not (kindIs "map" $p) -}}
{{- fail (printf "workspace-manager.providers[%d] is not a map: a provider instance is {name, kind, values}" $i) -}}
{{- end -}}
{{- $name := toString ($p.name | default "") -}}
{{- if not (regexMatch "^[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?$" $name) -}}
{{- fail (printf "workspace-manager.providers[%d].name %q is not a DNS label: it is the name workspaces and sign-ins refer to" $i $name) -}}
{{- end -}}
{{- if hasKey $names $name -}}
{{- fail (printf "workspace-manager.providers[%d].name %q is a duplicate: every provider instance has a name of its own" $i $name) -}}
{{- end -}}
{{- $_ := set $names $name true -}}
{{- if not $p.kind -}}
{{- fail (printf "workspace-manager.providers[%d] (%s) names no kind" $i $name) -}}
{{- end -}}
{{- if eq (toString $p.kind) "gitlab" -}}
{{- $range := dig "workspace-manager" "versionRange" "" $.Values.components -}}
{{- $wmFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $range | default "0.0.0") "" -}}
{{- $gitlabFloor := include "agent-platform.workspaceManager.gitlabFloor" $ -}}
{{- if lt ((semver $wmFloor).Compare (semver $gitlabFloor)) 0 -}}
{{- fail (printf "workspace-manager.providers[%d] (%s) is of kind gitlab, which workspace-manager has from %s on, but components.workspace-manager.versionRange (%s) admits earlier releases, whose manager refuses the kind at start: raise its floor to %s" $i $name $gitlabFloor $range $gitlabFloor) -}}
{{- end -}}
{{- end -}}
{{- include "agent-platform.workspaces.secretRefs" (dict "node" ($p.values | default dict) "at" (printf "workspace-manager.providers[%d].values" $i)) -}}
{{- end -}}
{{- with dig "grant" "signingKey" dict $wm -}}
{{- include "agent-platform.workspaces.secretRef" (dict "ref" . "at" "workspace-manager.grant.signingKey") -}}
{{- end -}}
{{- include "agent-platform.workspaces.organizations.validate" . -}}
{{- end -}}
{{- end -}}

{{/*
The guards of workspaces.organizations, the Organizations whose members manage
workspaces, run while workspaces are on: each entry a map with a DNS-label name
(the Organization's) that no other entry has, and at least one member group,
each a non-empty string. The list is the one source the workspace-manager's
organizations map is derived from: an own workspace-manager.organizations fails.
The manager writes every workspace object as its own ServiceAccount, through
the component chart's Role and RoleBinding in the kagent namespace, so
workspace-manager.rbac.create false fails too. Emits nothing; fails naming the
path.
*/}}
{{- define "agent-platform.workspaces.organizations.validate" -}}
{{- $wm := index .Values "workspace-manager" | default dict -}}
{{- if $wm.organizations -}}
{{- fail "workspace-manager.organizations is set: the Organizations and their members are workspaces.organizations [{name, memberGroups, memberEmails, memberDomains}], which the meta chart forwards as the workspace-manager's organizations map; move them there and leave workspace-manager.organizations unset" -}}
{{- end -}}
{{- if eq (toString (dig "rbac" "create" true $wm)) "false" -}}
{{- fail "workspace-manager.rbac.create is false: the workspace-manager writes every Workspace, its volume and its sync Jobs in the kagent namespace as its own ServiceAccount, which only the component chart's Role and RoleBinding there allow, and members are bound to nothing; leave workspace-manager.rbac.create unset" -}}
{{- end -}}
{{- $names := dict -}}
{{- range $i, $o := ((.Values.workspaces | default dict).organizations | default list) -}}
{{- if not (kindIs "map" $o) -}}
{{- fail (printf "workspaces.organizations[%d] is not a map: an Organization is {name, memberGroups, memberEmails, memberDomains}" $i) -}}
{{- end -}}
{{- $name := toString ($o.name | default "") -}}
{{- if not (regexMatch "^[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?$" $name) -}}
{{- fail (printf "workspaces.organizations[%d].name %q is not a DNS label: it is the Organization's name, which every workspace records" $i $name) -}}
{{- end -}}
{{- if hasKey $names $name -}}
{{- fail (printf "workspaces.organizations[%d].name %q is a duplicate: an Organization is listed once, with every group of its members" $i $name) -}}
{{- end -}}
{{- $_ := set $names $name true -}}
{{- $groups := $o.memberGroups | default list -}}
{{- $emails := $o.memberEmails | default list -}}
{{- $domains := $o.memberDomains | default list -}}
{{- if not (or $groups $emails $domains) -}}
{{- fail (printf "workspaces.organizations[%d] (%s) has no members: an Organization without memberGroups, memberEmails or memberDomains has no members, so nobody could manage its workspaces; name the groups of the forwarded identity, or the verified emails or email domains, that make a caller a member, or remove the entry" $i $name) -}}
{{- end -}}
{{- range $j, $g := $groups -}}
{{- if not (toString ($g | default "")) -}}
{{- fail (printf "workspaces.organizations[%d] (%s).memberGroups[%d] is empty: a member group is a group name of the forwarded identity" $i $name $j) -}}
{{- end -}}
{{- end -}}
{{- range $j, $e := $emails -}}
{{- if not (regexMatch "^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$" (toString ($e | default ""))) -}}
{{- fail (printf "workspaces.organizations[%d] (%s).memberEmails[%d] %q is not an email address: a member email is the verified email of the forwarded identity, e.g. jane@example.com" $i $name $j (toString ($e | default ""))) -}}
{{- end -}}
{{- end -}}
{{- range $j, $d := $domains -}}
{{- if not (regexMatch "^[^@\\s]+\\.[^@\\s]+$" (toString ($d | default ""))) -}}
{{- fail (printf "workspaces.organizations[%d] (%s).memberDomains[%d] %q is not an email domain: a member domain is what follows the @ of a verified email, without the @, e.g. example.com" $i $name $j (toString ($d | default ""))) -}}
{{- end -}}
{{- end -}}
{{- if or $emails $domains -}}
{{- $range := dig "workspace-manager" "versionRange" "" $.Values.components -}}
{{- $wmFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" $range | default "0.0.0") "" -}}
{{- $emailFloor := include "agent-platform.workspaceManager.memberEmailsFloor" $ -}}
{{- if lt ((semver $wmFloor).Compare (semver $emailFloor)) 0 -}}
{{- fail (printf "workspaces.organizations[%d] (%s) names memberEmails or memberDomains, which workspace-manager has from %s on, but components.workspace-manager.versionRange (%s) admits earlier releases, whose closed values schema refuses them: raise its floor to %s, or name memberGroups only" $i $name $emailFloor $range $emailFloor) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The workspace-manager's organizations map, {<name>: {memberGroups,
memberEmails, memberDomains}}, from workspaces.organizations, as JSON, each
member field only when the entry names it; empty ({}) without Organizations.
For a validated list only.
*/}}
{{- define "agent-platform.workspaces.organizations" -}}
{{- $out := dict -}}
{{- range $o := ((.Values.workspaces | default dict).organizations | default list) -}}
{{- $members := dict -}}
{{- range $key := list "memberGroups" "memberEmails" "memberDomains" -}}
{{- $vals := list -}}
{{- range (get $o $key | default list) -}}{{- $vals = append $vals (toString .) -}}{{- end -}}
{{- with $vals -}}{{- $_ := set $members $key . -}}{{- end -}}
{{- end -}}
{{- $_ := set $out (toString $o.name) $members -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
Walk a provider's values: every key that names a credential holds a Secret
reference. Emits nothing; fails naming the path.
*/}}
{{- define "agent-platform.workspaces.secretRefs" -}}
{{- $at := .at -}}
{{- range $k, $v := .node -}}
{{- if has (lower $k) (list "privatekey" "clientsecret" "secret" "token" "password" "apikey") -}}
{{- include "agent-platform.workspaces.secretRef" (dict "ref" $v "at" (printf "%s.%s" $at $k)) -}}
{{- else if kindIs "map" $v -}}
{{- include "agent-platform.workspaces.secretRefs" (dict "node" $v "at" (printf "%s.%s" $at $k)) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "agent-platform.workspaces.secretRef" -}}
{{- $r := .ref -}}
{{- if not (and (kindIs "map" $r) $r.name $r.key (eq (len (keys $r)) 2)) -}}
{{- fail (printf "%s is a credential: it takes a Secret reference {name, key} of a Secret in the platform's namespace, never the value (the value would land in clear text in the workspace-manager HelmRelease and in Helm release storage)" .at) -}}
{{- end -}}
{{- end -}}

{{/*
The template-time guards of the workspace storage (workspaces.storage,
giantswarm/agent-platform#900), run while workspaces are on, by this chart and
by the connectivity chart alike (its templates/workspaces/_helpers.tpl carries
the same definition): the class is named; a rendered class names a preset and
the preset's required input; the azureFiles preset keeps protocol nfs, since
an SMB share does not serve git. Emits nothing; fails naming the key.
*/}}
{{- define "agent-platform.workspaces.storage.validate" -}}
{{- $storage := dig "storage" dict (.Values.workspaces | default dict) -}}
{{- if not ($storage.storageClassName | default "") -}}
{{- fail "workspaces.enabled is true but workspaces.storage.storageClassName is empty: a workspace is one read-write-many volume (bare mirrors and a directory per Session, used by git), claimed from a StorageClass that keeps POSIX semantics — Amazon EFS, Azure Files over NFS 4.1, an NFS server — which a cluster rarely has by default; leave the default, workspaces-rwx, the name every installation gives the class it provides, name a class of another name it provides, or name a new one and set workspaces.storage.storageClass.create with a preset to render it" -}}
{{- end -}}
{{- $sc := $storage.storageClass | default dict -}}
{{- if $sc.create -}}
{{- $preset := toString ($sc.preset | default "") -}}
{{- if not (has $preset (list "efs" "azureFiles" "nfs")) -}}
{{- fail (printf "workspaces.storage.storageClass.create is true but workspaces.storage.storageClass.preset is %q: the presets are efs (Amazon EFS, an access point per volume), azureFiles (Azure Files over NFS 4.1) and nfs (an NFS server through the NFS CSI driver)" $preset) -}}
{{- end -}}
{{- if and (eq $preset "efs") (not (dig "efs" "fileSystemId" "" $sc)) -}}
{{- fail "workspaces.storage.storageClass.preset is efs but workspaces.storage.storageClass.efs.fileSystemId is empty: every volume is an access point on that file system (fs-…), which the installation provides" -}}
{{- end -}}
{{- if and (eq $preset "nfs") (not (dig "nfs" "server" "" $sc)) -}}
{{- fail "workspaces.storage.storageClass.preset is nfs but workspaces.storage.storageClass.nfs.server is empty: every volume is a directory of that server's export (nfs.share)" -}}
{{- end -}}
{{- $protocol := toString (dig "parameters" "protocol" "nfs" $sc) -}}
{{- if and (eq $preset "azureFiles") (ne $protocol "nfs") -}}
{{- fail (printf "workspaces.storage.storageClass.parameters.protocol is %q on the azureFiles preset: an Azure Files share over SMB fixes every file's mode at mount and has no symbolic links, so git does not work on it; the workspaces need protocol nfs, the preset's own" $protocol) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The template-time guards of Substrate's workspace driver
(workspaces.substrate.csiDriver, giantswarm/agent-platform#888), run while
workspaces are on, by this chart and by the connectivity chart alike (its templates/workspaces/_helpers.tpl
carries the same definition): a driver without a name sets nothing; one with a
name has a controller endpoint with a port (the network policy admits it); TLS
takes Substrate's pod identity, the CSIDriverConfig's only client certificate;
a class rendered from a preset is provisioned by that driver. Emits
nothing; fails naming the key.
*/}}
{{- define "agent-platform.workspaces.substrate.validate" -}}
{{- $csi := dig "substrate" "csiDriver" dict (.Values.workspaces | default dict) -}}
{{- $name := toString ($csi.name | default "") -}}
{{- $endpoint := toString ($csi.controllerEndpoint | default "") -}}
{{- if not $name -}}
{{- if or $endpoint ($csi.nodeSocketOverride | default "") ($csi.tls | default dict).serverName -}}
{{- fail "workspaces.substrate.csiDriver.name is empty but other csiDriver keys are set: the CSIDriverConfig is named after the driver and renders only with a name; name the workspace StorageClass's provisioner, or unset the driver's keys" -}}
{{- end -}}
{{- else -}}
{{- if not (regexMatch "^(tcp|dns)://.+:[0-9]+$" $endpoint) -}}
{{- fail (printf "workspaces.substrate.csiDriver.controllerEndpoint is %q: Substrate's ate-api-server calls the driver's controller service at tcp://<host>:<port> or dns://<host>:<port>, and the network policy admits that port" $endpoint) -}}
{{- end -}}
{{- $tls := $csi.tls | default dict -}}
{{- if and $tls.enabled (not $tls.usePodIdentity) -}}
{{- fail "workspaces.substrate.csiDriver.tls.enabled is true but tls.usePodIdentity is not: Substrate presents its own pod identity to the controller endpoint, the only client certificate a CSIDriverConfig takes" -}}
{{- end -}}
{{- end -}}
{{- include "agent-platform.workspaces.csiCompanion.validate" . -}}
{{- $resolved := toString ((include "agent-platform.workspaces.csiDriver.resolved" . | fromJson).name | default "") -}}
{{- if $resolved -}}
{{- $sc := dig "storage" "storageClass" dict (.Values.workspaces | default dict) -}}
{{- $provisioner := get (dict "efs" "efs.csi.aws.com" "azureFiles" "file.csi.azure.com" "nfs" "nfs.csi.k8s.io") (toString ($sc.preset | default "")) -}}
{{- if and $sc.create (ne $provisioner $resolved) -}}
{{- fail (printf "workspaces.substrate.csiDriver.name (%s) differs from the provisioner of the workspace StorageClass rendered from preset %s (%s): Substrate mounts a workspace's volume through the driver that provisioned it" $resolved $sc.preset $provisioner) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The CSI companion's guards and the registration derived from it
(giantswarm/agent-platform#889), the connectivity chart's definitions
(templates/workspaces/_helpers.tpl there), carried here so the meta chart
refuses the same values the connectivity release would: a companion names a
preset of the driver it stands in for; a csiDriver named beside it is that
driver; the proxy admits one SPIFFE identity; the node socket is under the
kubelet's plugins directory. The resolved registration is the installation's
own csiDriver while its name is set, else the companion's driver.
*/}}
{{- define "agent-platform.workspaces.csiCompanion.enabled" -}}
{{- if and (dig "enabled" false (.Values.workspaces | default dict)) (dig "substrate" "csiCompanion" "enabled" false (.Values.workspaces | default dict)) }}true{{ end -}}
{{- end -}}

{{- define "agent-platform.workspaces.csiCompanion.presets" -}}
{{- dict
  "efs" (dict "provisioner" "efs.csi.aws.com")
  "azureFiles" (dict "provisioner" "file.csi.azure.com")
  | toJson -}}
{{- end -}}

{{- define "agent-platform.workspaces.csiCompanion.validate" -}}
{{- if include "agent-platform.workspaces.csiCompanion.enabled" . -}}
{{- $c := dig "substrate" "csiCompanion" dict (.Values.workspaces | default dict) -}}
{{- $preset := toString ($c.preset | default "") -}}
{{- $presets := include "agent-platform.workspaces.csiCompanion.presets" . | fromJson -}}
{{- if not (hasKey $presets $preset) -}}
{{- fail (printf "workspaces.substrate.csiCompanion.enabled is true but workspaces.substrate.csiCompanion.preset is %q: the companion runs the cluster's file driver for Substrate — efs (Amazon EFS, efs.csi.aws.com) or azureFiles (Azure Files over NFS, file.csi.azure.com); name the driver the workspace StorageClass is provisioned with" $preset) -}}
{{- end -}}
{{- $provisioner := (get $presets $preset).provisioner -}}
{{- $own := toString (dig "substrate" "csiDriver" "name" "" (.Values.workspaces | default dict)) -}}
{{- if and $own (ne $own $provisioner) -}}
{{- fail (printf "workspaces.substrate.csiDriver.name (%s) is not the driver of the CSI companion's preset %s (%s): Substrate registers one driver for the workspace volumes; set the companion's preset to that driver, or leave csiDriver.name empty and the registration is derived from the companion" $own $preset $provisioner) -}}
{{- end -}}
{{- $identity := toString (dig "proxy" "clientIdentity" "spiffe://cluster.local/ns/ate-system/sa/ate-api-server" $c) -}}
{{- if not (hasPrefix "spiffe://" $identity) -}}
{{- fail (printf "workspaces.substrate.csiCompanion.proxy.clientIdentity is %q: the proxy admits the client certificate that carries this SPIFFE ID, ate-api-server's (spiffe://<trust domain>/ns/<namespace>/sa/ate-api-server)" $identity) -}}
{{- end -}}
{{- $socketDir := toString (dig "node" "socketDir" "/var/lib/kubelet/plugins/agent-platform-csi-companion" $c) -}}
{{- if not (hasPrefix "/var/lib/kubelet/plugins/" $socketDir) -}}
{{- fail (printf "workspaces.substrate.csiCompanion.node.socketDir is %q: atelet reaches a node plugin's socket under /var/lib/kubelet/plugins, the directory it mounts" $socketDir) -}}
{{- end -}}
{{- if and (eq (include "agent-platform.shape.kyvernoPolicies" .) "true") (include "agent-platform.targetSecretName" .) -}}
{{- fail "workspaces.substrate.csiCompanion is on with gitops.target and Kyverno policies: the companion's PolicyExceptions must exist before its workloads, and this chart renders them on its own cluster, not the target; provide them on the target cluster and set kyvernoPolicies.enabled false, or run the companion without a target" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "agent-platform.workspaces.csiDriver.resolved" -}}
{{- $own := dig "substrate" "csiDriver" dict (.Values.workspaces | default dict) -}}
{{- if and (not ($own.name | default "")) (include "agent-platform.workspaces.csiCompanion.enabled" .) -}}
{{- $preset := toString (dig "substrate" "csiCompanion" "preset" "" (.Values.workspaces | default dict)) -}}
{{- dict "name" ((get (include "agent-platform.workspaces.csiCompanion.presets" . | fromJson) $preset | default dict).provisioner | default "") | toJson -}}
{{- else -}}
{{- $own | toJson -}}
{{- end -}}
{{- end -}}

{{/*
The api.kagent.dev line (kagent 1.3 and later) refuses a database that holds the
1.x schema: its controller exits at start-up, the kagent upgrade times out with
the line's resources half applied, and Helm's rollback cannot undo that in
either direction (giantswarm/agent-platform#857). So the render refuses the
crossing before any component moves while all three hold:
- components.kagent.versionRange admits a release of 1.3 or later (probed at
  1.3.0 and at the start and end of every minor its literals name from 1.3 on,
  so a floor, an exact pin, ~ and ^ are all read);
- the running controller (the Deployment <kagent.fullnameOverride>-controller
  in the kagent namespace) carries a 1.x helm.sh/chart label;
- the controller's database is the one it runs on: the same Secret volume
  mounted at the directory of kagent.database.postgres.urlFile (read from the
  values and from the running Deployment alike; none on either side counts as
  the same) and the same kagent.database.postgres.url (read from the values
  and from the kagent HelmRelease's current spec.values; the URL is compared,
  never printed).
The documented crossings are a fresh postgres.databases entry whose derived
Secret replaces the old one, or, with the bundled Postgres, a
kagent.database.postgres.url naming another database of the instance
(UPGRADE.md).
A first install and an installation already on the line render as before.
Skipped with gitops.target set (the lookups see the installation, not the
target); `lookup` is empty under `helm template`, where the guard is silent.
*/}}
{{- /*
agent-platform.validateKagentDatabase: the kagent chart deploys no PostgreSQL
from 1.11 on (the 1.10 chart's bundled instance is gone, and its claim with
it). kagent on a range that admits 1.11 or later therefore needs the platform's
CloudNativePG database (postgres.enabled with postgres.databases.kagent-v2) or
an own connection (kagent.database.postgres.urlFile or connectionStringSecretRef);
anything else fails the render here instead of leaving the controller without
a database.
*/ -}}
{{- define "agent-platform.validateKagentDatabase" -}}
{{- if eq (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) "true" -}}
{{- $range := index .Values.components "kagent" "versionRange" | default "" -}}
{{- $probes := list "1.11.0" "1.11.99999" -}}
{{- range (regexFindAll "[0-9]+\\.[0-9]+" $range -1) -}}
{{- if semverCompare ">=1.11.0-0" (printf "%s.0" .) -}}
{{- $probes = append (append $probes (printf "%s.0" .)) (printf "%s.99999" .) -}}
{{- end -}}
{{- end -}}
{{- $bundleless := false -}}
{{- range $probes }}{{ if semverCompare $range . }}{{ $bundleless = true }}{{ end }}{{ end -}}
{{- $pg := dig "database" "postgres" dict (.Values.kagent | default dict) -}}
{{- $platform := and .Values.postgres.enabled (ne (dig "databases" "kagent-v2" "enabled" true .Values.postgres) false) -}}
{{- if and $bundleless (not $platform) (not $pg.urlFile) (not (dig "connectionStringSecretRef" "name" "" $pg)) -}}
{{- fail (printf "components.kagent selects kagent %s, whose chart deploys no PostgreSQL: run kagent on the platform's CloudNativePG database, the supported shape (postgres.enabled: true with postgres.databases.kagent-v2, and the CloudNativePG operator on the cluster or components.cloudnative-pg.enabled: true), or point kagent.database.postgres.urlFile or connectionStringSecretRef at an own database. An installation still on the 1.10 chart's bundled PostgreSQL moves its data first: the 1.11 chart's upgrade deletes the bundled claim" $range) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
"true" while muster's pods mount Substrate certificates the cluster may not issue
yet: muster serves FetchSecret (its values' credentialProvider.enabled) and the
substrate release is not Ready on the cluster the HelmReleases live on. The
signers' ClusterTrustBundles come from the connectivity release's hook and the
certificates from the substrate release, both behind muster (connectivity
dependsOn muster, substrate dependsOn connectivity), so a fresh install and an
in-place switch of workspaces and Substrate on would wait on muster for ever
(giantswarm/agent-platform#1107). Without a cluster to read (an offline render,
a target cluster) it counts as not Ready.
Usage: include "agent-platform.muster.awaitsSubstrate" (dict "root" $root "values" $vals)
*/}}
{{- define "agent-platform.muster.awaitsSubstrate" -}}
{{- if dig "muster" "credentialProvider" "enabled" false .values -}}
{{- $ready := false -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" .root "name" "substrate")) (not (include "agent-platform.targetSecretName" .root)) -}}
{{- $release := lookup "helm.toolkit.fluxcd.io/v2" "HelmRelease" (.root.Values.gitops.namespace | default .root.Release.Namespace) (include "agent-platform.childName" (dict "root" .root "name" "substrate")) -}}
{{- range (dig "status" "conditions" list ($release | default dict)) -}}
{{- if and (eq .type "Ready") (eq .status "True") -}}{{- $ready = true -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- if not $ready -}}true{{- end -}}
{{- end -}}
{{- end -}}

{{- define "agent-platform.validateKagentLineCrossing" -}}
{{- if and (eq (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) "true") (not (include "agent-platform.targetSecretName" .)) -}}
{{- $range := index .Values.components "kagent" "versionRange" | default "" -}}
{{- $probes := list "1.3.0" -}}
{{- range (regexFindAll "[0-9]+\\.[0-9]+" $range -1) -}}
{{- if semverCompare ">=1.3.0-0" (printf "%s.0" .) -}}
{{- $probes = append (append $probes (printf "%s.0" .)) (printf "%s.99999" .) -}}
{{- end -}}
{{- end -}}
{{- $crosses := false -}}
{{- range $probes }}{{ if semverCompare $range . }}{{ $crosses = true }}{{ end }}{{ end -}}
{{- if $crosses -}}
{{- $kagent := .Values.kagent | default dict -}}
{{- $urlFile := dig "database" "postgres" "urlFile" "" $kagent -}}
{{- $ns := include "agent-platform.kagent.namespace" . -}}
{{- $name := printf "%s-controller" ($kagent.fullnameOverride | default "kagent") -}}
{{- with (lookup "apps/v1" "Deployment" $ns $name) -}}
{{- $running := regexFind "^[0-9]+\\.[0-9]+\\.[0-9]+" (trimPrefix "kagent-" (dig "metadata" "labels" "helm.sh/chart" "" .)) -}}
{{- if and $running (semverCompare "<1.3.0-0" $running) -}}
{{- $pod := .spec.template.spec -}}
{{- $mounts := list -}}
{{- range $pod.containers }}{{ $mounts = concat $mounts (.volumeMounts | default list) }}{{ end -}}
{{- $old := include "agent-platform.kagent.databaseSecret" (dict "urlFile" $urlFile "volumes" ($pod.volumes | default list) "mounts" $mounts) -}}
{{- $new := include "agent-platform.kagent.databaseSecret" (dict "urlFile" $urlFile "volumes" (dig "controller" "volumes" list $kagent) "mounts" (dig "controller" "volumeMounts" list $kagent)) -}}
{{- $release := lookup "helm.toolkit.fluxcd.io/v2" "HelmRelease" ($.Values.gitops.namespace | default $.Release.Namespace) (include "agent-platform.childName" (dict "root" $ "name" "kagent")) -}}
{{- $oldUrl := dig "spec" "values" "database" "postgres" "url" "" ($release | default dict) -}}
{{- $newUrl := dig "database" "postgres" "url" "" $kagent -}}
{{- if and (eq $old $new) (eq $oldUrl $newUrl) -}}
{{- fail (printf "components.kagent selects the api.kagent.dev line (%s) while %s/%s runs kagent %s on its 1.x database (Secret %s, kagent.database.postgres.url unchanged): the line's controller refuses the 1.x schema and the upgrade would half-apply. Cross with a fresh database: add a postgres.databases entry for it (e.g. kagent-v3, name kagent_v3, component kagent) and mount its derived Secret <postgres.clusterName>-<key>-app in kagent.controller.volumes in place of %s, or with the bundled Postgres point kagent.database.postgres.url at another database of the instance; then upgrade (UPGRADE.md). Or pin agent-platform below 4.121.0" $range $ns $name $running ($old | default "none") ($old | default "the current one")) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The Secret behind the kagent controller's database URL file: the secretName of
the Secret volume whose mount path is the directory of urlFile. Empty without a
urlFile or without such a volume.
Usage: include "agent-platform.kagent.databaseSecret" (dict "urlFile" <path> "volumes" <list> "mounts" <list>)
*/}}
{{- define "agent-platform.kagent.databaseSecret" -}}
{{- if .urlFile -}}
{{- $dir := dir .urlFile -}}
{{- $volume := "" -}}
{{- range .mounts }}{{ if eq (trimSuffix "/" .mountPath) $dir }}{{ $volume = .name }}{{ end }}{{ end -}}
{{- range .volumes }}{{ if and $volume (eq .name $volume) .secret }}{{ .secret.secretName }}{{ end }}{{ end -}}
{{- end -}}
{{- end -}}

{{/*
Key paths (dot-joined, "block.path") of credentials set INLINE in the values,
joined by ", ". Empty when none is set. Only the paths are emitted, never the
values, so the string is safe to print in a fail message.

A component's credentials belong in a pre-created Secret the component chart
references (kagent oauth2-proxy config.existingSecret, muster
oauth.server.existingSecret / storage.valkey.existingSecret, valkey
auth.usersExistingSecret, klaus-gateway slack.secretName / obo.existingSecret, model-manager, agent-manager and vm-manager
oauth.existingSecret). Set inline, they are forwarded verbatim into that
component's HelmRelease spec.values and into Helm's release storage, readable
by anyone allowed to get HelmReleases there.
*/}}
{{- define "agent-platform.inlineSecretPaths" -}}
{{- $v := .Values -}}
{{- $found := list -}}
{{- /* Fixed paths: the top-level block, then the path inside it. */ -}}
{{- $paths := list
      (list "kagent" (list "oauth2-proxy" "config" "clientSecret"))
      (list "kagent" (list "oauth2-proxy" "config" "cookieSecret"))
      (list "muster" (list "muster" "oauth" "server" "dex" "clientSecret"))
      (list "muster" (list "muster" "oauth" "server" "google" "clientSecret"))
      (list "muster" (list "muster" "oauth" "server" "registrationToken"))
      (list "muster" (list "muster" "oauth" "server" "encryptionKeyValue"))
      (list "muster" (list "muster" "oauth" "server" "storage" "valkey" "password"))
      (list "klausGateway" (list "slack" "botToken"))
      (list "klausGateway" (list "slack" "signingSecret"))
      (list "klausGateway" (list "slack" "appToken"))
      (list "klausGateway" (list "obo" "stateKey"))
      (list "klausGateway" (list "obo" "storeKey"))
      (list "model-manager" (list "oauth" "dex" "clientSecret"))
      (list "agent-manager" (list "oauth" "dex" "clientSecret"))
      (list "vm-manager" (list "oauth" "dex" "clientSecret"))
      (list "cluster-manager" (list "oauth" "dex" "clientSecret"))
      (list "workspace-manager" (list "oauth" "dex" "clientSecret")) -}}
{{- range $paths -}}
{{- $cur := index $v (first .) | default dict -}}
{{- $ok := kindIs "map" $cur -}}
{{- range (last .) -}}
{{- if and $ok (kindIs "map" $cur) (hasKey $cur .) -}}
{{- $cur = index $cur . -}}
{{- else -}}
{{- $ok = false -}}
{{- end -}}
{{- end -}}
{{- if and $ok $cur -}}
{{- $found = append $found (printf "%s.%s" (first .) (join "." (last .))) -}}
{{- end -}}
{{- end -}}
{{- /* Every valkey ACL user: valkey.auth.aclUsers.<user>.password. */ -}}
{{- range $user, $spec := (dig "valkey" "auth" "aclUsers" dict (index $v "valkey" | default dict)) -}}
{{- if and (kindIs "map" $spec) (hasKey $spec "password") (index $spec "password") -}}
{{- $found = append $found (printf "valkey.valkey.auth.aclUsers.%s.password" $user) -}}
{{- end -}}
{{- end -}}
{{- join ", " $found -}}
{{- end -}}

{{/*
gitops.forbidInlineSecrets: fail the render when a credential is set inline.
The message names the key paths only.
*/}}
{{- define "agent-platform.validateInlineSecrets" -}}
{{- if .Values.gitops.forbidInlineSecrets -}}
{{- with (include "agent-platform.inlineSecretPaths" .) -}}
{{- fail (printf "gitops.forbidInlineSecrets is true but these values carry credentials inline, which would land in clear text in the component HelmReleases and in Helm release storage: %s. Move each into a pre-created Secret and reference it (kagent.oauth2-proxy.config.existingSecret, muster.muster.oauth.server.existingSecret and .storage.valkey.existingSecret, valkey.valkey.auth.usersExistingSecret, klausGateway.slack.secretName with an empty botToken, klausGateway.obo.existingSecret, model-manager/agent-manager/vm-manager/cluster-manager/workspace-manager oauth.existingSecret), or set gitops.forbidInlineSecrets: false" .) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
gitops.forbidPinnedLoginConnector: fail the render when muster's Dex login is
pinned to one connector. Without a connectorId mcp-oauth sends no connector_id
and Dex shows its connector chooser; a pin hides every other connector of a Dex
that serves several identity providers and hands people from the others a token
without the groups their allowlists are written for. The message names the key.
*/}}
{{- define "agent-platform.validatePinnedLoginConnector" -}}
{{- if .Values.gitops.forbidPinnedLoginConnector -}}
{{- $pin := dig "muster" "oauth" "server" "dex" "connectorId" "" (.Values.muster | default dict) -}}
{{- if $pin -}}
{{- fail "gitops.forbidPinnedLoginConnector is true but muster.muster.oauth.server.dex.connectorId is set: muster would append connector_id to every Dex authorization request and the Dex connector chooser would never appear, so people from the installation's other identity providers could not sign in or would receive a token without the groups their allowlists use. Remove the key (the muster chart omits it when empty and Dex then offers every connector), or set gitops.forbidPinnedLoginConnector: false" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
muster.muster.toolsetPresets: a preset named like one of muster's built-ins
(read-only, none, full) makes the muster pod refuse to start, out of sight in
Flux. Fail the render here instead, naming the preset.
*/}}
{{- define "agent-platform.validateToolsetPresets" -}}
{{- $presets := dig "muster" "toolsetPresets" dict (.Values.muster | default dict) -}}
{{- $clash := list -}}
{{- range $name, $_ := $presets -}}
{{- if has $name (list "read-only" "none" "full") -}}
{{- $clash = append $clash $name -}}
{{- end -}}
{{- end -}}
{{- with $clash -}}
{{- fail (printf "muster.muster.toolsetPresets redefines %s, which is built into muster and cannot be redefined by configuration (the muster pod would refuse to start, naming it); rename the preset" (join ", " .)) -}}
{{- end -}}
{{- end -}}

{{/*
Name of the AgentgatewayParameters CR — defaults to release name.
*/}}
{{- define "agent-platform.parametersName" -}}
{{- default .Release.Name .Values.gateway.parameters.name -}}
{{- end -}}

{{/*
Fully-qualified name of the muster service. Single source of truth: the umbrella
pins muster.fullnameOverride (see values.yaml), which the muster sub-chart uses
verbatim for its Service name. Reading that same key here — rather than
re-deriving the sub-chart's release-name naming algorithm — guarantees the
public route's backendRef and the agent-platform-mcps musterUrl always target
the real muster Service, and turns a misconfiguration into a loud render-time
failure instead of a silent 503.
*/}}
{{/*
The platform's Valkey as a client in the release namespace reaches it:
<valkey.valkey.fullnameOverride>:<service port>, the bare Service name muster's
own storage.valkey.url uses. Usage: include "agent-platform.valkeyAddress" .
*/}}
{{- define "agent-platform.valkeyAddress" -}}
{{- $v := .Values.valkey | default dict -}}
{{- printf "%s:%v" (dig "valkey" "fullnameOverride" "muster-valkey" $v) (dig "valkey" "service" "port" 6379 $v) -}}
{{- end -}}

{{/*
The Secret the valkey release authenticates its default user from
(valkey.valkey.auth.usersExistingSecret), else the one muster reads the same
password from, else the platform Secret (global.identity.existingSecret).
Empty when none is named. Usage: include "agent-platform.valkeySecretName" .
*/}}
{{- define "agent-platform.valkeySecretName" -}}
{{- $v := .Values.valkey | default dict -}}
{{- $m := .Values.muster | default dict -}}
{{- coalesce (dig "valkey" "auth" "usersExistingSecret" "" $v) (dig "muster" "oauth" "server" "storage" "valkey" "existingSecret" "" $m) (dig "muster" "oauth" "server" "existingSecret" "" $m) (dig "identity" "existingSecret" "" (.Values.global | default dict)) | default "" -}}
{{- end -}}

{{/*
The key of the default user's password in that Secret
(valkey.valkey.auth.aclUsers.default.passwordKey, else muster's
storage.valkey.secretKeyPassword, else valkey-password).
Usage: include "agent-platform.valkeyPasswordKey" .
*/}}
{{- define "agent-platform.valkeyPasswordKey" -}}
{{- $v := .Values.valkey | default dict -}}
{{- $m := .Values.muster | default dict -}}
{{- coalesce (dig "valkey" "auth" "aclUsers" "default" "passwordKey" "" $v) (dig "muster" "oauth" "server" "storage" "valkey" "secretKeyPassword" "" $m) "valkey-password" -}}
{{- end -}}

{{- define "agent-platform.musterFullname" -}}
{{- required "muster.fullnameOverride must be set — the umbrella owns muster's public route and its backendRef targets this exact Service name" .Values.muster.fullnameOverride -}}
{{- end -}}

{{/*
Port muster listens on; defaults to 8090. nil-safe: the muster service tree is
the muster release's own, so .Values.muster.service is normally unset here.
*/}}
{{- define "agent-platform.musterServicePort" -}}
{{- dig "service" "port" 8090 (.Values.muster | default dict) -}}
{{- end -}}

{{/*
The in-cluster MCP URL of the platform's muster, the endpoint every agent's own
RemoteMCPServer targets: http://<muster Service>.<release namespace>.svc.cluster.local:<port>/mcp
while the muster component is on, "" otherwise. ONE helper, one consumer, one
name in both charts: this copy derives agent-manager's chart value muster.url
(componentDerivedValues, next to flux.helmReleaseServiceAccount); agent-manager
hands it to the Generic agent chart 1.x as muster.url on every agent it
composes and reports it in get_info. The portal sends none (create_agent takes
no muster argument), so the connectivity chart's app-config carries no muster
URL. The agent chart's own default is the same URL on a default install.
Usage: include "agent-platform.musterMcpUrl" .
*/}}
{{- define "agent-platform.musterMcpUrl" -}}
{{- if (include "agent-platform.componentEnabled" (dict "root" . "name" "muster")) -}}
{{- printf "http://%s.%s.svc.cluster.local:%v/mcp" (include "agent-platform.musterFullname" .) .Release.Namespace (include "agent-platform.musterServicePort" .) -}}
{{- end -}}
{{- end -}}

{{/*
The in-cluster gRPC target of the kagent controller through the agentgateway
data plane, the one agent-manager's session tools call as the caller:
grpc://<gateway.name>.<target namespace>.svc.cluster.local:<gateway.listeners[0].port>
while the kagent and agentgateway components are on and kagent.controllerRoute
is enabled (the GRPCRoute that carries SessionService and lf.a2a.v1.A2AService),
"" otherwise. The data plane lands with the connectivity release, in the
platform's target namespace.
Usage: include "agent-platform.kagentControllerTarget" .
*/}}
{{- define "agent-platform.kagentControllerTarget" -}}
{{- $kagentOn := include "agent-platform.componentEnabled" (dict "root" . "name" "kagent") -}}
{{- $gatewayOn := include "agent-platform.componentEnabled" (dict "root" . "name" "agentgateway") -}}
{{- if and $kagentOn $gatewayOn (dig "controllerRoute" "enabled" false (.Values.kagent | default dict)) -}}
{{- printf "grpc://%s.%s.svc.cluster.local:%v" .Values.gateway.name (include "agent-platform.targetNamespace" .) (index .Values.gateway.listeners 0).port -}}
{{- end -}}
{{- end -}}

{{/*
Merged HTTPRoute labels for a named route. The shared base
(ingress.httpRoute.labels) applies to every route; optional per-route overrides
(ingress.httpRoute.<route>.labels) win on key collision, letting a downstream
diverge one route without forking the whole block. Emits nothing when both are
empty. Usage:
  {{- include "agent-platform.httpRouteLabels" (dict "ctx" . "route" "muster") }}
*/}}
{{- define "agent-platform.httpRouteLabels" -}}
{{- $h := .ctx.Values.ingress.httpRoute -}}
{{- $merged := merge (deepCopy (dig .route "labels" dict $h)) ($h.labels | default dict) -}}
{{- with $merged }}{{- toYaml . }}{{- end -}}
{{- end -}}

{{/*
Merged HTTPRoute annotations for a named route — same precedence as
httpRouteLabels (per-route ingress.httpRoute.<route>.annotations override the
shared ingress.httpRoute.annotations). Emits nothing when both are empty.
*/}}
{{- define "agent-platform.httpRouteAnnotations" -}}
{{- $h := .ctx.Values.ingress.httpRoute -}}
{{- $merged := merge (deepCopy (dig .route "annotations" dict $h)) ($h.annotations | default dict) -}}
{{- with $merged }}{{- toYaml . }}{{- end -}}
{{- end -}}

{{/*
Cilium DNS egress rule for kube-dns and node-local-dns.
CoreDNS is labeled k8s-app: kube-dns upstream (kubeadm) and k8s-app: coredns
on Giant Swarm clusters; match both so either fleet shape resolves.
Rendered as a YAML list item; the caller must provide the surrounding `egress:` key.
*/}}
{{- define "agent-platform.dnsEgress" -}}
- toEndpoints:
    - matchLabels:
        io.kubernetes.pod.namespace: kube-system
        k8s-app: kube-dns
    - matchLabels:
        io.kubernetes.pod.namespace: kube-system
        k8s-app: coredns
    - matchLabels:
        io.kubernetes.pod.namespace: kube-system
        k8s-app: k8s-dns-node-cache
  toPorts:
    - ports:
        - port: "1053"
          protocol: UDP
        - port: "1053"
          protocol: TCP
        - port: "53"
          protocol: UDP
        - port: "53"
          protocol: TCP
{{- end -}}

{{/*
=== Cluster shape ===

The knobs that describe what the cluster can admit — Kyverno policies, the
network-policy flavor, ServiceMonitors/PodMonitors, dicebear's Envoy route
filter, the agent-sandbox pod-security policy, the model-serving cache
policies — accept `auto` (the default):
the object renders when its API group is served. `.Capabilities.APIVersions` is
the live discovery under helm-controller, the Helm CLI and `--dry-run=server`;
under `helm template` it is Helm's built-in set unless `--api-versions` names
more, so an offline render resolves every `auto` to the vanilla shape. An
explicit `true|false` (or `cilium|kubernetes`) always wins over detection.

The meta chart resolves each knob ONCE (agent-platform.shape.apply) before it
inlines a component's values, and derives the component-level copies from that
same answer, so a render can never hand one component the cilium flavor and
another the kubernetes one. The connectivity chart carries the same helpers
for renders without the meta chart; the meta chart forwards resolved values,
so the two cannot disagree on one cluster.
*/}}

{{/*
Resolve one `auto|true|false` knob to the string "true" or "false". `auto`
follows whether .api is served; an explicit boolean (or its string form from
--set-string) is returned as is; anything else fails the render naming .key.
Usage: include "agent-platform.shape.resolve" (dict "root" $ "key" "kyvernoPolicies.enabled" "value" .Values.kyvernoPolicies.enabled "api" "kyverno.io/v1")
*/}}
{{- define "agent-platform.shape.resolve" -}}
{{- $v := .value -}}
{{- if or (kindIs "invalid" $v) (and (kindIs "string" $v) (eq $v "auto")) -}}
{{- if .root.Capabilities.APIVersions.Has .api }}true{{ else }}false{{ end -}}
{{- else if kindIs "bool" $v -}}
{{- if $v }}true{{ else }}false{{ end -}}
{{- else if or (eq (toString $v) "true") (eq (toString $v) "false") -}}
{{- toString $v -}}
{{- else -}}
{{- fail (printf "%s must be one of auto, true, false (got %v)" .key $v) -}}
{{- end -}}
{{- end -}}

{{/*
kyvernoPolicies.enabled resolved: "true" when Kyverno policies render (auto:
kyverno.io/v1 served).
*/}}
{{- define "agent-platform.shape.kyvernoPolicies" -}}
{{- include "agent-platform.shape.resolve" (dict "root" . "key" "kyvernoPolicies.enabled" "value" .Values.kyvernoPolicies.enabled "api" "kyverno.io/v1") -}}
{{- end -}}

{{/*
networkPolicy.flavor resolved: "cilium" or "kubernetes" (auto: cilium when
cilium.io/v2 is served, else kubernetes).
*/}}
{{- define "agent-platform.shape.networkPolicyFlavor" -}}
{{- $f := .Values.networkPolicy.flavor -}}
{{- if or (kindIs "invalid" $f) (eq (toString $f) "auto") -}}
{{- if .Capabilities.APIVersions.Has "cilium.io/v2" }}cilium{{ else }}kubernetes{{ end -}}
{{- else if or (eq (toString $f) "cilium") (eq (toString $f) "kubernetes") -}}
{{- toString $f -}}
{{- else -}}
{{- fail (printf "networkPolicy.flavor must be one of auto, cilium, kubernetes (got %v)" $f) -}}
{{- end -}}
{{- end -}}

{{/*
global.observability.metrics.serviceMonitor.enabled resolved: "true" when the
monitor objects render (auto: monitoring.coreos.com/v1 served).
*/}}
{{- define "agent-platform.shape.serviceMonitor" -}}
{{- include "agent-platform.shape.resolve" (dict "root" . "key" "global.observability.metrics.serviceMonitor.enabled" "value" .Values.global.observability.metrics.serviceMonitor.enabled "api" "monitoring.coreos.com/v1") -}}
{{- end -}}

{{/*
dicebear.route.enabled resolved: "true" when the avatar HTTPRoute and its Envoy
Gateway HTTPRouteFilters render (auto: gateway.envoyproxy.io/v1alpha1 served).
*/}}
{{- define "agent-platform.shape.dicebearRoute" -}}
{{- include "agent-platform.shape.resolve" (dict "root" . "key" "dicebear.route.enabled" "value" (dig "route" "enabled" "auto" (.Values.dicebear | default dict)) "api" "gateway.envoyproxy.io/v1alpha1") -}}
{{- end -}}

{{/*
agentSandbox.podSecurity.enabled resolved: "true" when the agent-sandbox
pod-security ClusterPolicy renders. It is a Kyverno mutate policy, so `auto`
follows the RESOLVED kyvernoPolicies.enabled (an explicit
kyvernoPolicies.enabled: false switches it off with the rest; the
"podSecurity requires kyvernoPolicies" guard then never fires on auto).
*/}}
{{- define "agent-platform.shape.agentSandboxPodSecurity" -}}
{{- $v := dig "podSecurity" "enabled" "auto" (.Values.agentSandbox | default dict) -}}
{{- if or (kindIs "invalid" $v) (and (kindIs "string" $v) (eq $v "auto")) -}}
{{- include "agent-platform.shape.kyvernoPolicies" . -}}
{{- else -}}
{{- include "agent-platform.shape.resolve" (dict "root" . "key" "agentSandbox.podSecurity.enabled" "value" $v "api" "kyverno.io/v1") -}}
{{- end -}}
{{- end -}}

{{/*
modelServing.policies.enabled resolved: "true" when the model-serving Kyverno
cache policies render (a Kyverno mutate policy, so `auto` follows the RESOLVED
kyvernoPolicies.enabled like the agent-sandbox pod-security policy).
*/}}
{{- define "agent-platform.shape.modelServingPolicies" -}}
{{- $v := dig "policies" "enabled" "auto" (.Values.modelServing | default dict) -}}
{{- if or (kindIs "invalid" $v) (and (kindIs "string" $v) (eq $v "auto")) -}}
{{- include "agent-platform.shape.kyvernoPolicies" . -}}
{{- else -}}
{{- include "agent-platform.shape.resolve" (dict "root" . "key" "modelServing.policies.enabled" "value" $v "api" "kyverno.io/v1") -}}
{{- end -}}
{{- end -}}

{{/*
kagent.controller.vpa.enabled resolved: "true" when the connectivity chart
renders the kagent controller's VerticalPodAutoscaler. `auto` follows whether
autoscaling.k8s.io/v1 is served — the VPA CRD is not part of Kubernetes
conformance; an explicit true / false wins. The key is the connectivity
chart's (components.kagent.omitKeys holds it back from the kagent release).
*/}}
{{- define "agent-platform.shape.kagentControllerVpa" -}}
{{- $vpa := dig "controller" "vpa" nil (.Values.kagent | default dict) -}}
{{- /* The block itself is the switch: an installation that deletes
kagent.controller.vpa — or the whole kagent.controller block — has no knob to
resolve and gets no object, the same answer as enabled: false. A null set at
either layer deletes the key rather than passing it on, so this is the shape
the chart sees, and reading .enabled off it would dereference nothing. */ -}}
{{- if not (kindIs "map" $vpa) -}}
false
{{- else -}}
{{- include "agent-platform.shape.resolve" (dict "root" . "key" "kagent.controller.vpa.enabled" "value" (dig "enabled" "auto" $vpa) "api" "autoscaling.k8s.io/v1") -}}
{{- end -}}
{{- end -}}

{{/*
Write .value into .values at .path (a list of keys) when the leaf there is
`auto`. A leaf that is absent or set explicitly is left alone — explicit
overrides win, and a block an operator emptied is not re-created. Emits nothing.
Usage: include "agent-platform.shape.derive" (dict "values" $v "path" (list "muster" "networkPolicy" "flavor") "value" "cilium")
*/}}
{{- define "agent-platform.shape.derive" -}}
{{- $cur := .values -}}
{{- $ok := true -}}
{{- range (initial .path) -}}
{{- if and $ok (kindIs "map" $cur) (hasKey $cur .) -}}
{{- $cur = index $cur . -}}
{{- else -}}
{{- $ok = false -}}
{{- end -}}
{{- end -}}
{{- if and $ok (kindIs "map" $cur) -}}
{{- $leaf := last .path -}}
{{- if and (hasKey $cur $leaf) (eq (toString (index $cur $leaf)) "auto") -}}
{{- $_ := set $cur $leaf .value -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Resolve every cluster-shape knob in .values (a deep copy of .Values) IN PLACE,
once, before the component loop inlines them. Emits nothing.

The six knobs (the five above and modelServing.policies.enabled, a Kyverno
mutate policy that follows the resolved kyvernoPolicies.enabled) are written
with their resolved value. The component-level
copies the standalone overlay used to flip by hand are derived from the same
answers, but only where the leaf is left at `auto`:
  networkPolicy.flavor      -> muster.networkPolicy.flavor,
                               valkey.ciliumNetworkPolicy.enabled (cilium only)
  serviceMonitor.enabled    -> muster.muster.observability.metrics.prometheus.serviceMonitor.enabled,
                               .prometheus.prometheusRule.enabled,
                               muster.muster.observability.grafanaDashboard.enabled
                               (the dashboard ConfigMap is only picked up by the
                               same observability platform),
                               kagent.oauth2-proxy.metrics.serviceMonitor.enabled,
                               kagent.otel.traces.enabled / .logs.enabled (the
                               OTLP gateway they export to is part of that platform;
                               off while the signal has no endpoint),
                               agentgateway.monitoring.enabled (the packaging
                               chart's own gate over its controller ServiceMonitor,
                               proxy PodMonitor and dashboard ConfigMap),
                               mcp-kubernetes.mcpKubernetes.instrumentation
                               .serviceMonitor.enabled and
                               mcp-kubernetes.grafanaDashboards.enabled (its
                               monitor and the three boards it ships),
                               klausGateway.serviceMonitor.enabled (the chart's
                               own monitor; the chart takes a boolean),
                               vm-manager.serviceMonitor.enabled,
                               model-manager.serviceMonitor.enabled,
                               agent-manager.serviceMonitor.enabled,
                               cluster-manager.serviceMonitor.enabled,
                               workspace-manager.serviceMonitor.enabled,
                               kserve-llmisvc-resources.kserve.llmisvc
                               .controller.serviceMonitor.enabled,
                               substrate.metrics.podMonitor.enabled (the six
                               workloads of the Substrate control plane),
                               kagent.controller.metrics.serviceMonitor.enabled
                               (the controller's own, from the line's 1.0.2)
The OTLP destination of every exporter comes from global.observability.traces.otlp
the same way, before the gates below read it (agent-platform.shape.otlp).
Two leaves have no `auto` form and are derived directly, off only:
  valkey.valkey.metrics.podMonitor.enabled — the valkey chart's own default is
      on; written false when monitors are off, left absent otherwise so the
      fleet's HelmRelease values are unchanged. An explicit value is kept.
  kagent.controller.env[name=OTEL_EXPORTER_OTLP_HEADERS] — the tenant header
      of the OTLP gateway; dropped when both kagent OTel exporters resolve off.
  kagent.harness.env — the actors' copy: OTEL_EXPORTER_OTLP_HEADERS dropped
      the same way (agent-platform.shape.dropEnv).
  klausGateway.observability.otlpEndpoint / .otlpHeaders — emptied when
      klausGateway.observability.enabled (auto | true | false; auto follows the
      monitors) resolves off, so the klaus-gateway release exports nothing; the
      knob itself is dropped from that release by components.klaus-gateway
      .omitKeys (the chart's observability block is closed).
mcp-kubernetes' Cilium policy joins this list once mcp-kubernetes is a component.
Usage: include "agent-platform.shape.apply" (dict "root" $ "values" $shaped)
*/}}
{{- define "agent-platform.shape.apply" -}}
{{- $root := .root -}}
{{- $v := .values -}}
{{- $kyverno := eq (include "agent-platform.shape.kyvernoPolicies" $root) "true" -}}
{{- $flavor := include "agent-platform.shape.networkPolicyFlavor" $root -}}
{{- $monitors := eq (include "agent-platform.shape.serviceMonitor" $root) "true" -}}
{{- $dicebearRoute := eq (include "agent-platform.shape.dicebearRoute" $root) "true" -}}
{{- $podSecurity := eq (include "agent-platform.shape.agentSandboxPodSecurity" $root) "true" -}}
{{- $servingPolicies := eq (include "agent-platform.shape.modelServingPolicies" $root) "true" -}}
{{- $controllerVpa := eq (include "agent-platform.shape.kagentControllerVpa" $root) "true" -}}
{{- /* The knobs themselves: written resolved whatever they held. */ -}}
{{- $_ := set $v.kyvernoPolicies "enabled" $kyverno -}}
{{- $_ := set $v.networkPolicy "flavor" $flavor -}}
{{- $_ := set $v.global.observability.metrics.serviceMonitor "enabled" $monitors -}}
{{- if kindIs "map" (dig "route" nil (index $v "dicebear" | default dict)) -}}
{{- $_ := set (index $v "dicebear" "route") "enabled" $dicebearRoute -}}
{{- end -}}
{{- if kindIs "map" (dig "podSecurity" nil (index $v "agentSandbox" | default dict)) -}}
{{- $_ := set (index $v "agentSandbox" "podSecurity") "enabled" $podSecurity -}}
{{- end -}}
{{- if kindIs "map" (dig "policies" nil (index $v "modelServing" | default dict)) -}}
{{- $_ := set (index $v "modelServing" "policies") "enabled" $servingPolicies -}}
{{- end -}}
{{- if kindIs "map" (dig "controller" "vpa" nil (index $v "kagent" | default dict)) -}}
{{- $_ := set (index $v "kagent" "controller" "vpa") "enabled" $controllerVpa -}}
{{- end -}}
{{- /* substrate.postgres.enabled: `auto` resolved to the boolean the substrate
chart takes — bundled iff neither the platform Cluster nor a connection string
holds (agent-platform.substrate.postgresMode); the substrate release and the
connectivity release both read the resolved value. */ -}}
{{- if kindIs "map" (dig "postgres" nil (index $v "substrate" | default dict)) -}}
{{- $_ := set (index $v "substrate" "postgres") "enabled" (eq (include "agent-platform.substrate.postgresMode" $root) "bundled") -}}
{{- end -}}
{{- include "agent-platform.shape.otlp" (dict "root" $root "values" $v) -}}
{{- /* klausGateway.refusals.enabled: auto | true | false, resolved to the
answer agent-platform.klausGateway.refusalsOn gives, so the connectivity
release opens the gateway's refusal egress exactly while the notices run. */ -}}
{{- if kindIs "map" (index $v "klausGateway") -}}
{{- $kgv := index $v "klausGateway" -}}
{{- if not (kindIs "map" (index $kgv "refusals")) -}}{{- $_ := set $kgv "refusals" dict -}}{{- end -}}
{{- $_ := set (index $kgv "refusals") "enabled" (eq (include "agent-platform.klausGateway.refusalsOn" $root) "true") -}}
{{- end -}}
{{- /* Derived component copies: only a leaf left at auto is written. */ -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "muster" "networkPolicy" "flavor") "value" $flavor) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "valkey" "ciliumNetworkPolicy" "enabled") "value" (eq $flavor "cilium")) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "muster" "muster" "observability" "metrics" "prometheus" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "muster" "muster" "observability" "metrics" "prometheus" "prometheusRule" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "muster" "muster" "observability" "grafanaDashboard" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "kagent" "oauth2-proxy" "metrics" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "agentgateway" "monitoring" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "mcp-kubernetes" "mcpKubernetes" "instrumentation" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "mcp-kubernetes" "grafanaDashboards" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "substrate" "metrics" "podMonitor" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "kagent" "controller" "metrics" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- range $signal := list "traces" "logs" -}}
{{- $kagent := index $v "kagent" | default dict -}}
{{- $endpoint := dig "otel" $signal "endpoint" "" $kagent | default (dig "otel" "exporter" "otlp" "endpoint" "" $kagent) | toString | trim -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "kagent" "otel" $signal "enabled") "value" (and $monitors (ne $endpoint ""))) -}}
{{- end -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "vm-manager" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "model-manager" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "agent-manager" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "cluster-manager" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "workspace-manager" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "kserve-llmisvc-resources" "kserve" "llmisvc" "controller" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- /* valkey PodMonitor: the chart's own default is on, so only "off" is written. */ -}}
{{- if not $monitors -}}
{{- $metrics := dig "valkey" "metrics" nil (index $v "valkey" | default dict) -}}
{{- if kindIs "map" $metrics -}}
{{- $pm := index $metrics "podMonitor" -}}
{{- if kindIs "invalid" $pm -}}
{{- $_ := set $metrics "podMonitor" (dict "enabled" false) -}}
{{- else if and (kindIs "map" $pm) (not (hasKey $pm "enabled")) -}}
{{- $_ := set $pm "enabled" false -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- /* kagent OTLP env: the tenant header on the controller and on the Harness
(the actors) is gone when neither OTel exporter is on. */ -}}
{{- $kagent := index $v "kagent" | default dict -}}
{{- if kindIs "map" $kagent -}}
{{- $traces := eq (toString (dig "otel" "traces" "enabled" false $kagent)) "true" -}}
{{- $logs := eq (toString (dig "otel" "logs" "enabled" false $kagent)) "true" -}}
{{- $drop := list -}}
{{- if and (not $traces) (not $logs) -}}
{{- $drop = append $drop "OTEL_EXPORTER_OTLP_HEADERS" -}}
{{- end -}}
{{- include "agent-platform.shape.dropEnv" (dict "owner" (index $kagent "controller") "names" $drop) -}}
{{- include "agent-platform.shape.dropEnv" (dict "owner" (index $kagent "harness") "names" $drop) -}}
{{- end -}}
{{- /* The kagent-extensions binary's settings join the controller's env once
the shape has resolved its own entries (agent-platform.kagent.extensions); an
own entry of the same name stands and keeps its place. */ -}}
{{- with (include "agent-platform.kagent.extensions" $root | fromJson).env -}}
{{- $controller := index $v "kagent" "controller" -}}
{{- $env := index $controller "env" | default list -}}
{{- $named := list -}}
{{- range $env -}}{{- $named = append $named (toString .name) -}}{{- end -}}
{{- range . -}}
{{- if not (has .name $named) -}}{{- $env = append $env . -}}{{- end -}}
{{- end -}}
{{- $_ := set $controller "env" $env -}}
{{- end -}}
{{- /* klaus-gateway's trace export follows the same answer: the knob resolved
from auto, and the endpoint and headers the klaus-gateway chart reads emptied
when it is off (giantswarm/klaus-gateway#263). */ -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "klausGateway" "observability" "enabled") "value" $monitors) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "klausGateway" "serviceMonitor" "enabled") "value" $monitors) -}}
{{- $kgObs := dig "observability" nil (index $v "klausGateway" | default dict) -}}
{{- if and (kindIs "map" $kgObs) (hasKey $kgObs "enabled") (ne (toString (index $kgObs "enabled")) "true") -}}
{{- $_ := set $kgObs "otlpEndpoint" "" -}}
{{- $_ := set $kgObs "otlpHeaders" dict -}}
{{- end -}}
{{- end -}}

{{/*
Every OTLP exporter's destination from ONE block, global.observability.traces.otlp
(endpoint, protocol, tenant, headers), written into the component copies on the
shaped values tree where they are `auto` (agent-platform.shape.derive: a copy set
to anything else wins, and nothing fails over the difference: the same rule as
the monitor gates). Runs inside agent-platform.shape.apply before the kagent and
klaus-gateway gates read the endpoints. Emits nothing.
  endpoint -> kagent.otel.exporter.otlp.endpoint,
              muster.muster.observability.otel.endpoint,
              klausGateway.observability.otlpEndpoint, substrate.otel.endpoint,
              gateway.parameters.dataPlaneEnv[OTEL_EXPORTER_OTLP_ENDPOINT]
              (the entry dropped when the endpoint is empty); with no endpoint, every
              Substrate signal that names no endpoint of its own is turned off
              (substrate.otel.<signal>.enabled: false);
              kserve-runtime-configs.kserve.llmisvcConfigs.tracing.exporterEndpoint
              (the model pods' tracing preset; dropped when empty), then
              modelServing.networkPolicy.otlpEndpoint from that preset's
              resolved endpoint (the model pods' egress);
              <manager>.observability.otel.endpoint (model-manager,
              agent-manager, skill-manager, vm-manager, cluster-manager, workspace-manager,
              backstage);
              mcp-kubernetes.mcpKubernetes.instrumentation.otlpEndpoint as
              host:port (the scheme and path dropped, the port the scheme's or
              protocol's default when it names none), with .otlpInsecure false for an
              https:// endpoint, true otherwise, and .tracingExporter otlp,
              none when the endpoint is empty
  protocol -> kagent.otel.exporter.otlp.protocol,
              muster.muster.observability.otel.protocol,
              <manager>.observability.otel.protocol,
              mcp-kubernetes.mcpKubernetes.instrumentation.otlpProtocol,
              gateway.parameters.dataPlaneEnv[OTEL_EXPORTER_OTLP_PROTOCOL];
              empty is grpc
  tenant   -> the X-Scope-OrgID header of the exporters that send headers,
              and the pod label observability.giantswarm.io/tenant of the two
              that send none: substrate.podLabels, gateway.parameters.podLabels,
              kserve-runtime-configs.kserve.llmisvcConfigs.tracing.podLabels
              (the label dropped when the tenant is empty)
  headers  -> with the tenant: muster.muster.observability.otel.headers,
              <manager>.observability.otel.headers,
              mcp-kubernetes.mcpKubernetes.instrumentation.otlpHeaders and
              kagent.{controller,harness}.env[OTEL_EXPORTER_OTLP_HEADERS]
              ("k=v,k=v"; the entry dropped when empty),
              klausGateway.observability.otlpHeaders (a map)
klaus-gateway, Substrate and the model pods' tracing preset (vLLM, the llm-d
endpoint picker) speak gRPC only: an http/protobuf protocol fails the render
while one of them is on and would take the endpoint, naming the key to set
instead.
Usage: include "agent-platform.shape.otlp" (dict "root" $ "values" $shaped)
*/}}
{{- define "agent-platform.shape.otlp" -}}
{{- $root := .root -}}
{{- $v := .values -}}
{{- $otlp := dig "observability" "traces" "otlp" dict (index $v "global" | default dict) | default dict -}}
{{- $endpoint := dig "endpoint" "" $otlp | default "" | toString | trim -}}
{{- $protocol := dig "protocol" "" $otlp | default "grpc" | toString | lower -}}
{{- $tenant := dig "tenant" "" $otlp | default "" | toString | trim -}}
{{- $headers := dict -}}
{{- range $k, $val := (dig "headers" dict $otlp | default dict) -}}
{{- if eq (lower $k) "x-scope-orgid" -}}
{{- if and $tenant (ne (toString $val) $tenant) -}}
{{- fail (printf "global.observability.traces.otlp.headers.%s (%s) differs from global.observability.traces.otlp.tenant (%s): the tenant is one value, so set it in tenant and drop the header" $k $val $tenant) -}}
{{- end -}}
{{- if not $tenant -}}{{- $_ := set $headers $k (toString $val) -}}{{- end -}}
{{- else -}}
{{- $_ := set $headers $k (toString $val) -}}
{{- end -}}
{{- end -}}
{{- with $tenant -}}{{- $_ := set $headers "X-Scope-OrgID" . -}}{{- end -}}
{{- $pairs := list -}}
{{- range $k, $val := $headers -}}{{- $pairs = append $pairs (printf "%s=%s" $k $val) -}}{{- end -}}
{{- $joined := join "," $pairs -}}
{{- /* The gRPC-only exporters that would take an http/protobuf endpoint. */ -}}
{{- if eq $protocol "http/protobuf" -}}
{{- $grpcOnly := list -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" $root "name" "klaus-gateway")) (include "agent-platform.shape.isAuto" (dict "values" $v "path" (list "klausGateway" "observability" "otlpEndpoint"))) -}}
{{- $grpcOnly = append $grpcOnly "klausGateway.observability.otlpEndpoint" -}}
{{- end -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" $root "name" "substrate")) (include "agent-platform.shape.isAuto" (dict "values" $v "path" (list "substrate" "otel" "endpoint"))) -}}
{{- $grpcOnly = append $grpcOnly "substrate.otel.endpoint" -}}
{{- end -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" $root "name" "kserve-runtime-configs")) (include "agent-platform.shape.isAuto" (dict "values" $v "path" (list "kserve-runtime-configs" "kserve" "llmisvcConfigs" "tracing" "exporterEndpoint"))) -}}
{{- $grpcOnly = append $grpcOnly "kserve-runtime-configs.kserve.llmisvcConfigs.tracing.exporterEndpoint" -}}
{{- end -}}
{{- with $grpcOnly -}}
{{- fail (printf "global.observability.traces.otlp.protocol is http/protobuf, but these exporters speak OTLP over gRPC only and would take its endpoint: %s. Set each to the collector's gRPC endpoint" (join ", " .)) -}}
{{- end -}}
{{- end -}}
{{- /* Substrate with no endpoint: each signal that names no endpoint of its own
is turned off, where the chart would export to the SDK's localhost default. */ -}}
{{- if and (not $endpoint) (include "agent-platform.shape.isAuto" (dict "values" $v "path" (list "substrate" "otel" "endpoint"))) -}}
{{- $otel := index $v "substrate" "otel" -}}
{{- range $signal := list "traces" "metrics" "logs" -}}
{{- $cfg := index $otel $signal | default dict -}}
{{- if and (kindIs "map" $cfg) (not (dig "endpoint" "" $cfg)) (not (hasKey $cfg "enabled")) -}}
{{- $_ := set $otel $signal (merge (dict "enabled" false) $cfg) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- range $path := list (list "kagent" "otel" "exporter" "otlp" "endpoint") (list "muster" "muster" "observability" "otel" "endpoint") (list "klausGateway" "observability" "otlpEndpoint") (list "substrate" "otel" "endpoint") -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" $path "value" $endpoint) -}}
{{- end -}}
{{- range $path := list (list "kagent" "otel" "exporter" "otlp" "protocol") (list "muster" "muster" "observability" "otel" "protocol") -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" $path "value" $protocol) -}}
{{- end -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "muster" "muster" "observability" "otel" "headers") "value" $joined) -}}
{{- range $name := list "model-manager" "agent-manager" "skill-manager" "vm-manager" "cluster-manager" "workspace-manager" "backstage" -}}
{{- $base := list $name "observability" "otel" -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (append $base "endpoint") "value" $endpoint) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (append $base "protocol") "value" $protocol) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (append $base "headers") "value" $joined) -}}
{{- end -}}
{{- /* mcp-kubernetes takes host:port and a separate insecure flag, and exports
nothing unless tracingExporter names otlp. */ -}}
{{- $instr := list "mcp-kubernetes" "mcpKubernetes" "instrumentation" -}}
{{- $hostport := regexReplaceAll "^[a-zA-Z][a-zA-Z0-9+.-]*://" $endpoint "" | splitList "/" | first -}}
{{- if and $hostport (not (regexMatch ":[0-9]+$" $hostport)) -}}
{{- $hostport = printf "%s:%s" $hostport (ternary "443" (ternary "4318" "4317" (eq $protocol "http/protobuf")) (hasPrefix "https://" (lower $endpoint))) -}}
{{- end -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (append $instr "tracingExporter") "value" (ternary "otlp" "none" (ne $endpoint ""))) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (append $instr "otlpEndpoint") "value" $hostport) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (append $instr "otlpInsecure") "value" (not (hasPrefix "https://" (lower $endpoint)))) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (append $instr "otlpProtocol") "value" $protocol) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (append $instr "otlpHeaders") "value" $joined) -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "klausGateway" "observability" "otlpHeaders") "value" (deepCopy $headers)) -}}
{{- $kagent := index $v "kagent" | default dict -}}
{{- if kindIs "map" $kagent -}}
{{- range $owner := list "controller" "harness" -}}
{{- include "agent-platform.shape.deriveEnv" (dict "owner" (index $kagent $owner) "name" "OTEL_EXPORTER_OTLP_HEADERS" "value" $joined) -}}
{{- end -}}
{{- end -}}
{{- $params := dig "gateway" "parameters" nil $v -}}
{{- if kindIs "map" $params -}}
{{- include "agent-platform.shape.deriveEnv" (dict "owner" $params "key" "dataPlaneEnv" "name" "OTEL_EXPORTER_OTLP_ENDPOINT" "value" $endpoint) -}}
{{- include "agent-platform.shape.deriveEnv" (dict "owner" $params "key" "dataPlaneEnv" "name" "OTEL_EXPORTER_OTLP_PROTOCOL" "value" $protocol) -}}
{{- end -}}
{{- range $path := list (list "substrate" "podLabels") (list "gateway" "parameters" "podLabels") (list "kserve-runtime-configs" "kserve" "llmisvcConfigs" "tracing" "podLabels") -}}
{{- include "agent-platform.shape.deriveOrDrop" (dict "values" $v "path" (append $path "observability.giantswarm.io/tenant") "value" $tenant) -}}
{{- end -}}
{{- /* The model pods: the tracing preset's endpoint, then its resolved value
mirrored for the connectivity release's egress (the kserve-runtime-configs
block does not reach that release). */ -}}
{{- include "agent-platform.shape.deriveOrDrop" (dict "values" $v "path" (list "kserve-runtime-configs" "kserve" "llmisvcConfigs" "tracing" "exporterEndpoint") "value" $endpoint) -}}
{{- $presetEndpoint := dig "kserve-runtime-configs" "kserve" "llmisvcConfigs" "tracing" "exporterEndpoint" "" $v | toString | trim -}}
{{- include "agent-platform.shape.derive" (dict "values" $v "path" (list "modelServing" "networkPolicy" "otlpEndpoint") "value" $presetEndpoint) -}}
{{- end -}}

{{/*
"true" when the leaf at .path (a list of keys) in .values is `auto`, else empty.
*/}}
{{- define "agent-platform.shape.isAuto" -}}
{{- $cur := .values -}}
{{- $ok := true -}}
{{- range .path -}}
{{- if and $ok (kindIs "map" $cur) (hasKey $cur .) -}}
{{- $cur = index $cur . -}}
{{- else -}}
{{- $ok = false -}}
{{- end -}}
{{- end -}}
{{- if and $ok (eq (toString $cur) "auto") -}}true{{- end -}}
{{- end -}}

{{/*
agent-platform.shape.derive, except that an empty .value deletes the leaf
instead of writing it (a label whose value would be empty). Emits nothing.
*/}}
{{- define "agent-platform.shape.deriveOrDrop" -}}
{{- if include "agent-platform.shape.isAuto" . -}}
{{- if .value -}}
{{- include "agent-platform.shape.derive" . -}}
{{- else -}}
{{- $cur := .values -}}
{{- range (initial .path) -}}{{- $cur = index $cur . -}}{{- end -}}
{{- $_ := unset $cur (last .path) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
In the env list .owner.<key> (key: env by default), a list of name/value maps,
write .value into the entry named .name whose value is `auto`, or drop that
entry when .value is empty. An entry set to anything else wins. Emits nothing.
*/}}
{{- define "agent-platform.shape.deriveEnv" -}}
{{- $owner := .owner -}}
{{- $key := .key | default "env" -}}
{{- if and (kindIs "map" $owner) (kindIs "slice" (index $owner $key)) -}}
{{- $env := list -}}
{{- range (index $owner $key) -}}
{{- if and (kindIs "map" .) (eq (toString (index . "name")) $.name) (eq (toString (index . "value")) "auto") -}}
{{- if $.value -}}{{- $env = append $env (merge (dict "value" $.value) (omit . "value")) -}}{{- end -}}
{{- else -}}
{{- $env = append $env . -}}
{{- end -}}
{{- end -}}
{{- $_ := set $owner $key $env -}}
{{- end -}}
{{- end -}}

{{/*
Drop the entries of .owner.env (a list of name/value maps — kagent.controller.env,
kagent.harness.env) whose name is in .names, in place on the shaped values tree.
A missing owner or env, or no names, changes nothing. Emits nothing.
*/}}
{{- define "agent-platform.shape.dropEnv" -}}
{{- $owner := .owner -}}
{{- if and .names (kindIs "map" $owner) (kindIs "slice" (index $owner "env")) -}}
{{- $env := list -}}
{{- range (index $owner "env") -}}
{{- if not (and (kindIs "map" .) (has (toString (index . "name")) $.names)) -}}
{{- $env = append $env . -}}
{{- end -}}
{{- end -}}
{{- $_ := set $owner "env" $env -}}
{{- end -}}
{{- end -}}

{{/*
Placement of the stateful singletons (giantswarm/agent-platform#439): merge
scheduling.singletons.nodeSelector into, and append scheduling.singletons.tolerations
to, the scheduling knobs of the four single-replica stateful components on the
shaped values tree — muster (the muster chart's nodeSelector / tolerations),
muster-valkey (valkey.valkey.*, the upstream subchart's), the kagent controller
(kagent.controller.*) and klaus-gateway (klausGateway.*). A key a component's
own nodeSelector already holds wins (sprig merge: the destination's keys stay);
the component's own tolerations come first. Empty knobs write nothing, so the
default render is byte-identical to a chart without the block. Runs on the
$shaped copy in components.yaml after agent-platform.shape.apply, so every
component release — and the connectivity release, which sees the components'
blocks — reads the merged copies; scheduling itself is held back from the
connectivity release (components.agent-platform-connectivity.omitKeys).
Usage: include "agent-platform.scheduling.apply" (dict "values" $shaped)
*/}}
{{- define "agent-platform.scheduling.apply" -}}
{{- $v := .values -}}
{{- $singletons := dig "singletons" dict (index $v "scheduling" | default dict) -}}
{{- $selector := index $singletons "nodeSelector" | default dict -}}
{{- $tolerations := index $singletons "tolerations" | default list -}}
{{- if or $selector $tolerations -}}
{{- range $path := list (list "muster") (list "valkey" "valkey") (list "kagent" "controller") (list "klausGateway") -}}
{{- $node := $v -}}
{{- range $key := $path -}}
{{- if not (kindIs "map" (index $node $key)) }}{{ $_ := set $node $key dict }}{{ end -}}
{{- $node = index $node $key -}}
{{- end -}}
{{- with $selector }}{{ $_ := set $node "nodeSelector" (merge (deepCopy (index $node "nodeSelector" | default dict)) .) }}{{ end -}}
{{- with $tolerations }}{{ $_ := set $node "tolerations" (concat (index $node "tolerations" | default list) .) }}{{ end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The platform's one login in the managers' OAuth blocks
(giantswarm/agent-platform#484). model-manager, agent-manager, vm-manager,
cluster-manager, workspace-manager and skill-manager are OAuth resource servers
of the login muster's OAuth server names (skill-manager's block does not reach
the connectivity release: its own chart opens its identity-provider egress).
Each chart resolves its issuer, client, Secret and trusted audiences from its
own oauth block, else global.identity; what both leave unset is filled
here from muster.muster.oauth.server — oauth.dex.issuerURL from dex.issuerUrl,
oauth.dex.clientID from dex.clientId (and oauth.trustedAudiences [that client],
the charts' own default from global.identity.clientId), oauth.existingSecret
from existingSecret (key dex-client-secret, the key every manager chart and
muster read) — so an installation that names muster's login names the
managers' too, a customer's own Dex client included, which a fleet-wide
global.identity.clientId cannot carry. Defaults, not the single-source rule: a
manager's own value wins, and so does global.identity (the connectivity chart
fails the render when either disagrees with muster's). Only for the dex
provider, while muster's OAuth server is on (with it off, model-manager's oauth
is off: componentDerivedValues).
oauth.baseURL of model-manager and agent-manager is
https://<host><pathPrefix>: for
agent-manager the hostname and prefix of its route (agentManager.route.hostname,
else agentgateway.<global.domain>), for model-manager, which has no route,
agentgateway.<global.domain> and /model-manager, the resource URL it has always
announced; without a host it stays unset and the connectivity chart's guard
names the key.
Runs on the $shaped copy in components.yaml after scheduling.apply, so each
manager release and the connectivity release — its guards, the managers'
identity-provider egress — read the same filled block. Emits nothing.
Usage: include "agent-platform.identity.apply" (dict "values" $shaped)
*/}}
{{- define "agent-platform.identity.apply" -}}
{{- $v := .values -}}
{{- $global := index $v "global" | default dict -}}
{{- $identity := dig "identity" dict $global -}}
{{- $domain := dig "domain" "" $global -}}
{{- $login := include "agent-platform.identity.musterLogin" $v | fromJson -}}
{{- range $name, $wiring := dict "model-manager" "modelManager" "agent-manager" "agentManager" "vm-manager" "" "cluster-manager" "" "workspace-manager" "" "skill-manager" "" -}}
{{- $block := index $v $name -}}
{{- if and (kindIs "map" $block) (kindIs "map" (index $block "oauth")) (dig "oauth" "enabled" false $block) -}}
{{- $oauth := index $block "oauth" -}}
{{- if and $login (eq (toString (dig "provider" "dex" $oauth)) "dex") -}}
{{- if not (kindIs "map" (index $oauth "dex")) }}{{ $_ := set $oauth "dex" dict }}{{ end -}}
{{- $dex := index $oauth "dex" -}}
{{- if and $login.issuerURL (not $dex.issuerURL) (not $identity.issuerUrl) }}{{ $_ := set $dex "issuerURL" $login.issuerURL }}{{ end -}}
{{- if and $login.clientID (not $dex.clientID) (not $identity.clientId) -}}
{{- $_ := set $dex "clientID" $login.clientID -}}
{{- if not $oauth.trustedAudiences }}{{ $_ := set $oauth "trustedAudiences" (list $login.clientID) }}{{ end -}}
{{- end -}}
{{- if and $login.existingSecret (not $oauth.existingSecret) (not $dex.clientSecret) (not $identity.existingSecret) }}{{ $_ := set $oauth "existingSecret" $login.existingSecret }}{{ end -}}
{{- end -}}
{{- if and $wiring (not $oauth.baseURL) -}}
{{- $route := dig $wiring "route" dict $v -}}
{{- if eq $wiring "modelManager" }}{{ $route = dict "pathPrefix" "/model-manager" }}{{ end -}}
{{- $host := $route.hostname -}}
{{- if and (not $host) $domain }}{{ $host = printf "agentgateway.%s" $domain }}{{ end -}}
{{- if and $host $route.pathPrefix }}{{ $_ := set $oauth "baseURL" (printf "https://%s%s" $host $route.pathPrefix) }}{{ end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Whether the bundled Flux engine is on — components.flux.enabled, read through
the same helper as every other roster entry (a missing entry counts as on, as
Helm treats a dependency whose condition path is absent). Emits "true" or "".
*/}}
{{- define "agent-platform.engineEnabled" -}}
{{- include "agent-platform.componentEnabled" (dict "root" . "name" "flux") -}}
{{- end -}}

{{/*
The namespace the kagent component installs its workloads into, when it is one
the install would not otherwise create — the bundled engine's pre-install /
pre-upgrade hook creates it (templates/hooks/kagent-namespace.yaml). Empty
unless ALL of: the bundled engine is on (with the engine off this chart is a
pure renderer for a cluster's own Flux, and that cluster creates the namespace
out of band — the fleet's bases do), the kagent component is on,
kagent.namespaceOverride is set, and it differs from the namespace the platform
HelmReleases target (gitops.targetNamespace, else the release namespace — that
one helm-controller creates itself, install.createNamespace).
Why a hook, and why here: the kagent chart renders its objects into
kagent.namespaceOverride while its HelmRelease targets the platform namespace,
so helm-controller's createNamespace never creates `kagent`; the one chart
object that does — the connectivity chart's Namespace — sits in a release that
dependsOn kagent. A first install on a cluster without the namespace failed
every kagent attempt with `namespaces "kagent" not found` until the retries
were exhausted, and everything behind kagent waited
(giantswarm/agent-platform#306). The Namespace is deliberately NOT an object of
this release: the connectivity release renders and tracks it (adopting the
existing one on its install), and two Helm releases must never track one
object — a second tracked owner flips meta.helm.sh/release-name and the other
release's next upgrade fails on ownership metadata. A hook resource is not a
release object, and a Job that runs `kubectl create namespace` when it is
missing leaves exactly what the bases and the lab leave: a bare Namespace the
connectivity release adopts.
Usage: include "agent-platform.kagent.hookNamespace" .
*/}}
{{- define "agent-platform.kagent.hookNamespace" -}}
{{- if and (eq (include "agent-platform.engineEnabled" .) "true") (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) -}}
{{- $ns := dig "namespaceOverride" "" (.Values.kagent | default dict) -}}
{{- $target := include "agent-platform.targetNamespace" . -}}
{{- if and $ns (ne $ns $target) }}{{ $ns }}{{ end -}}
{{- end -}}
{{- end -}}

{{/*
The namespace the kagent component's objects live in: kagent.namespaceOverride,
else the namespace the platform HelmReleases target (gitops.targetNamespace,
else the release namespace).
Usage: include "agent-platform.kagent.namespace" .
*/}}
{{- define "agent-platform.kagent.namespace" -}}
{{- dig "namespaceOverride" "" (.Values.kagent | default dict) | default (include "agent-platform.targetNamespace" .) -}}
{{- end -}}

{{/*
The first release of the workspace-manager line (giantswarm/workspace-manager)
whose chart takes kagent.address, kagent.namespace and kagent.port (the session
directories' cleanup from kagent's record of each Session's last turn); every
earlier release's closed values schema refuses a kagent block. From it on
(a release candidate of it included) the chart derives
workspace-manager.kagent.address (agent-platform.componentDerivedValues). One
line, no comment inside the define.
*/}}
{{- define "agent-platform.workspaceManager.kagentFloor" -}}0.4.0{{- end -}}

{{/*
The first release of the workspace-manager line that calls the kagent
controller with a projected ServiceAccount token of kagent.tokenAudience, which
the controller's kubernetes authorization mode needs (agent-platform.kagent.authorization).
*/}}
{{- define "agent-platform.workspaceManager.tokenFloor" -}}0.10.0{{- end -}}

{{/*
agent-manager's organization values, as JSON. tenants.enabled follows the
organization switch. The 2.20.0 floor keeps the connectivity chart as the
only owner of agent-platform-tenant-flux. Credential UI URLs are explicit
client configuration; this chart does not derive them from Backstage. One
form serves organization and installation models, with or without the
organization switch.
Usage: include "agent-platform.agentManager.organizations" $root | fromJson
*/}}
{{- define "agent-platform.agentManager.organizations" -}}
{{- $am := index .Values "agent-manager" | default dict -}}
{{- $on := eq (include "agent-platform.organizations.on" .) "true" -}}
{{- if hasKey $am "devPortal" -}}
{{- fail "agent-manager.devPortal is unsupported: configure agent-manager.credentials.uiURL with the client's HTTPS URL template containing {operation}" -}}
{{- end -}}
{{- if or (hasKey $am "credentials") (hasKey $am "githubTokenExchange") -}}
{{- if not (include "agent-platform.componentFloorAtLeast" (dict "root" . "name" "agent-manager" "version" "2.22.0")) -}}
{{- fail "agent-manager credential operations and GitHub token exchange need components.agent-manager.versionRange with a floor of 2.22.0 or later" -}}
{{- end -}}
{{- end -}}
{{- if hasKey (dig "github" dict $am | default dict) "tokenExchange" -}}
{{- $managerFloor := include "agent-platform.semverRangeFloor" (dig "agent-manager" "versionRange" "" .Values.components) -}}
{{- if or (not $managerFloor) (lt ((semver $managerFloor).Compare (semver "3.0.0-rc.10")) 0) -}}
{{- fail "agent-manager.github.tokenExchange needs components.agent-manager.versionRange with a floor of 3.0.0-rc.10 or later" -}}
{{- end -}}
{{- $musterFloor := include "agent-platform.semverRangeFloor" (dig "muster" "versionRange" "" .Values.components) -}}
{{- if or (not $musterFloor) (lt ((semver $musterFloor).Compare (semver "5.63.2")) 0) -}}
{{- fail "agent-manager.github.tokenExchange needs components.muster.versionRange with a floor of 5.63.2 or later" -}}
{{- end -}}
{{- end -}}
{{- if and (dig "credentials" "uiURL" "" $am) (not (and (dig "oauth" "enabled" false $am) (dig "oauth" "downstream" "enabled" false $am))) -}}
{{- fail "agent-manager.credentials.uiURL needs agent-manager.oauth.enabled and agent-manager.oauth.downstream.enabled: the credential form posts the value to agent-manager as the person" -}}
{{- end -}}
{{- $own := dig "tenants" dict $am | default dict -}}
{{- range $k, $_ := $own -}}
{{- if not (has $k (list "enabled" "commit")) -}}
{{- fail (printf "agent-manager.tenants.%s is unsupported: configure tenants.commit for organization GitOps writes; tenants.enabled follows agentPlatformOrganizations.enabled" $k) -}}
{{- end -}}
{{- end -}}
{{- if and (hasKey $own "commit") (not (include "agent-platform.componentFloorAtLeast" (dict "root" . "name" "agent-manager" "version" "2.20.0"))) -}}
{{- fail "agent-manager.tenants.commit needs components.agent-manager.versionRange with a floor of 2.20.0 or later" -}}
{{- end -}}
{{- if and (hasKey $own "enabled") (ne (toString $own.enabled) (toString $on)) -}}
{{- fail (printf "agent-manager.tenants.enabled (%v) differs from agentPlatformOrganizations.enabled (%v): agent-manager serves the organization tools exactly while the operator keeps the organization namespaces — set agentPlatformOrganizations.enabled and leave agent-manager.tenants.enabled unset" $own.enabled $on) -}}
{{- end -}}
{{- $out := dict "tenants" (dict "enabled" $on) -}}
{{- if $on -}}
{{- $floor := include "agent-platform.agentManager.organizationsFloor" . -}}
{{- if not (include "agent-platform.componentFloorAtLeast" (dict "root" . "name" "agent-manager" "version" $floor)) -}}
{{- fail (printf "agentPlatformOrganizations.enabled needs agent-manager %s or later: components.agent-manager.versionRange (%s) admits a chart that renders the ClusterRole agent-platform-tenant-flux beside the connectivity chart's, and the two releases' upgrades end without it — raise the range's floor to %s" $floor (dig "agent-manager" "versionRange" "" .Values.components) $floor) -}}
{{- end -}}
{{- if not (and (dig "oauth" "enabled" false $am) (dig "oauth" "downstream" "enabled" false $am)) -}}
{{- fail "agentPlatformOrganizations.enabled needs agent-manager.oauth.enabled and agent-manager.oauth.downstream.enabled: the organization tools run as the caller, whose RoleBindings in the organization namespace grant the writes" -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
muster's organization values, as JSON: {"mcpServerNamespaceSelector":
{"matchExpressions": [{"key": <the organizations' label>, "operator":
"Exists"}]}} while agentPlatformOrganizations.enabled is on, {} while it is
off. muster then serves the MCPServers of every namespace the operator labels
as an organization's, next to its own namespace's, each to a person whom
Kubernetes RBAC lets list mcpservers there (giantswarm/muster#1783). The
label is the same one the connectivity chart's policies select the
organization namespaces by, and only the operator sets it
(agent-platform-organization-labels). With the switch off an own
muster.muster.mcpServerNamespaceSelector travels unchanged. The render fails,
naming what is missing, when the switch is on and:
  * an own muster.muster.mcpServerNamespaceSelector differs from the derived one;
  * the floor of components.muster.versionRange is below
    agent-platform.muster.organizationsFloor, whose chart takes the selector
    (an earlier chart refuses the key);
  * muster's OAuth server is off or not on the dex provider: muster lists the
    servers with the person's Dex token and refuses to start otherwise;
  * muster's MCP-server viewers are empty (musterMcpServerViewers, or
    tenants.platform.users while it is unset; giantswarm/agent-platform#1331):
    muster lists the servers of its own namespace as the person too, and with
    no subject the connectivity release binds nobody to list them
    (agent-platform:mcpserver-viewer). The connectivity chart resolves the
    viewers the same way (agent-platform.muster.mcpServerViewers): change
    both together.
Called from agent-platform.componentDerivedValues, i.e. only while
components.muster is on.
Usage: include "agent-platform.muster.organizations" $root | fromJson
*/}}
{{- define "agent-platform.muster.organizations" -}}
{{- if not (include "agent-platform.organizations.on" .) -}}
{{- dict | toJson -}}
{{- else -}}
{{- $m := dig "muster" dict (.Values.muster | default dict) | default dict -}}
{{- $selector := dict "matchExpressions" (list (dict "key" (include "agent-platform.orgNamespaces.label" .) "operator" "Exists")) -}}
{{- with dig "mcpServerNamespaceSelector" nil $m -}}
{{- if ne (toJson .) (toJson $selector) -}}
{{- fail (printf "muster.muster.mcpServerNamespaceSelector (%s) differs from the one agentPlatformOrganizations.enabled derives (%s): muster serves exactly the namespaces the operator labels as an organization's — leave muster.muster.mcpServerNamespaceSelector unset" (toJson .) (toJson $selector)) -}}
{{- end -}}
{{- end -}}
{{- $floor := include "agent-platform.muster.organizationsFloor" . -}}
{{- if not (include "agent-platform.componentFloorAtLeast" (dict "root" . "name" "muster" "version" $floor)) -}}
{{- fail (printf "agentPlatformOrganizations.enabled needs muster %s or later, whose chart takes muster.mcpServerNamespaceSelector (giantswarm/muster#1783; an earlier chart refuses the key): components.muster.versionRange (%s) — raise the range's floor to %s" $floor (dig "muster" "versionRange" "" .Values.components) $floor) -}}
{{- end -}}
{{- if not (and (dig "oauth" "server" "enabled" false $m) (eq (toString (dig "oauth" "server" "provider" "dex" $m)) "dex")) -}}
{{- fail "agentPlatformOrganizations.enabled needs muster.muster.oauth.server.enabled with the provider dex: muster lists the organizations' MCP servers with the person's Dex token and refuses to start with mcpServerNamespaceSelector otherwise" -}}
{{- end -}}
{{- $viewers := .Values.musterMcpServerViewers -}}
{{- if kindIs "invalid" $viewers -}}
{{- $viewers = dig "platform" "users" list (.Values.tenants | default dict) -}}
{{- end -}}
{{- if not $viewers -}}
{{- fail "agentPlatformOrganizations.enabled needs muster's MCP-server viewers, musterMcpServerViewers (or tenants.platform.users while musterMcpServerViewers is unset): muster lists the MCP servers of its own namespace as the person, and with no subject there the connectivity release binds nobody to list them (agent-platform:mcpserver-viewer)" -}}
{{- end -}}
{{- dict "mcpServerNamespaceSelector" $selector | toJson -}}
{{- end -}}
{{- end -}}

{{/*
The first muster release whose chart takes muster.mcpServerNamespaceSelector
(giantswarm/muster#1783). One line, no comment inside the define.
*/}}
{{- define "agent-platform.muster.organizationsFloor" -}}5.58.0{{- end -}}

{{/*
The first muster release that takes toolsetPresets.<name>.icon. One line, no
comment inside the define.
*/}}
{{- define "agent-platform.muster.presetIconsFloor" -}}5.61.0{{- end -}}

{{/*
Icons of the shipped presets (infrastructure, agent-platform), for each one
muster.muster.toolsetPresets still defines and leaves without an icon, while
the floor of components.muster.versionRange is at least
agent-platform.muster.presetIconsFloor. Emits JSON, {} otherwise.
Usage: include "agent-platform.muster.presetIcons" $root | fromJson
*/}}
{{- define "agent-platform.muster.presetIcons" -}}
{{- $out := dict -}}
{{- if include "agent-platform.componentFloorAtLeast" (dict "root" . "name" "muster" "version" (include "agent-platform.muster.presetIconsFloor" .)) -}}
{{- $icons := dict
      "infrastructure" "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiI+PGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiM5OTNDMUQiLz48ZyBmaWxsPSJub25lIiBzdHJva2U9IiNmZmYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cmVjdCB4PSIxMCIgeT0iOSIgd2lkdGg9IjEyIiBoZWlnaHQ9IjYiIHJ4PSIxLjUiLz48cmVjdCB4PSIxMCIgeT0iMTciIHdpZHRoPSIxMiIgaGVpZ2h0PSI2IiByeD0iMS41Ii8+PHBhdGggZD0iTTEzIDEyaC4wMU0xMyAyMGguMDEiLz48L2c+PC9zdmc+"
      "agent-platform" "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMiAzMiI+PGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiM1MzRBQjciLz48ZyBmaWxsPSJub25lIiBzdHJva2U9IiNmZmYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cGF0aCBkPSJNMTYgOWwxLjggNS4yTDIzIDE2bC01LjIgMS44TDE2IDIzbC0xLjgtNS4yTDkgMTZsNS4yLTEuOHoiLz48L2c+PC9zdmc+" -}}
{{- $presets := dig "muster" "toolsetPresets" dict (.Values.muster | default dict) -}}
{{- range $name, $icon := $icons -}}
{{- $p := get $presets $name -}}
{{- if and (kindIs "map" $p) (not $p.icon) -}}
{{- $_ := set $out $name (dict "icon" $icon) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
A Go duration (time.ParseDuration: 720h, 1h30m, 0, 1.5h) in seconds, empty
for anything else (a sign, a day unit, a bare number other than 0).
Usage: include "agent-platform.durationSeconds" "720h"
*/}}
{{- define "agent-platform.durationSeconds" -}}
{{- $d := toString . -}}
{{- $unit := dict "h" 3600.0 "m" 60.0 "s" 1.0 "ms" 0.001 "us" 0.000001 "µs" 0.000001 "ns" 0.000000001 -}}
{{- $num := "([0-9]+(\\.[0-9]*)?|\\.[0-9]+)" -}}
{{- if eq $d "0" -}}0
{{- else if regexMatch (printf "^(%s(ns|us|µs|ms|h|m|s))+$" $num) $d -}}
{{- $total := 0.0 -}}
{{- range regexFindAll (printf "%s(ns|us|µs|ms|h|m|s)" $num) $d -1 -}}
{{- $total = addf $total (mulf (float64 (regexFind $num .)) (get $unit (regexReplaceAll (printf "^%s" $num) . ""))) -}}
{{- end -}}
{{- $total -}}
{{- end -}}
{{- end -}}

{{/*
The first release of the workspace-manager line whose manager has the provider
kind gitlab (gitlab.com or a self-managed GitLab: url, apiURL, a group access
token as the sync credential, an OAuth application as the sign-in); an earlier
manager refuses the kind at start. A gitlab provider instance needs the floor of
components.workspace-manager.versionRange at it or later (a release candidate
of it included), or the render fails (agent-platform.validateWorkspaces). One
line, no comment inside the define.
*/}}
{{- define "agent-platform.workspaceManager.gitlabFloor" -}}0.5.0{{- end -}}

{{/*
The first release of the workspace-manager line that admits an Organization's
members by verified email or email domain (organizations.<name>.memberEmails,
.memberDomains), for an identity provider that sends no groups claim; an
earlier release's closed values schema refuses both keys. An Organization in
workspaces.organizations with either needs the floor of
components.workspace-manager.versionRange at it or later (a release candidate
of it included), or the render fails
(agent-platform.workspaces.organizations.validate). One line, no comment inside
the define.
*/}}
{{- define "agent-platform.workspaceManager.memberEmailsFloor" -}}0.12.0{{- end -}}

{{/*
The first release of the workspace-manager line whose person's provider token
is muster's grant of a provider instance's App (muster.mcpServer.auth.provider)
and which keeps no sign-in store of its own; an earlier manager with provider
instances and OAuth needs the sign-in keys this chart no longer creates. With
provider instances and oauth.enabled the floor of
components.workspace-manager.versionRange is at it or later (a release
candidate of it included), or the render fails
(agent-platform.validateWorkspaceAuth). One line, no comment inside the define.
*/}}
{{- define "agent-platform.workspaceManager.musterGrantFloor" -}}0.10.0{{- end -}}

{{/*
The first workspace-manager release that takes the person's token per provider
instance from muster's provider Apps (muster.mcpServer.auth.providerApps,
X-Muster-Grant-<instance>; giantswarm/workspace-manager#129), and the first
muster release that keeps provider Apps apart from any MCPServer
(muster.providerApps; giantswarm/muster#1604). While the registration receives
the grants of provider Apps (agent-platform.workspaceManager.providerApps) the
floors of components.workspace-manager.versionRange and
components.muster.versionRange are at them or later, or the render fails
(agent-platform.validateWorkspaceAuth). One line each, no comment inside the
define.
*/}}
{{- define "agent-platform.workspaceManager.providerAppsFloor" -}}0.12.0{{- end -}}
{{- define "agent-platform.muster.providerAppsFloor" -}}5.48.0{{- end -}}

{{/*
The first release of the klaus-gateway line (giantswarm/klaus-gateway) whose
chart takes workspaces.toolsPrefix (the workspace-manager client over muster);
every earlier release's closed values schema refuses a workspaces block. From
it on (a release candidate of it included) the chart derives
klausGateway.workspaces.toolsPrefix while workspaces are on
(agent-platform.componentDerivedValues). One line, no comment inside the define.
*/}}
{{- define "agent-platform.klausGateway.workspacesFloor" -}}4.3.0{{- end -}}

{{/*
The first release of the agent-manager line (giantswarm/agent-manager) whose
chart takes muster.toolchainsToolsPrefix (start_session starts a toolchain
only at a version the toolchain-manager's list_toolchains lists); an earlier
release's closed values schema refuses the key. From it on (a release
candidate of it included) the chart derives agent-manager.muster.toolchainsToolsPrefix
while components.toolchain-manager is on (agent-platform.componentDerivedValues).
One line, no comment inside the define.
*/}}
{{- define "agent-platform.agentManager.toolchainsFloor" -}}2.14.0{{- end -}}

{{/*
The first release of the agent-manager line whose chart takes
toolchains.registryConfig.secretName (a toolchain read from a private
registry with the credentials of a dockerconfigjson Secret); an earlier
release's closed values schema refuses the key. From it on (a release
candidate of it included) the chart derives it from
toolchain-manager.registryPullSecret. One line, no comment inside the define.
*/}}
{{- define "agent-platform.agentManager.registryConfigFloor" -}}2.16.0{{- end -}}

{{/*
PLACEHOLDER (giantswarm/backstage#3355, unreleased; 3.37.1 takes URLs alone):
the first release of the portal (backstage) that takes a skill repository as
{url, ref, path, readOnly}; below it the portal gets URLs alone and no
platform source. Set it to the backstage release that carries #3355 before
raising components.backstage.versionRange to it. One line, no comment inside
the define.
*/}}
{{- define "agent-platform.backstage.skillSourcesFloor" -}}3.31.0{{- end -}}

{{/*
The first agent-manager release that takes skillManager.url and pins skills
through the skill-manager, and takes installation and defaultAgentModel
(giantswarm/agent-manager#290, giantswarm/giantswarm#38322); an earlier
release's closed values schema refuses the keys. A release candidate of it
counts (componentFloorAtLeast), so a range floor below the candidate that
carries #290 (2.24.0-rc.6 and earlier) gets keys it refuses. The default
floor of components.agent-manager.versionRange is this release. One line, no
comment inside the define.
*/}}
{{- define "agent-platform.agentManager.skillManagerFloor" -}}2.24.0{{- end -}}

{{/*
The first portal (backstage) release that reads skills from the skill-manager
through muster as the person and checks a skill pull request against its
sources (giantswarm/backstage#3432, giantswarm/giantswarm#38322). One line, no
comment inside the define.
*/}}
{{- define "agent-platform.backstage.skillManagerFloor" -}}3.36.0{{- end -}}

{{/*
"true" when the portal reads skills from the skill-manager: both components
on and the floor of components.backstage.versionRange at or above
agent-platform.backstage.skillManagerFloor. The portal then gets no skill
repositories of its own.
Usage: include "agent-platform.backstage.viaSkillManager" $
*/}}
{{- define "agent-platform.backstage.viaSkillManager" -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "backstage")) (include "agent-platform.componentEnabled" (dict "root" . "name" "skill-manager")) (include "agent-platform.componentFloorAtLeast" (dict "root" . "name" "backstage" "version" (include "agent-platform.backstage.skillManagerFloor" .))) -}}true{{- end -}}
{{- end -}}

{{/*
The installation's name in the portal: the key of its entries in the
app-config the connectivity chart renders (backstage.installationName).
Usage: include "agent-platform.portalInstallationName" $
*/}}
{{- define "agent-platform.portalInstallationName" -}}
{{- dig "installationName" "" (.Values.backstage | default dict) | default "agent-platform" -}}
{{- end -}}

{{/*
"true" when this chart is a published release: a version without a
pre-release, packaged with appVersion = version (the pipeline stamps both). A
pre-release (a branch build, a candidate) and the working tree (appVersion
0.1.0) are not; they have no release tag and no stamped commit.
Usage: include "agent-platform.publishedRelease" $
*/}}
{{- define "agent-platform.publishedRelease" -}}
{{- if and (not (semver .Chart.Version).Prerelease) (eq (toString .Chart.AppVersion) .Chart.Version) }}true{{ end -}}
{{- end -}}

{{/*
The commit skills.platformSource.ref pins the platform's skills to: "" unset;
anything but a full 40-hex commit id fails the render, since the default
agent's pins take a commit only (the agent chart refuses a branch, a tag and a
short SHA) and helm resolves nothing at render.
Usage: include "agent-platform.skills.platformRef" $
*/}}
{{- define "agent-platform.skills.platformRef" -}}
{{- $ref := dig "platformSource" "ref" "" (.Values.skills | default dict) | toString -}}
{{- if and $ref (not (regexMatch "^[0-9a-f]{40}$" $ref)) -}}
{{- fail (printf "skills.platformSource.ref %q: give a full 40-hex commit id; the default agent's skills pin a commit, never a branch, a tag or a short SHA" $ref) -}}
{{- end -}}
{{- $ref -}}
{{- end -}}

{{/*
The platform's own skill source: skills/ of this repository, read-only, at
skills.platformSource.ref when set, else this chart's release tag
(agent-platform.publishedRelease), else the commit a dev build was built from
(the h<sha> of X.Y.Z-r<branch-hash>t<time>h<sha>), else no ref (the default
branch).
Usage: include "agent-platform.skills.platformSource" $ | fromJson
*/}}
{{- define "agent-platform.skills.platformSource" -}}
{{- $source := dict "url" "https://github.com/giantswarm/agent-platform" "path" "skills" "readOnly" true -}}
{{- $pre := toString (semver .Chart.Version).Prerelease -}}
{{- $ref := include "agent-platform.skills.platformRef" . -}}
{{- if $ref -}}
{{- $_ := set $source "ref" $ref -}}
{{- else if include "agent-platform.publishedRelease" . -}}
{{- $_ := set $source "ref" (printf "v%s" (include "agent-platform.chartVersion" .)) -}}
{{- else if regexMatch "^r[0-9a-f]+t[0-9]{14}h[0-9a-f]{7,40}$" $pre -}}
{{- $_ := set $source "ref" (regexReplaceAll "^.*h([0-9a-f]+)$" $pre "${1}") -}}
{{- end -}}
{{- $source | toJson -}}
{{- end -}}

{{/*
A skill source's identity, url + ref + path, the URL without a trailing `/` or
`.git`. Usage: include "agent-platform.skills.sourceKey" $entry
*/}}
{{- define "agent-platform.skills.sourceKey" -}}
{{- $e := ternary . (dict "url" .) (kindIs "map" .) -}}
{{- $url := trimSuffix "/" (toString $e.url) | trimSuffix ".git" | trimSuffix "/" -}}
{{- printf "%s|%s|%s" $url (toString ($e.ref | default "")) (trimSuffix "/" (toString ($e.path | default ""))) -}}
{{- end -}}

{{/*
The skill sources one consumer offers, as JSON {"list": [...]}, all from
skillManager.sources:
- skill-manager (sources): the platform's source first
  (skills.platformSource.enabled), then skillManager.sources, as written (a
  URL or {url, ref, path, readOnly});
- backstage (skillsRepositories): the same, from the portal's
  skillSourcesFloor on; below it URLs alone and no platform source;
- agent-manager (skills.repositories, deprecated): URLs alone and no platform
  source, for an agent-manager that does not pin through the skill-manager
  (agent-platform.agentManager.viaSkillManager).
A consumer's own deprecated list (agent-manager.skills.repositories,
backstage.skillsRepositories), when set, replaces skillManager.sources for
that consumer. One entry per url + ref + path. An installation entry for the
platform's repository while its source is on fails the render.
Usage: include "agent-platform.skills.repositories" (dict "root" $ "consumer" "backstage") | fromJson
*/}}
{{- define "agent-platform.skills.repositories" -}}
{{- $v := .root.Values -}}
{{- $platform := include "agent-platform.skills.platformSource" .root | fromJson -}}
{{- $platformOn := ne (toString (dig "platformSource" "enabled" true ($v.skills | default dict))) "false" -}}
{{- $own := list -}}
{{- if eq .consumer "agent-manager" }}{{- $own = dig "skills" "repositories" list (index $v "agent-manager" | default dict) -}}
{{- else if eq .consumer "backstage" }}{{- $own = dig "skillsRepositories" list ($v.backstage | default dict) -}}
{{- end -}}
{{- $installation := $own | default (dig "sources" list ($v.skillManager | default dict)) | default list -}}
{{- $objects := eq .consumer "skill-manager" -}}
{{- if eq .consumer "backstage" -}}
{{- $objects = eq (include "agent-platform.componentFloorAtLeast" (dict "root" .root "name" "backstage" "version" (include "agent-platform.backstage.skillSourcesFloor" .root))) "true" -}}
{{- end -}}
{{- $platformKey := include "agent-platform.skills.sourceKey" (dict "url" $platform.url) | splitList "|" | first -}}
{{- $seen := dict -}}
{{- $out := list -}}
{{- if and $platformOn $objects -}}
{{- $out = append $out $platform -}}
{{- $_ := set $seen (include "agent-platform.skills.sourceKey" $platform) true -}}
{{- end -}}
{{- range $installation -}}
{{- $key := include "agent-platform.skills.sourceKey" . -}}
{{- if and $platformOn (eq (first (splitList "|" $key)) $platformKey) -}}
{{- fail (printf "the skill source %v names the platform's own repository, which the chart already offers read-only at its release (skills.platformSource); remove the entry, or set skills.platformSource.enabled=false to list the repository yourself" .) -}}
{{- end -}}
{{- $entry := . -}}
{{- if and (kindIs "map" .) (not $objects) }}{{ $entry = .url }}{{ end -}}
{{- $key = include "agent-platform.skills.sourceKey" $entry -}}
{{- if not (hasKey $seen $key) -}}
{{- $_ := set $seen $key true -}}
{{- $out = append $out $entry -}}
{{- end -}}
{{- end -}}
{{- dict "list" $out | toJson -}}
{{- end -}}

{{/*
"true" when agent-manager pins and lists skills through the skill-manager:
both components on and the floor of components.agent-manager.versionRange at
or above agent-platform.agentManager.skillManagerFloor. agent-manager then
gets skillManager.url and no skill sources; otherwise its deprecated
skills.repositories (agent-platform.skills.repositories).
Usage: include "agent-platform.agentManager.viaSkillManager" $
*/}}
{{- define "agent-platform.agentManager.viaSkillManager" -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "agent-manager")) (include "agent-platform.componentEnabled" (dict "root" . "name" "skill-manager")) (include "agent-platform.componentFloorAtLeast" (dict "root" . "name" "agent-manager" "version" (include "agent-platform.agentManager.skillManagerFloor" .))) -}}true{{- end -}}
{{- end -}}

{{/*
The skill-manager's in-cluster REST URL, the one agent-manager calls:
http://<skill-manager.fullnameOverride>.<its namespace>.svc.cluster.local:<skill-manager.service.port, 8080>.
Usage: include "agent-platform.skillManager.url" $
*/}}
{{- define "agent-platform.skillManager.url" -}}
{{- $sm := index .Values "skill-manager" | default dict -}}
{{- $ns := dig "skill-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- printf "http://%s.%s.svc.cluster.local:%v" ($sm.fullnameOverride | default "skill-manager") $ns (dig "service" "port" 8080 $sm) -}}
{{- end -}}

{{/*
The namespaces of the skill-manager's callers other than its own, as JSON
{"list": [...]}: muster's (the MCP tools), the portal's while
components.backstage is on, and, while agent-manager pins through it
(agent-platform.agentManager.viaSkillManager), agent-manager's (its REST
calls) and the kagent namespace (agent-manager's migrate run). Each once.
Usage: (include "agent-platform.skillManager.callerNamespaces" . | fromJson).list
*/}}
{{- define "agent-platform.skillManager.callerNamespaces" -}}
{{- $platform := include "agent-platform.targetNamespace" . -}}
{{- $own := dig "skill-manager" "targetNamespace" "" .Values.components | default $platform -}}
{{- $out := list (dig "muster" "targetNamespace" "" .Values.components | default $platform) -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "backstage") -}}
{{- $out = append $out (dig "backstage" "targetNamespace" "" .Values.components | default $platform) -}}
{{- end -}}
{{- if include "agent-platform.agentManager.viaSkillManager" . -}}
{{- $out = append $out (dig "agent-manager" "targetNamespace" "" .Values.components | default $platform) -}}
{{- $out = append $out (include "agent-platform.kagent.namespace" .) -}}
{{- end -}}
{{- dict "list" (without (uniq $out) $own) | toJson -}}
{{- end -}}

{{/*
The Secret, by name, holding the skill-manager's service token (key token),
the bearer agent-manager's migrate run calls it with: generated by the
connectivity release in the skill-manager's namespace and the kagent
namespace (templates/agent-manager/skill-manager-token.yaml), while
agent-manager pins through it and skill-manager.oauth.enabled is on (the
token needs it). Empty otherwise.
Usage: include "agent-platform.skillManager.serviceToken" $
*/}}
{{- define "agent-platform.skillManager.serviceToken" -}}
{{- if and (include "agent-platform.agentManager.viaSkillManager" .) (dig "oauth" "enabled" false (index .Values "skill-manager" | default dict)) -}}
skill-manager-service-token
{{- end -}}
{{- end -}}

{{/*
The skill-manager's MCP backend entry for the connectivity release
(networkPolicy.mcpBackends.skill-manager), while the component is on: its
pods in its release's namespace on its Service port, so the ingress policy
admits muster (its MCP tools) and the namespace's own pods (agent-manager's
REST calls); the connectivity chart opens agent-manager's egress to it. Emits
JSON, {} while the component is off.
Usage: include "agent-platform.skillManager.mcpBackend" . | fromJson
*/}}
{{- define "agent-platform.skillManager.mcpBackend" -}}
{{- $out := dict -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "skill-manager") -}}
{{- $sm := index .Values "skill-manager" | default dict -}}
{{- $ns := dig "skill-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- $out = dict "namespace" $ns "ports" (list (int (dig "service" "port" 8080 $sm))) "podSelector" (dict "app.kubernetes.io/name" (include "agent-platform.skillManager.name" $sm)) -}}
{{- $amNs := dig "agent-manager" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- if and (include "agent-platform.agentManager.viaSkillManager" .) (ne $amNs $ns) -}}
{{- $_ := set $out "additionalPeers" (list (dict "namespace" $amNs "matchLabels" (dict "app.kubernetes.io/name" (dig "nameOverride" "agent-manager" (index .Values "agent-manager" | default dict))))) -}}
{{- end -}}
{{- /* Only while the chart's own NetworkPolicy selects the pods: the entry's
egress policy only adds to it, and alone it would deny the pods' other egress
(GitHub, the registries, OTLP). */ -}}
{{- if dig "networkPolicy" "enabled" true $sm -}}
{{- with include "agent-platform.skillManager.issuerUrl" . -}}
{{- $_ := set $out "identityProvider" (dict "provider" "dex" "issuerUrl" .) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
The skill-manager pods' app.kubernetes.io/name label, as its chart's
skill-manager.name renders it: nameOverride, an empty one meaning the chart
name, cut to 63 characters without a trailing hyphen. The MCP backend entry's
podSelector, so its ingress and egress policies select the running pods.
Usage: include "agent-platform.skillManager.name" (index .Values "skill-manager" | default dict)
*/}}
{{- define "agent-platform.skillManager.name" -}}
{{- dig "nameOverride" "" . | default "skill-manager" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
The issuer the skill-manager validates tokens of, while its OAuth is on: its
own oauth.dex.issuerURL, else global.identity.issuerUrl, else muster's login
(muster.muster.oauth.server.dex.issuerUrl, while that server is on with the dex
provider) — the order its chart and agent-platform.identity.apply resolve it
in. Its MCP backend entry carries it (identityProvider), so the connectivity
chart opens the pods' egress to it as it does for the other managers
(agent-platform.idpEgress.cilium): by name, and the cluster entity on 443 and
10443 for an issuer served through an in-cluster Gateway — on Cilium the
chart's own NetworkPolicy, an ipBlock on 443, matches no in-cluster endpoint.
Empty with its OAuth off or no issuer named.
Usage: include "agent-platform.skillManager.issuerUrl" .
*/}}
{{- define "agent-platform.skillManager.issuerUrl" -}}
{{- $sm := index .Values "skill-manager" | default dict -}}
{{- if dig "oauth" "enabled" false $sm -}}
{{- $login := include "agent-platform.identity.musterLogin" .Values | fromJson -}}
{{- dig "oauth" "dex" "issuerURL" "" $sm | default (dig "identity" "issuerUrl" "" (.Values.global | default dict)) | default ($login.issuerURL | default "") -}}
{{- end -}}
{{- end -}}

{{/*
muster's login, the platform's one login, as the managers take it: the
issuer, client and Secret of muster.muster.oauth.server while that server is on
with the dex provider; {} otherwise. Read by agent-platform.identity.apply and
agent-platform.skillManager.issuerUrl, so the issuer a manager runs with and the
one its egress opens follow one rule.
Usage: include "agent-platform.identity.musterLogin" $values | fromJson
*/}}
{{- define "agent-platform.identity.musterLogin" -}}
{{- $server := dig "muster" "oauth" "server" dict (index . "muster" | default dict) -}}
{{- $login := dict -}}
{{- if and (dig "enabled" true $server) (eq (toString (dig "provider" "dex" $server)) "dex") -}}
{{- $login = dict "issuerURL" (dig "dex" "issuerUrl" "" $server) "clientID" (dig "dex" "clientId" "" $server) "existingSecret" (dig "existingSecret" "" $server) -}}
{{- end -}}
{{- $login | toJson -}}
{{- end -}}

{{/*
The values the default agent's release (components.default-agent)
takes from the platform, merged over agents/default-agent/values.yaml: the
muster URL every agent targets, its display name and description
(defaultAgent.displayName, defaultAgent.description; the display name also
replaces `[[ .DisplayName ]]` in the file's system message), its avatar on the
DiceBear host (the route's first hostname, else avatars.<global.domain>; none
without either), the
toolset preset:full (it acts as the person), the component's labels on the
Agent too (components.default-agent.labels) with managed-by, which
agent-manager lists read-only, and default, which it reports as the
installation's default agent, always set, and its model: defaultAgent.modelConfig,
else modelConfig.name "" (no model), which agent-manager fills once with the
installation's default model.
Usage: include "agent-platform.defaultAgent.derived" $ | fromJson
*/}}
{{- define "agent-platform.defaultAgent.derived" -}}
{{- $agent := dict -}}
{{- $host := "" -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "dicebear") -}}
{{- $host = first (dig "route" "hostnames" list (.Values.dicebear | default dict) | default (list "")) -}}
{{- with .Values.global.domain -}}{{- $host = $host | default (printf "avatars.%s" .) -}}{{- end -}}
{{- end -}}
{{- with $host -}}
{{- $_ := set $agent "iconUrl" (printf "https://%s/v1/default-agent.png" .) -}}
{{- end -}}
{{- $da := .Values.defaultAgent | default dict -}}
{{- $displayName := $da.displayName | default "General Assistant" -}}
{{- $_ := set $agent "displayName" $displayName -}}
{{- with $da.description }}{{- $_ := set $agent "description" . -}}{{- end -}}
{{- $file := .Files.Get (index .Values.components "default-agent").valuesFile | fromYaml -}}
{{- with dig "agent" "systemMessage" "" $file -}}
{{- $_ := set $agent "systemMessage" (replace "[[ .DisplayName ]]" $displayName .) -}}
{{- end -}}
{{- $labels := mustMergeOverwrite (deepCopy ((index .Values.components "default-agent").labels | default dict)) (dict "agent-platform.giantswarm.io/default" "true" "agent-platform.giantswarm.io/managed-by" "agent-platform") -}}
{{- $model := dig "modelConfig" "" $da | toString -}}
{{- $out := dict "muster" (dict "url" (include "agent-platform.musterMcpUrl" .)) "toolset" (list "preset:full") "labels" $labels "modelConfig" (dict "name" $model) -}}
{{- $_ := set $out "agent" $agent -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
A component's values file (components.<name>.valuesFile, a path in this chart),
as JSON. The release pipeline stamps the tag's commit over the `[[ .SHA ]]`
placeholder (hack/stamp-release-commit.sh). skills.platformSource.ref, when
set, replaces the commit of every skills[] entry of the platform's repository,
stamped or not. A skills[] entry still carrying the placeholder
is dropped where the chart is no published release
(agent-platform.publishedRelease), and fails the render of a published
release: such a chart was packaged without the stamp.
Usage: include "agent-platform.componentValuesFile" (dict "root" $ "path" $c.valuesFile) | fromJson
*/}}
{{- define "agent-platform.componentValuesFile" -}}
{{- $vals := .root.Files.Get .path | fromYaml -}}
{{- if not $vals -}}
{{- fail (printf "%s is missing from the chart or empty" .path) -}}
{{- end -}}
{{- $released := include "agent-platform.publishedRelease" .root -}}
{{- $ref := include "agent-platform.skills.platformRef" .root -}}
{{- $platform := (include "agent-platform.skills.platformSource" .root | fromJson).url -}}
{{- if hasKey $vals "skills" -}}
{{- $pinned := list -}}
{{- range $vals.skills -}}
{{- if and $ref (kindIs "map" .) (kindIs "map" .git) (eq (trimSuffix ".git" (toString .git.url)) $platform) -}}
{{- $_ := set .git "commit" $ref -}}
{{- end -}}
{{- if eq (toString (dig "git" "commit" "" (ternary . dict (kindIs "map" .)))) "[[ .SHA ]]" -}}
{{- if $released -}}
{{- fail (printf "%s: skill %s still carries the [[ .SHA ]] placeholder in release %s: the chart was published without hack/stamp-release-commit.sh" $.path .name $.root.Chart.Version) -}}
{{- end -}}
{{- else -}}
{{- $pinned = append $pinned . -}}
{{- end -}}
{{- end -}}
{{- $_ := set $vals "skills" $pinned -}}
{{- end -}}
{{- $vals | toJson -}}
{{- end -}}

{{/*
The first agent-manager release whose tenants.enabled leaves the ClusterRole
agent-platform-tenant-flux to the connectivity chart
(giantswarm/agent-manager#305), the floor agentPlatformOrganizations.enabled
needs (agent-platform.agentManager.organizations).
*/}}
{{- define "agent-platform.agentManager.organizationsFloor" -}}2.20.0{{- end -}}

{{/*
The first release of the Substrate line (giantswarm/substrate) whose chart
takes atelet.imagePullSecrets (the credentials atelet pulls actor images
with, a Session's tool images among them). From it on (a release candidate of
it included) the chart derives it from toolchain-manager.registryPullSecret.
One line, no comment inside the define.
*/}}
{{- define "agent-platform.substrate.ateletPullSecretsFloor" -}}1.18.0{{- end -}}

{{/*
The first release of the toolchain-manager line (giantswarm/toolchain-manager)
whose chart takes muster.mcpUrl and muster.agentManagerToolsPrefix
(deprecate_toolchain asks agent-manager through muster); an earlier release's
closed values schema refuses the keys. From it on the chart derives both
(agent-platform.toolchainManager.derived). One line, no comment inside the
define.
*/}}
{{- define "agent-platform.toolchainManager.deprecateFloor" -}}0.3.0{{- end -}}

{{/*
The first release of the toolchain-manager line whose chart takes
klausGateway (url, audience) and a source's team and slackChannel (the
outdated notices through klaus-gateway); an earlier
release's closed values schema refuses them. From it on (a release candidate
of it included) the chart derives klausGateway and lists the manager in
klaus-gateway's reviews.allowedCallers (agent-platform.toolchainManager.reviews).
One line, no comment inside the define.
*/}}
{{- define "agent-platform.toolchainManager.reviewsFloor" -}}0.4.0{{- end -}}

{{/*
The kagent controller's in-cluster gRPC API (in-cluster h2c), straight to its
Service: grpc://<kagent.fullnameOverride>-controller.<kagent namespace>.svc:8083
while the kagent component is on, "" otherwise. 8083 is the port the kagent
controller serves its API on, the one the connectivity chart's policies and
controller route name.
Usage: include "agent-platform.kagent.controllerAddress" .
*/}}
{{- define "agent-platform.kagent.controllerAddress" -}}
{{- if include "agent-platform.componentEnabled" (dict "root" . "name" "kagent") -}}
{{- printf "grpc://%s-controller.%s.svc:8083" (dig "fullnameOverride" "" (.Values.kagent | default dict) | default "kagent") (include "agent-platform.kagent.namespace" .) -}}
{{- end -}}
{{- end -}}

{{/*
The audience of the ServiceAccount tokens the kagent controller's TokenReview
admits (kagent.controller.authorization.serviceAccountTokenAudience): the
block's own, else workspace-manager's (workspace-manager.kagent.tokenAudience),
else kagent, both charts' default. Every caller with a ServiceAccount token
(workspace-manager, klaus-gateway's session reads) projects it for this one.
*/}}
{{- define "agent-platform.kagent.tokenAudience" -}}
{{- $own := toString (dig "controller" "authorization" "serviceAccountTokenAudience" "" (.Values.kagent | default dict)) -}}
{{- $own | default (dig "kagent" "tokenAudience" "" (index .Values "workspace-manager" | default dict)) | default "kagent" -}}
{{- end -}}

{{/*
klaus-gateway's release namespace and the name of its ServiceAccount and pods
(klausGateway.fullnameOverride, else klaus-gateway).
*/}}
{{- define "agent-platform.klausGateway.namespace" -}}
{{- dig "klaus-gateway" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- end -}}
{{- define "agent-platform.klausGateway.name" -}}
{{- dig "fullnameOverride" "" (.Values.klausGateway | default dict) | default "klaus-gateway" -}}
{{- end -}}

{{/*
The releases the refusal notices need: klaus-gateway 4.11.0, whose closed
values schema knows klausGateway.refusals, and kagent 1.20.0, whose
controller admits a session reader. Truthy (emits "true") while the floors of
components.klaus-gateway.versionRange and components.kagent.versionRange are
at or above them; below, the notices stay off and nothing of them renders.
*/}}
{{- define "agent-platform.klausGateway.refusalsFloor" -}}4.11.0{{- end -}}
{{- define "agent-platform.kagent.sessionReaderFloor" -}}1.20.0{{- end -}}
{{- define "agent-platform.klausGateway.refusalsFloorsMet" -}}
{{- $kgFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig "klaus-gateway" "versionRange" "" .Values.components) | default "0.0.0") "" -}}
{{- $kaFloor := regexReplaceAll "-.*$" (include "agent-platform.semverRangeFloor" (dig "kagent" "versionRange" "" .Values.components) | default "0.0.0") "" -}}
{{- if and (ge ((semver $kgFloor).Compare (semver (include "agent-platform.klausGateway.refusalsFloor" .))) 0) (ge ((semver $kaFloor).Compare (semver (include "agent-platform.kagent.sessionReaderFloor" .))) 0) -}}true{{- end -}}
{{- end -}}

{{/*
Truthy (emits "true") while the egress refusal notices run
(giantswarm/giantswarm#38667): klaus-gateway with Slack on
(klausGateway.slack.enabled), klausGateway.refusals.enabled not false (auto by default),
kagent and Substrate on, and the controller in the kubernetes authorization
mode, whose session reader admits the gateway, and the klaus-gateway and kagent
ranges at or above the releases that carry the notices
(agent-platform.klausGateway.refusalsFloorsMet). The gateway then reads the
Substrate egress's refusal counter and tells each agent's creator by direct
message. The connectivity chart asks the same (its copy of this define).
*/}}
{{- define "agent-platform.klausGateway.refusalsOn" -}}
{{- $kg := .Values.klausGateway | default dict -}}
{{- if and (eq (toString (dig "refusals" "enabled" "auto" $kg)) "true") (not (include "agent-platform.klausGateway.refusalsFloorsMet" .)) -}}
{{- fail (printf "klausGateway.refusals.enabled is true, but components.klaus-gateway.versionRange admits a klaus-gateway before %s or components.kagent.versionRange a kagent before %s, which cannot run the refusal notices — raise the floors, or leave klausGateway.refusals.enabled at auto" (include "agent-platform.klausGateway.refusalsFloor" .) (include "agent-platform.kagent.sessionReaderFloor" .)) -}}
{{- end -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "klaus-gateway")) (dig "slack" "enabled" false $kg) (ne (toString (dig "refusals" "enabled" "auto" $kg)) "false") (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) (include "agent-platform.componentEnabled" (dict "root" . "name" "substrate")) (eq (toString (dig "controller" "authorization" "mode" "" (.Values.kagent | default dict))) "kubernetes") (include "agent-platform.klausGateway.refusalsFloorsMet" .) -}}true{{- end -}}
{{- end -}}

{{/*
The Helm hook events the hook ServiceAccount + ClusterRoleBinding (hooks/rbac.yaml)
are created for, in Helm's order: pre-install,pre-upgrade while the kagent
namespace hook renders (it runs as that account — creating a namespace is
cluster-scoped, the namespaced <release>-self identity cannot); with the
bundled engine pre-install, pre-upgrade for the Flux Operator CRD hook and
pre-delete and post-delete for the ordered teardown; and the serving
teardown's event while it renders
(agent-platform.serving.teardownEvent: pre-delete, or pre-upgrade when the
slice is switched off in place). Empty when none of them renders — rbac.yaml
renders nothing then.
*/}}
{{- define "agent-platform.hooks.serviceAccountEvents" -}}
{{- $events := list -}}
{{- if include "agent-platform.kagent.hookNamespace" . }}{{ $events = concat $events (list "pre-install" "pre-upgrade") }}{{ end -}}
{{- if eq (include "agent-platform.engineEnabled" .) "true" }}{{ $events = concat $events (list "pre-install" "pre-upgrade" "pre-delete" "post-delete") }}{{ end -}}
{{- with include "agent-platform.serving.teardownEvent" . }}{{ $events = append $events . }}{{ end -}}
{{- join "," (uniq $events) -}}
{{- end -}}

{{/*
The tenant ServiceAccount the platform HelmReleases run under: the one the
flux-engine subchart renders (agent-platform-flux) whenever the engine is on,
nothing otherwise. gitops.serviceAccountName overrides it either way (see
components.yaml). The name is fixed on both sides — the subchart renders it,
this helper spells it — so the two cannot drift apart through a value.
*/}}
{{- define "agent-platform.tenantServiceAccountName" -}}
{{- if eq (include "agent-platform.engineEnabled" .) "true" -}}agent-platform-flux{{- end -}}
{{- end -}}

{{/*
Render guard of the bundled engine. Two refusals, both only with the engine on:

1. A cluster that already runs Flux. A second, locked-down helm-controller would
   watch every namespace and reconcile every HelmRelease in the cluster as the
   default account (measured), and the operator would take over the cluster's
   Flux CRDs. Foreign = an apps/v1 Deployment labelled
   app.kubernetes.io/component=helm-controller outside the release namespace
   (the label Flux's distribution and the operator's manifests stamp — the
   engine's own helm-controller lives in the release namespace), or a
   FluxInstance outside the release namespace (the engine's is `flux` in the
   release namespace; the FluxInstance kind is looked up only when the API is
   served, so a cluster without the operator CRDs is not an error). `lookup` is
   live under install/upgrade, --dry-run=server and helm-controller, and empty
   under `helm template`, where this guard is therefore silent.
2. gitops.namespace set to another namespace: the platform HelmReleases would
   then name a tenant ServiceAccount (agent-platform-flux) that exists only in
   the release namespace. The exempt-namespace layout is the fleet's, and the
   fleet runs with the engine off.

And one with the engine off: turning it off on an installation that runs it.
`helm upgrade` deletes the objects that left the manifest in one pass — the
operator together with the FluxInstance whose finalizer it processes — and
hangs like an unordered uninstall would; the pre-delete hooks do not run on an
upgrade. Looked up only when the FluxInstance API is served and gitops.namespace
is empty (a CLI installation with the engine never sets it, see 2.), so the
fleet's render — engine off, exempt namespace — makes no API call at all.
*/}}
{{- define "agent-platform.validateEngine" -}}
{{- if ne (include "agent-platform.engineEnabled" .) "true" -}}
{{- if and (not .Values.gitops.namespace) (.Capabilities.APIVersions.Has "fluxcd.controlplane.io/v1") -}}
{{- $own := lookup "fluxcd.controlplane.io/v1" "FluxInstance" .Release.Namespace "flux" -}}
{{- if and $own (eq (dig "metadata" "labels" "app.kubernetes.io/instance" "" $own) .Release.Name) -}}
{{- fail (printf "components.flux.enabled=false on an installation that runs the bundled Flux engine (FluxInstance %s/flux belongs to release %s): the upgrade would delete the operator together with the FluxInstance it finalizes and hang. Uninstall the release instead (helm uninstall --wait tears it down in order), or delete the FluxInstance first" .Release.Namespace .Release.Name) -}}
{{- end -}}
{{- end -}}
{{- else -}}
{{- $ns := .Values.gitops.namespace -}}
{{- if and $ns (ne $ns .Release.Namespace) -}}
{{- fail (printf "gitops.namespace=%s cannot be combined with the bundled Flux engine: the platform HelmReleases run as the tenant ServiceAccount agent-platform-flux, which the engine renders in the release namespace (%s). Leave gitops.namespace empty, or set components.flux.enabled=false on a cluster that runs its own Flux" $ns .Release.Namespace) -}}
{{- end -}}
{{- $foreign := list -}}
{{- range ((lookup "apps/v1" "Deployment" "" "").items | default list) -}}
{{- if and (eq (dig "metadata" "labels" "app.kubernetes.io/component" "" .) "helm-controller") (ne .metadata.namespace $.Release.Namespace) -}}
{{- $foreign = append $foreign (printf "Deployment %s/%s" .metadata.namespace .metadata.name) -}}
{{- end -}}
{{- end -}}
{{- if .Capabilities.APIVersions.Has "fluxcd.controlplane.io/v1" -}}
{{- range ((lookup "fluxcd.controlplane.io/v1" "FluxInstance" "" "").items | default list) -}}
{{- if ne .metadata.namespace $.Release.Namespace -}}
{{- $foreign = append $foreign (printf "FluxInstance %s/%s" .metadata.namespace .metadata.name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- with $foreign -}}
{{- fail (printf "this cluster runs Flux; set components.flux.enabled=false or install the chart through it (found %s)" (join ", " .)) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The target cluster's kubeconfig Secret (gitops.target.kubeConfig.secretRef.name,
giantswarm/agent-platform#328): its name when this release installs its
components into another cluster, "" otherwise. One release of this chart per
target cluster — the slices are toggles in its values, never two releases of the
chart on one cluster (both need the same cluster-scoped CRDs).
*/}}
{{- define "agent-platform.targetSecretName" -}}
{{- dig "target" "kubeConfig" "secretRef" "name" "" (.Values.gitops | default dict) -}}
{{- end -}}

{{/*
The namespace the component releases install their workloads into on the
cluster they land on: gitops.targetNamespace; empty, the release namespace, or
with the target knob `agent-platform` — the release namespace is an org
namespace of the installation, and on the target the components get a
namespace of the platform's own (giantswarm/agent-platform#688).
Usage: include "agent-platform.targetNamespace" .
*/}}
{{- define "agent-platform.targetNamespace" -}}
{{- .Values.gitops.targetNamespace | default (ternary "agent-platform" .Release.Namespace (ne (include "agent-platform.targetSecretName" .) "")) -}}
{{- end -}}

{{/*
The name of a component's OCIRepository and HelmRelease on the installation:
the component's chart name; with the target knob `<gitops.target.name>-<chart>`
(target.name empty = the release name), so two targeted releases in one
namespace never share a child (giantswarm/agent-platform#688).
Usage: include "agent-platform.childName" (dict "root" $ "name" $chart)
*/}}
{{- define "agent-platform.childName" -}}
{{- if include "agent-platform.targetSecretName" .root -}}
{{- printf "%s-%s" (dig "target" "name" "" .root.Values.gitops | default .root.Release.Name) .name -}}
{{- else -}}
{{- .name -}}
{{- end -}}
{{- end -}}

{{/*
The name of a component's OCIRepository, which its HelmRelease's chartRef names:
the child name, and for a chart released with this chart at an exact version
(components.<name>.releasedWithChart) `<child>-<version>`. Helm applies the two
objects in kind order, HelmRelease before OCIRepository, so with one name for
every version helm-controller would apply a step's new values to the previous
chart, whose closed schema refuses a key the step adds, and spend a retry
(giantswarm/agent-platform#1019). A versioned name moves the version into the
HelmRelease's own spec: helm-controller waits until the source of that name
holds that version's artifact, and the previous source is pruned with the step.
A range or a dev channel keeps the child name.
Usage: include "agent-platform.sourceName" (dict "child" $child "entry" $c "semver" $semver)
*/}}
{{- define "agent-platform.sourceName" -}}
{{- if and .entry.releasedWithChart (regexMatch "^v?[0-9]+\\.[0-9]+\\.[0-9]+(-[0-9A-Za-z.-]+)?$" .semver) -}}
{{- printf "%s-%s" .child (regexReplaceAll "[^a-z0-9.-]+" (lower (trimPrefix "v" .semver)) "-") -}}
{{- else -}}
{{- .child -}}
{{- end -}}
{{- end -}}

{{/*
Render guard of the target knob: the components install into the target through
the installation's helm-controller, so the bundled engine has no place in such a
release — no Flux is ever installed into a workload cluster, nor into a cluster
that runs one.
*/}}
{{- define "agent-platform.validateTarget" -}}
{{- with (include "agent-platform.targetSecretName" .) -}}
{{- if eq (include "agent-platform.engineEnabled" $) "true" -}}
{{- fail (printf "gitops.target.kubeConfig.secretRef.name=%s cannot be combined with the bundled Flux engine: the components install into the target cluster through the installation's helm-controller, and no Flux is installed into a workload cluster or into a cluster that runs one. Set components.flux.enabled=false" .) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
One owner per cluster-scoped component (components.<name>.ownedCrds): a CRD the
component installs that already exists and whose Flux labels name another
HelmRelease than the one this render produces (<gitops.namespace | release
namespace>/<chart>) fails the render naming that release. helm-controller stamps
helm.toolkit.fluxcd.io/name and /namespace on every object of a release, the
crds/ directory's CRDs included, so the labels are the owner. A CRD without them
is left to Helm as before (adoption is not this chart's). Skipped with
gitops.target set: the lookups see the installation while the components land
on the target, so there the detection is the composer's. `lookup` is empty
under `helm template`, where this guard is therefore silent.
*/}}
{{- define "agent-platform.validateCrdOwners" -}}
{{- if not (include "agent-platform.targetSecretName" .) -}}
{{- $ns := .Values.gitops.namespace | default .Release.Namespace -}}
{{- $foreign := list -}}
{{- range $key, $c := .Values.components -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" $ "name" $key)) (hasKey $c "chart") -}}
{{- range ($c.ownedCrds | default list) -}}
{{- with (lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" .) -}}
{{- $owner := dig "metadata" "labels" "helm.toolkit.fluxcd.io/name" "" . -}}
{{- $ownerNs := dig "metadata" "labels" "helm.toolkit.fluxcd.io/namespace" "" . -}}
{{- if and $owner (or (ne $owner $key) (ne $ownerNs $ns)) -}}
{{- $foreign = append $foreign (printf "%s (components.%s) belongs to HelmRelease %s/%s" .metadata.name $key $ownerNs $owner) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- with $foreign -}}
{{- fail (printf "a cluster-scoped component has exactly one owner per cluster, and release %s (HelmReleases in %s) would be a second one: %s. Remove that release first, or set components.<name>.enabled=false here — a slice release beside the platform's own leaves the controller and its CRDs to the platform's release" $.Release.Name $ns (join "; " .)) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
One GPU operator per cluster (components.gpu-operator, giantswarm/agent-platform#327).
NVIDIA's operator owns one ClusterPolicy and one set of DaemonSets, so with the
component on the render fails when the cluster it renders against already runs an
operator that is not this release's: a ClusterPolicy whose owner — the Flux labels
helm.toolkit.fluxcd.io/name + /namespace, else Helm's meta.helm.sh/release-name +
/release-namespace annotations — is another release or none; a HelmRelease of the
gpu-operator chart under another name or in another namespace (cluster-manager's
<cluster>-gpu-operator, before or after its ClusterPolicy exists); an App of it.
The message names what was seen and the handover: delete that release
(cluster-manager's detection then sees this component and never re-creates it),
then switch the toggle on — or leave it off. Adopting the running objects is not
this chart's. Skipped with the target knob, as agent-platform.validateCrdOwners
is: the lookups see the installation while the component lands on the target,
where the detection is cluster-manager's. Each lookup is gated on its API being
served, and `lookup` is empty under `helm template`, where the guard is silent —
tests/fixtures/gpu-operator-foreign-owner.yaml on a cluster and --dry-run=server
show it (README, "The GPU operator").
*/}}
{{- define "agent-platform.validateGpuOperatorOwner" -}}
{{- $c := index .Values.components "gpu-operator" | default dict -}}
{{- if and $c (eq (include "agent-platform.componentEnabled" (dict "root" . "name" "gpu-operator")) "true") (not (include "agent-platform.targetSecretName" .)) -}}
{{- $ns := .Values.gitops.namespace | default .Release.Namespace -}}
{{- $release := "gpu-operator" -}}
{{- $releaseNs := $c.targetNamespace | default (include "agent-platform.targetNamespace" .) -}}
{{- $foreign := list -}}
{{- if .Capabilities.APIVersions.Has "nvidia.com/v1" -}}
{{- range ((lookup "nvidia.com/v1" "ClusterPolicy" "" "").items | default list) -}}
{{- $fluxName := dig "metadata" "labels" "helm.toolkit.fluxcd.io/name" "" . -}}
{{- $fluxNs := dig "metadata" "labels" "helm.toolkit.fluxcd.io/namespace" "" . -}}
{{- $helmName := dig "metadata" "annotations" "meta.helm.sh/release-name" "" . -}}
{{- $helmNs := dig "metadata" "annotations" "meta.helm.sh/release-namespace" "" . -}}
{{- if $fluxName -}}
{{- if or (ne $fluxName $release) (ne $fluxNs $ns) -}}
{{- $foreign = append $foreign (printf "ClusterPolicy %s belongs to HelmRelease %s/%s (labels helm.toolkit.fluxcd.io/name=%s, helm.toolkit.fluxcd.io/namespace=%s)" .metadata.name $fluxNs $fluxName $fluxName $fluxNs) -}}
{{- end -}}
{{- else if $helmName -}}
{{- if or (ne $helmName $release) (ne $helmNs $releaseNs) -}}
{{- $foreign = append $foreign (printf "ClusterPolicy %s belongs to the Helm release %s in %s (annotations meta.helm.sh/release-name=%s, meta.helm.sh/release-namespace=%s — installed by hand or as an App)" .metadata.name $helmName $helmNs $helmName $helmNs) -}}
{{- end -}}
{{- else -}}
{{- $foreign = append $foreign (printf "ClusterPolicy %s carries no owner (no helm.toolkit.fluxcd.io/name label, no meta.helm.sh/release-name annotation)" .metadata.name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if .Capabilities.APIVersions.Has "helm.toolkit.fluxcd.io/v2" -}}
{{- range ((lookup "helm.toolkit.fluxcd.io/v2" "HelmRelease" "" "").items | default list) -}}
{{- $chart := dig "spec" "chart" "spec" "chart" "" . -}}
{{- $chartRef := dig "spec" "chartRef" "name" "" . -}}
{{- if and (or (eq $chart $release) (eq $chartRef $release) (hasSuffix "-gpu-operator" $chartRef) (hasSuffix "-gpu-operator" .metadata.name)) (not (and (eq .metadata.name $release) (eq .metadata.namespace $ns))) -}}
{{- $foreign = append $foreign (printf "HelmRelease %s/%s installs the operator" .metadata.namespace .metadata.name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if .Capabilities.APIVersions.Has "application.giantswarm.io/v1alpha1" -}}
{{- range ((lookup "application.giantswarm.io/v1alpha1" "App" "" "").items | default list) -}}
{{- if eq (dig "spec" "name" "" .) $release -}}
{{- $foreign = append $foreign (printf "App %s/%s installs the operator" .metadata.namespace .metadata.name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- with $foreign -}}
{{- fail (printf "components.gpu-operator.enabled=true, but this cluster already runs a GPU operator, and NVIDIA's operator is one per cluster (one ClusterPolicy, one set of DaemonSets): %s. This release would be a second owner (HelmRelease %s/%s, the Helm release %s in %s). Hand the operator over first: delete that release — cluster-manager's <cluster>-gpu-operator, whose detection then sees this component and never re-creates it, or the operator installed by hand — then switch the toggle on; or leave components.gpu-operator.enabled=false and keep the operator where it is. Adopting the running objects is not this chart's. The component configures the operator from the gpu-operator block, one of two rows: Flatcar — driver and toolkit off (the default); nodes with a pre-installed driver — gpu-operator.toolkit.enabled=true" (join "; " .) $ns $release $release $releaseNs) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Names of the platform HelmReleases this chart renders (every enabled roster
entry with a chart, by its key), in roster order. The teardown hook deletes exactly these.
Usage: include "agent-platform.platformReleaseNames" . | fromYamlArray
*/}}
{{- define "agent-platform.platformReleaseNames" -}}
{{- $names := list -}}
{{- range $key, $c := .Values.components -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" $ "name" $key)) (hasKey $c "chart") -}}
{{- $names = append $names $key -}}
{{- end -}}
{{- end -}}
{{- toYaml $names -}}
{{- end -}}

{{/*
The platform HelmReleases in teardown order: waves of release names, each wave
the releases no release still standing dependsOn — so a release is uninstalled
only after every release whose objects are its CRs. Helm's uninstall deletes a
release's objects and fails ("failed to delete release: <name>") when one of
their kinds is already gone — its CRD chart uninstalled first — and
helm-controller then retries that uninstall until the teardown hook times out
(measured on the ATS kind smoke: substrate's SandboxConfig racing
substrate-crds). The releases of one wave uninstall concurrently. The graph is
the roster's dependsOn, filtered as components.yaml filters it (a reference to a
toggled-off component names no release); a cycle fails the render.
Usage: include "agent-platform.teardownWaves" . | fromYamlArray  (a list of lists)
*/}}
{{- define "agent-platform.teardownWaves" -}}
{{- $root := . -}}
{{- $deps := dict -}}
{{- range $key, $c := .Values.components -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" $root "name" $key)) (hasKey $c "chart") -}}
{{- $on := list -}}
{{- range ($c.dependsOn | default list) -}}
{{- if and (hasKey $root.Values.components .) (include "agent-platform.componentEnabled" (dict "root" $root "name" .)) (hasKey (index $root.Values.components .) "chart") -}}
{{- $on = append $on . -}}
{{- end -}}
{{- end -}}
{{- $_ := set $deps $key $on -}}
{{- end -}}
{{- end -}}
{{- $waves := list -}}
{{- $remaining := keys $deps | sortAlpha -}}
{{- range until (len $deps) -}}
{{- if $remaining -}}
{{- $wave := list -}}
{{- range $name := $remaining -}}
{{- $needed := false -}}
{{- range $other := $remaining -}}
{{- if has $name (index $deps $other) -}}{{- $needed = true -}}{{- end -}}
{{- end -}}
{{- if not $needed -}}{{- $wave = append $wave $name -}}{{- end -}}
{{- end -}}
{{- if not $wave -}}{{- fail (printf "components.*.dependsOn is cyclic among %s; the ordered teardown needs an acyclic graph" (join ", " $remaining)) -}}{{- end -}}
{{- $waves = append $waves $wave -}}
{{- $next := list -}}
{{- range $name := $remaining -}}{{- if not (has $name $wave) -}}{{- $next = append $next $name -}}{{- end -}}{{- end -}}
{{- $remaining = $next -}}
{{- end -}}
{{- end -}}
{{- toYaml $waves -}}
{{- end -}}

{{/*
The teardown-releases hook's script: one `kubectl delete --wait` per wave of
agent-platform.teardownWaves, in gitops.namespace (the release namespace with
the engine on). Each wave's releases uninstall concurrently; the next wave
starts when helm-controller has removed the last HelmRelease of the previous one.
*/}}
{{- define "agent-platform.teardownScript" -}}
{{- $ns := .Values.gitops.namespace | default .Release.Namespace -}}
# The platform HelmReleases in reverse dependency order (a CRD chart's release
# only after the releases whose objects are its CRs); kubectl waits for
# helm-controller to uninstall a wave before the next one starts.
{{- range $i, $wave := include "agent-platform.teardownWaves" . | fromYamlArray }}
echo "wave {{ add1 $i }}: {{ join " " $wave }}"
kubectl delete helmreleases.helm.toolkit.fluxcd.io --namespace {{ $ns }} --ignore-not-found --wait --timeout=5m {{ join " " $wave }}
{{- end }}
{{- end -}}

{{/*
Self-management resolved: "true" when this release renders its own
OCIRepository + HelmRelease (templates/self/) and the admission policy that
makes the Helm CLI day-0 only, empty otherwise. gitops.self.enabled is
`auto` (follows the bundled engine: components.flux.enabled), `true` or
`false`. `true` without the engine is refused: on a cluster that runs its own
Flux that Flux holds the chart's HelmRelease (README, "Clusters that run
Flux"), and a self HelmRelease under a foreign helm-controller would run as
whatever account that controller impersonates.
*/}}
{{- define "agent-platform.selfEnabled" -}}
{{- $v := (.Values.gitops.self | default dict).enabled -}}
{{- $engine := eq (include "agent-platform.engineEnabled" .) "true" -}}
{{- if or (kindIs "invalid" $v) (and (kindIs "string" $v) (eq $v "auto")) -}}
{{- if $engine }}true{{ end -}}
{{- else if eq (toString $v) "true" -}}
{{- if not $engine -}}
{{- fail "gitops.self.enabled=true needs the bundled Flux engine (components.flux.enabled=true): with the engine off, the cluster's own Flux holds this chart's HelmRelease (README, Clusters that run Flux). Set gitops.self.enabled to auto (the default) or false" -}}
{{- end -}}
true
{{- else if eq (toString $v) "false" -}}
{{- else -}}
{{- fail (printf "gitops.self.enabled=%v is not one of auto, true, false" $v) -}}
{{- end -}}
{{- end -}}

{{/*
The identity the self-management hooks run as: a ServiceAccount in the release
namespace with a namespaced Role (templates/self/rbac.yaml) — a regular chart
object, not a hook: the detached resumer Job runs AFTER the post-install hooks
completed, when a hook-managed ServiceAccount (hook-succeeded) is already gone.
*/}}
{{- define "agent-platform.self.serviceAccountName" -}}
{{- printf "%s-self" .Release.Name -}}
{{- end -}}

{{/*
The Secret the self HelmRelease reads its values from (valuesFrom, optional:
false) and the values hook writes (the USER-SUPPLIED values of the release —
`helm get values` — never the merged tree, which would pin every component
versionRange at first-install time). Fixed name: the admission policy's message
and the README name it.
*/}}
{{- define "agent-platform.self.valuesSecretName" -}}
agent-platform-values
{{- end -}}

{{/*
The ValidatingAdmissionPolicy (cluster-scoped) and its binding that make the
Helm CLI day-0 only, one pair per release: <release>-self-managed-<namespace>.
*/}}
{{- define "agent-platform.self.policyName" -}}
{{- printf "%s-self-managed-%s" .Release.Name .Release.Namespace -}}
{{- end -}}

{{/*
The hand-back annotation on the release namespace: with it present the
admission policy admits the Helm CLI's storage write again, so
`helm upgrade --set gitops.self.enabled=false --force-conflicts` can hand the
release back to the CLI.
*/}}
{{- define "agent-platform.self.handBackAnnotation" -}}
agent-platform.giantswarm.io/helm-cli
{{- end -}}

{{/*
The ServiceAccount the self HelmRelease runs as and the only identity the
admission policy admits to write this release's Helm storage: the bundled
engine's tenant identity, or gitops.serviceAccountName when set (the same
resolution the platform HelmReleases use in components.yaml).
*/}}
{{- define "agent-platform.self.releaseServiceAccountName" -}}
{{- .Values.gitops.serviceAccountName | default (include "agent-platform.tenantServiceAccountName" .) -}}
{{- end -}}

{{/*
Semver range the self OCIRepository follows. gitops.self.versionRange when set;
otherwise derived from the running chart's version: `>=<version> <next
major>.0.0` — a release follows patch and minor releases of its own major, never
a downgrade (a fixed floor would let source-controller pick a LOWER tag than the
one the CLI just installed), and the range moves forward with every version
the controller applies. Build metadata (helm-controller renders the chart as
<version>+<oci digest>) is dropped; a pre-release floor is kept.
*/}}
{{- define "agent-platform.self.versionRange" -}}
{{- (include "agent-platform.self.ref" . | fromJson).range -}}
{{- end -}}

{{/*
The self-management OCIRepository's range as written or derived, and whether
gitops.prereleases widened it to admit pre-releases, as JSON {"range",
"admits"}; a range with a semverFilter of its own is left as written.
*/}}
{{- define "agent-platform.self.ref" -}}
{{- $range := .Values.gitops.self.versionRange | default (printf ">=%s <%d.0.0" (include "agent-platform.chartVersion" .) (add1 (semver .Chart.Version).Major)) -}}
{{- if and .Values.gitops.prereleases (not .Values.gitops.self.semverFilter) -}}
{{- include "agent-platform.admitPrereleases" (dict "range" $range "key" "gitops.self.versionRange") -}}
{{- else -}}
{{- dict "range" $range "admits" false | toJson -}}
{{- end -}}
{{- end -}}

{{/*
gitops.prereleases on the agent chart line agent-manager composes into every
agent's OCIRepository (agent-manager.agentChart): its semver admits
pre-releases and its semverFilter is the release tag filter, as for the
components' ranges. A block with a semverFilter of its own is left as written.
agent-manager reads agentChart.semverFilter since giantswarm/agent-manager#86.
*/}}
{{- define "agent-platform.prereleases.apply" -}}
{{- if .root.Values.gitops.prereleases -}}
{{- $chart := dig "agentChart" nil (index .values "agent-manager" | default dict) -}}
{{- if and (kindIs "map" $chart) $chart.semver (not $chart.semverFilter) -}}
{{- $widened := include "agent-platform.admitPrereleases" (dict "range" (toString $chart.semver) "key" "agent-manager.agentChart.semver") | fromJson -}}
{{- $_ := set $chart "semver" $widened.range -}}
{{- if $widened.admits -}}
{{- $_ := set $chart "semverFilter" (include "agent-platform.releaseTagFilter" .root) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The self-management OCIRepository's tag filter: gitops.self.semverFilter, else
the release tag filter where gitops.prereleases widens the self range.
*/}}
{{- define "agent-platform.self.semverFilter" -}}
{{- if .Values.gitops.self.semverFilter -}}
{{- .Values.gitops.self.semverFilter -}}
{{- else if (include "agent-platform.self.ref" . | fromJson).admits -}}
{{- include "agent-platform.releaseTagFilter" . -}}
{{- end -}}
{{- end -}}

{{/*
The tags a range widened by gitops.prereleases may select: stable releases and
release candidates (X.Y.Z, X.Y.Z-rc.N). The branch builds pushed to the same
repositories (gitsemver's dev shape X.Y.Z-r<hash>t<time>h<sha>, and the older
X.Y.Z-dev.<branch>...) carry a pre-release too, and a `-0` range alone would
select them.
*/}}
{{- define "agent-platform.releaseTagFilter" -}}
^v?[0-9]+\.[0-9]+\.[0-9]+(-rc\.[0-9]+)?$
{{- end -}}

{{/*
A semver range that also admits pre-release versions (gitops.prereleases), as
JSON {"range": ..., "admits": bool}. Flux (Masterminds/semver v3) evaluates
pre-releases for a range only when one of its comparators carries one, so a
comparator that carries none gets `-0`: ">=5.31.4 <6.0.0" is
">=5.31.4-0 <6.0.0-0", "0.x" is "0.x-0". Left as written: an exact version
(`1.2.3`, `=1.2.3`, `==1.2.3`), which `-0` would turn into a version that does
not exist, an exclusion (`!=1.2.3`), which `-0` would stop excluding, and a
comparator that carries a pre-release already. `admits` says the range selects
pre-releases: false for a range of exact versions and exclusions only, which
stays as written with no tag filter. Comparators are split on spaces; `||`
passes through. A range with no version at all (`*`) fails the render rather
than silently staying stable-only.
*/}}
{{- define "agent-platform.admitPrereleases" -}}
{{- $version := "^([<>=~^!]*)(v?[0-9]+(\\.([0-9]+|[xX*])){0,2})(-[0-9A-Za-z.-]+)?(,?)$" -}}
{{- $exactCore := "^v?[0-9]+\\.[0-9]+\\.[0-9]+$" -}}
{{- $out := list -}}
{{- $versions := false -}}
{{- $admits := false -}}
{{- range (splitList " " .range) -}}
{{- if regexMatch $version . -}}
{{- $versions = true -}}
{{- $op := regexReplaceAll $version . "${1}" -}}
{{- $core := regexReplaceAll $version . "${2}" -}}
{{- $pre := regexReplaceAll $version . "${5}" -}}
{{- if $pre -}}
{{- $out = append $out . -}}
{{- $admits = true -}}
{{- else if or (eq $op "!=") (and (has $op (list "" "=" "==")) (regexMatch $exactCore $core)) -}}
{{- $out = append $out . -}}
{{- else -}}
{{- $out = append $out (regexReplaceAll $version . "${1}${2}-0${6}") -}}
{{- $admits = true -}}
{{- end -}}
{{- else -}}
{{- $out = append $out . -}}
{{- end -}}
{{- end -}}
{{- if not $versions -}}
{{- fail (printf "gitops.prereleases: %s=%q has no version to admit pre-releases for; write the range with explicit bounds (>=A <B)" .key .range) -}}
{{- end -}}
{{- dict "range" (join " " $out) "admits" $admits | toJson -}}
{{- end -}}

{{/*
This chart's own version as its releases are published: <major>.<minor>.<patch>
with a pre-release kept (a dev build is X.Y.Z-r<branch-hash>t<time>h<sha>, one
version for the two charts of a commit) and build metadata dropped
(helm-controller renders the chart as <version>+<oci digest>). The floor of
the self range above, and the exact version of every component released off
the same tag as this chart (components.<name>.releasedWithChart).
*/}}
{{- define "agent-platform.chartVersion" -}}
{{- $v := semver .Chart.Version -}}
{{- $out := printf "%d.%d.%d" $v.Major $v.Minor $v.Patch -}}
{{- with $v.Prerelease }}{{ $out = printf "%s-%s" $out . }}{{ end -}}
{{- $out -}}
{{- end -}}

{{/*
Render guard of self-management, evaluated only when it is on: the hand-back
annotation together with self-management on. The policy would admit the Helm
CLI while the bundled helm-controller holds the release — two writers on one
release, which is what the whole shape forbids (a CLI revision pending while
the controller reconciles is unlocked and upgraded with whatever the values
Secret holds). The hand-back upgrade carries gitops.self.enabled=false; a stale
annotation is removed. `lookup` is live under the Helm CLI, --dry-run=server
and helm-controller (where the guard surfaces on the self HelmRelease for the
duration of a hand-back), empty under `helm template`.
*/}}
{{- define "agent-platform.validateSelf" -}}
{{- if eq (include "agent-platform.selfEnabled" .) "true" -}}
{{- $ns := lookup "v1" "Namespace" "" .Release.Namespace -}}
{{- $ann := include "agent-platform.self.handBackAnnotation" . -}}
{{- if and $ns (eq (dig "metadata" "annotations" $ann "" $ns) "allow") -}}
{{- fail (printf "namespace %s carries the hand-back annotation %s=allow while gitops.self.enabled resolves to true: the Helm CLI and the bundled helm-controller would both write release %s. Finish the hand-back — helm upgrade … --set gitops.self.enabled=false --force-conflicts — or remove the annotation to keep the release self-managed" .Release.Namespace $ann .Release.Name) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The helm-and-shell image the hooks that need helm run (gitops.hooks.helmImage).
*/}}
{{- define "agent-platform.hooks.helmImage" -}}
{{- $i := .Values.gitops.hooks.helmImage -}}
{{- include "agent-platform.mirror.ref" (dict "ref" (printf "%s/%s:%s" $i.registry $i.repository $i.tag) "mirror" (include "agent-platform.mirror.registry" .)) -}}
{{- end -}}

{{/*
=== Kyverno PolicyExceptions ===

The `exceptions:` list of a PolicyException from the rules one workload
violates: each rule is looked up in kyvernoPolicies.rules (rule → the
ClusterPolicy of the cluster's PSS set; a rule without an entry fails the
render naming it), the rules are grouped by policy, and each rule is cited
with its autogen-<rule> — the copy Kyverno generates for the controller kinds
(Deployment, DaemonSet, ...) a pod-level rule matches through. Rendered as YAML
list items; the caller provides the `exceptions:` key.
Usage: include "agent-platform.kyverno.exceptions" (dict "root" $ "rules" (list "host-path" "privileged-containers"))
*/}}
{{- define "agent-platform.kyverno.exceptions" -}}
{{- $root := .root -}}
{{- $byPolicy := dict -}}
{{- range .rules -}}
{{- $policy := index ($root.Values.kyvernoPolicies.rules | default dict) . -}}
{{- if not $policy -}}
{{- fail (printf "kyvernoPolicies.rules names no ClusterPolicy for the rule %q; add `%s: <policy>` (the PSS policy of the cluster's kyverno-policies chart that carries the rule)" . .) -}}
{{- end -}}
{{- $_ := set $byPolicy $policy (append (index $byPolicy $policy | default list) .) -}}
{{- end -}}
{{- range $policy, $rules := $byPolicy }}
- policyName: {{ $policy }}
  ruleNames:
  {{- range $rules }}
    - {{ . }}
    - autogen-{{ . }}
  {{- end }}
{{- end }}
{{- end -}}

{{/*
"true" while agentPlatformOrganizations.enabled is on, else empty; the label of
the organizations' namespaces, as the connectivity chart selects them.
*/}}
{{- define "agent-platform.organizations.on" -}}
{{- if dig "enabled" false (.Values.agentPlatformOrganizations | default dict) }}true{{ end -}}
{{- end -}}

{{- define "agent-platform.orgNamespaces.label" -}}
agent-platform.giantswarm.io/organization
{{- end -}}

{{/*
The workers' network policies a keeper of an organization namespace copies
from the kagent namespace, by flavor, as a JSON list (the connectivity
chart's substrate/netpol.yaml renders them).
Usage: include "agent-platform.workerPolicyNames" (dict "flavor" $flavor) | fromJsonArray
*/}}
{{- define "agent-platform.workerPolicyNames" -}}
{{- if eq .flavor "cilium" -}}
{{- list "substrate-workers" | toJson -}}
{{- else -}}
{{- list "substrate-workers-ingress" "substrate-workers-egress" | toJson -}}
{{- end -}}
{{- end -}}

{{/*
agent-platform-operator's names, as JSON, made in this one place
(giantswarm/agent-platform#1278). This chart installs the operator and tells
it these names; it derives them onto the connectivity release too
(agentPlatformOrganizations.operator), whose policies, bindings, network
policies and objects for the operator read them there and hold no copy:
  - serviceAccountName: the operator's chart names its ServiceAccount after
    itself (.Chart.Name), the chart components.agent-platform-operator
    installs;
  - podLabels: its pods' selector label app.kubernetes.io/name, the same name;
  - snapshotSecret, with RustFS (substrate.rustfs.enabled): the Secret of
    RustFS's keys the connectivity chart renders beside the operator, its
    snapshots.credentials.existingSecret;
  - awsRoleName, with the Crossplane AWS snapshot store: the IAM role the
    connectivity chart renders for the operator beside Substrate's, the
    store's role name and -operator, named on the operator's ServiceAccount
    (IRSA). IAM takes 64 characters; a longer name fails the render rather
    than be cut, which could give it Substrate's role's name.
Usage: include "agent-platform.organizations.operator" . | fromJson
*/}}
{{- define "agent-platform.organizations.operator" -}}
{{- $name := (index .Values.components "agent-platform-operator").chart -}}
{{- $out := dict "serviceAccountName" $name "podLabels" (dict "app.kubernetes.io/name" $name) -}}
{{- if dig "rustfs" "enabled" false (.Values.substrate | default dict) -}}
{{- $_ := set $out "snapshotSecret" "substrate-rustfs-operator" -}}
{{- end -}}
{{- if eq (include "agent-platform.substrateStore.crossplane" .) "aws" -}}
{{- $role := printf "%s-operator" (include "agent-platform.substrateStore.awsRoleName" .) -}}
{{- if gt (len $role) 64 -}}
{{- fail (printf "agentPlatformOrganizations: the operator's IAM role %s is longer than 64 characters: set a shorter kagent.harness.snapshotStore.crossplane.aws.roleName (at most 55)" $role) -}}
{{- end -}}
{{- $_ := set $out "awsRoleName" $role -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
agent-platform-operator's ServiceAccount, as JSON {name, namespace}: the name
of agent-platform.organizations.operator, in the connectivity release's
namespace, where the component installs (agent-platform.validateOrganizations
refuses another) and where the connectivity chart names it with the name this
chart derives (agent-platform.organizations.operatorServiceAccount there).
*/}}
{{- define "agent-platform.organizations.operatorServiceAccount" -}}
{{- $connNs := dig "agent-platform-connectivity" "targetNamespace" "" .Values.components | default (include "agent-platform.targetNamespace" .) -}}
{{- dict "name" (include "agent-platform.organizations.operator" . | fromJson).serviceAccountName "namespace" $connNs | toJson -}}
{{- end -}}

{{/*
Fail the render for an organizations setup that cannot work
(agentPlatformOrganizations.enabled, giantswarm/giantswarm#38891):
  - an explicit components.agent-platform-operator.enabled that disagrees
    with the switch, or a targetNamespace other than the connectivity
    release's (the policies there name the operator's ServiceAccount in it);
  - an own agentPlatformOrganizations.operator value: the chart derives it;
  - the switch on without kagent or Agent Substrate: the operator copies the
    curated kagent objects and the WorkerPool, and its cleanup process asks ate-api;
    without kagent.fluxServiceAccountName, without the llm listener's routing
    of ModelConfigs (llmRouting.enabled, llmRouting.modelConfigPolicy.enabled),
    and without the installation's API hostnames (global.domain or
    agentPlatformOrganizations.apiHostnames).
*/}}
{{- define "agent-platform.validateOrganizations" -}}
{{- $on := include "agent-platform.organizations.on" . -}}
{{- $c := index .Values.components "agent-platform-operator" | default dict -}}
{{- if and (hasKey $c "enabled") (not (kindIs "invalid" $c.enabled)) (ne (toString $c.enabled) (toString (eq $on "true"))) -}}
{{- fail (printf "components.agent-platform-operator.enabled is %v but agentPlatformOrganizations.enabled is %v: the operator follows the one switch — set agentPlatformOrganizations.enabled and leave components.agent-platform-operator.enabled unset" $c.enabled (eq $on "true")) -}}
{{- end -}}
{{- range $k, $v := dig "operator" dict (.Values.agentPlatformOrganizations | default dict) | default dict -}}
{{- if $v -}}
{{- fail (printf "agentPlatformOrganizations.operator.%s is set: the chart derives agent-platform-operator's names (agent-platform.organizations.operator) — leave agentPlatformOrganizations.operator unset" $k) -}}
{{- end -}}
{{- end -}}
{{- if $on -}}
{{- $op := include "agent-platform.organizations.operatorServiceAccount" . | fromJson -}}
{{- with $c.targetNamespace -}}
{{- if ne . $op.namespace -}}
{{- fail (printf "components.agent-platform-operator.targetNamespace (%s) differs from the connectivity release's namespace (%s): the admission policies and bindings there name the operator's ServiceAccount in that namespace — leave it unset" . $op.namespace) -}}
{{- end -}}
{{- end -}}
{{- if not (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) -}}
{{- fail "agentPlatformOrganizations.enabled needs kagent (components.kagent.enabled): agent-platform-operator copies the curated kagent objects into every organization namespace" -}}
{{- end -}}
{{- if not (include "agent-platform.componentEnabled" (dict "root" . "name" "substrate")) -}}
{{- fail "agentPlatformOrganizations.enabled needs Agent Substrate (components.substrate): an organization's agents run on its copy of the platform WorkerPool, and cleanup of a deleted organization asks ate-api until it has no actor left" -}}
{{- end -}}
{{- if not (include "agent-platform.kagent.fluxServiceAccountName" .) -}}
{{- fail "agentPlatformOrganizations.enabled needs kagent.fluxServiceAccountName: it is the operator's helmReleaseServiceAccount, the ServiceAccount an organization's HelmReleases run as" -}}
{{- end -}}
{{- if not (and (dig "enabled" false (.Values.llmRouting | default dict)) (dig "modelConfigPolicy" "enabled" true (.Values.llmRouting | default dict))) -}}
{{- fail "agentPlatformOrganizations.enabled needs llmRouting.enabled and llmRouting.modelConfigPolicy.enabled: an organization's ModelConfigs go through the llm listener, whose MutatingAdmissionPolicy fills in the base URL (an API server that serves admissionregistration.k8s.io/v1 MutatingAdmissionPolicy)" -}}
{{- end -}}
{{- if not (or .Values.global.domain (dig "apiHostnames" list (.Values.agentPlatformOrganizations | default dict))) -}}
{{- fail "agentPlatformOrganizations.enabled needs the installation's Kubernetes API hostnames: set global.domain (api.<global.domain> is derived) or agentPlatformOrganizations.apiHostnames; an organization's EgressPolicy may not name them" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The values the meta chart derives onto the agent-platform-operator release
(the agent-platform-operator block's comment lists them), as JSON. An own
value of one of these keys that differs fails the render, naming it.
*/}}
{{- define "agent-platform.operator.derived" -}}
{{- $kagent := .Values.kagent | default dict -}}
{{- $derived := dict "platformNamespace" (include "agent-platform.kagent.namespace" .) -}}
{{- $np := dict "flavor" "" "names" list -}}
{{- if .Values.networkPolicy.enabled -}}
{{- $flavor := include "agent-platform.shape.networkPolicyFlavor" . -}}
{{- $np = dict "flavor" $flavor "names" (include "agent-platform.workerPolicyNames" (dict "flavor" $flavor) | fromJsonArray) -}}
{{- end -}}
{{- $_ := set $derived "networkPolicy" $np -}}
{{- $_ := set $derived "helmReleaseServiceAccount" (include "agent-platform.kagent.fluxServiceAccountName" .) -}}
{{- /* The agent chart line, as agent-manager composes it (gitops.prereleases
widens it the same way). */ -}}
{{- $am := deepCopy (index .Values "agent-manager" | default dict) -}}
{{- include "agent-platform.prereleases.apply" (dict "root" . "values" (dict "agent-manager" $am)) -}}
{{- $chart := dig "agentChart" dict $am | default dict -}}
{{- $agentChart := dict "ociUrl" ($chart.ociUrl | default "oci://gsoci.azurecr.io/charts/giantswarm/agent") "semver" (toString ($chart.semver | default "2.x")) -}}
{{- with $chart.semverFilter }}{{- $_ := set $agentChart "semverFilter" . -}}{{- end -}}
{{- $_ := set $derived "agentChart" $agentChart -}}
{{- $_ := set $derived "curated" (dict "enabled" true "workerPool" (dig "substrateWorkerPool" "name" "" $kagent)) -}}
{{- /* The organizations' snapshots sit beside the platform Harness's, in the
same bucket (or the container behind the s3proxy façade): s3://<bucket>/<uid>. */ -}}
{{- $location := include "agent-platform.kagent.snapshotLocation" . -}}
{{- $bucket := regexReplaceAll "/.*$" (trimPrefix "s3://" $location) "" -}}
{{- if not $bucket -}}
{{- fail "agentPlatformOrganizations.enabled needs the Harness snapshot location (kagent.harness.snapshotLocation, or kagent.harness.snapshotStore): an organization's Harness copies keep their snapshots under s3://<bucket>/<organization UID> in its bucket" -}}
{{- end -}}
{{- $snapshots := include "agent-platform.operator.snapshots" . | fromJson -}}
{{- $_ := set $snapshots "bucket" $bucket -}}
{{- $aws := eq (include "agent-platform.substrateStore.crossplane" .) "aws" -}}
{{- if $aws -}}
{{- $xp := (include "agent-platform.substrateStore.block" . | fromJson).crossplane -}}
{{- with $xp.region }}{{- $_ := set $snapshots "region" . -}}{{- end -}}
{{- /* The role the connectivity chart renders beside Substrate's
(organization-erasure/crossplane-aws.yaml), named by
agent-platform.organizations.operator, in the store's account. */ -}}
{{- $role := (include "agent-platform.organizations.operator" . | fromJson).awsRoleName -}}
{{- $_ := set $derived "serviceAccount" (dict "annotations" (dict "eks.amazonaws.com/role-arn" (include "agent-platform.substrateStore.awsRoleArnOf" (dict "root" . "role" $role)))) -}}
{{- end -}}
{{- $_ := set $derived "snapshots" $snapshots -}}
{{- $ateNs := dig "substrate" "targetNamespace" "ate-system" .Values.components -}}
{{- $op := include "agent-platform.organizations.operatorServiceAccount" . | fromJson -}}
{{- $erasure := dict
      "fluxNamespace" (dig "fluxNamespace" "" (.Values.agentPlatformOrganizations | default dict))
      "kagent" (dict "target" (include "agent-platform.kagent.controllerAddress" .) "audience" (include "agent-platform.kagent.tokenAudience" .))
      "substrate" (dict "target" (printf "grpcs://api.%s.svc:443" $ateNs) "audience" (printf "api.%s.svc" $ateNs) "caClusterTrustBundle" (dict "signerName" "servicedns.podcert.ate.dev/identity" "matchLabels" (dict "podcert.ate.dev/canarying" "live"))) -}}
{{- $_ := set $derived "erasure" $erasure -}}
{{- with include "agent-platform.operator.serviceAccountBindings" . | fromJsonArray -}}
{{- $_ := set $derived "serviceAccountBindings" . -}}
{{- end -}}
{{- $own := index .Values "agent-platform-operator" | default dict -}}
{{- /* Commit mode follows the Flux values the organizations' admission policy
holds the operator's Kustomizations to: the source, the path under
fluxPathPrefix and the SOPS key Secret, so the operator writes exactly what
the policy admits. Its interval and installationKustomization (the
installation's own Kustomization that applies the organizations) are the
operator block's own. Without fluxNamespace there is no commit mode. */ -}}
{{- $orgs := .Values.agentPlatformOrganizations | default dict -}}
{{- if $orgs.fluxNamespace -}}
{{- $source := $orgs.fluxSource | default dict -}}
{{- if not $source.name -}}
{{- fail "agentPlatformOrganizations.fluxSource.name is required with fluxNamespace: an organization's Kustomization applies its path from the installation's Flux source" -}}
{{- end -}}
{{- $_ := set $derived "commitMode" (dict
      "sourceRef" (dict "kind" ($source.kind | default "GitRepository") "name" $source.name)
      "path" (printf "%s{parent}/{name}" ($orgs.fluxPathPrefix | default ""))
      "decryptionSecret" ($orgs.fluxDecryptionSecret | default "")) -}}
{{- else if dig "commitMode" "sourceRef" "name" "" $own -}}
{{- fail "agent-platform-operator.commitMode.sourceRef.name is set but agentPlatformOrganizations.fluxNamespace is not: commit mode needs the installation's Flux namespace, where the operator keeps the organizations' Kustomizations; set agentPlatformOrganizations.fluxNamespace and fluxSource, and leave agent-platform-operator.commitMode.sourceRef unset" -}}
{{- end -}}
{{- include "agent-platform.operator.checkOwn" (dict "own" $own "derived" $derived "path" "agent-platform-operator") -}}
{{- $derived | toJson -}}
{{- end -}}

{{/*
Fail when an own value under `own` differs from the derived value at the same
path (a leaf of `derived`; maps are walked, lists compared whole).
Usage: include "agent-platform.operator.checkOwn" (dict "own" $own "derived" $derived "path" "agent-platform-operator")
*/}}
{{- define "agent-platform.operator.checkOwn" -}}
{{- $own := .own -}}
{{- range $k, $v := .derived -}}
{{- $path := printf "%s.%s" $.path $k -}}
{{- if hasKey $own $k -}}
{{- $mine := index $own $k -}}
{{- if and (kindIs "map" $v) (kindIs "map" $mine) -}}
{{- include "agent-platform.operator.checkOwn" (dict "own" $mine "derived" $v "path" $path) -}}
{{- else if and (not (kindIs "invalid" $mine)) (ne (toJson $mine) (toJson $v)) -}}
{{- fail (printf "%s (%s) differs from what the chart derives (%s): agentPlatformOrganizations.enabled wires the operator to the platform — leave %s unset" $path (toJson $mine) (toJson $v) $path) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
=== The mirror (gitops.mirror, giantswarm/agent-platform#1259) ===

An air-gapped installation pulls every chart and image from one registry of its
own. gitops.mirror.registry names its host (host or host:port, no scheme, no
path); every source this chart renders on gsoci.azurecr.io moves there, the
path, tag and digest kept: the component and self-management OCIRepositories,
every string of the values forwarded to a component release (registries,
repositories, image references, oci:// chart URLs), the hook images. Empty
renders every source as written.
*/}}
{{- define "agent-platform.mirror.source" -}}gsoci.azurecr.io{{- end -}}

{{/*
The mirror host, validated; empty when unset.
Usage: include "agent-platform.mirror.registry" $root
*/}}
{{- define "agent-platform.mirror.registry" -}}
{{- $registry := toString (dig "mirror" "registry" "" .Values.gitops) -}}
{{- if and $registry (not (regexMatch "^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?(:[0-9]{1,5})?$" $registry)) -}}
{{- fail (printf "gitops.mirror.registry %q must be a registry host — host or host:port, no scheme, no path; it replaces gsoci.azurecr.io in every chart and image source, the path stays" $registry) -}}
{{- end -}}
{{- $registry -}}
{{- end -}}

{{/*
A source reference on the mirror: the source host, alone or followed by a path,
with or without oci://, is replaced by the mirror host; any other string is
returned as written.
Usage: include "agent-platform.mirror.ref" (dict "ref" $s "mirror" $registry)
*/}}
{{- define "agent-platform.mirror.ref" -}}
{{- $ref := toString .ref -}}
{{- $source := include "agent-platform.mirror.source" . -}}
{{- $scheme := "" -}}
{{- if hasPrefix "oci://" $ref -}}{{- $scheme = "oci://" -}}{{- $ref = trimPrefix "oci://" $ref -}}{{- end -}}
{{- if and .mirror (or (eq $ref $source) (hasPrefix (printf "%s/" $source) $ref)) -}}
{{- printf "%s%s%s" $scheme .mirror (trimPrefix $source $ref) -}}
{{- else -}}
{{- printf "%s%s" $scheme $ref -}}
{{- end -}}
{{- end -}}

{{/*
Move every source reference of a values tree onto the mirror, in place: maps
and lists are walked, each string is passed through agent-platform.mirror.ref.
Numbers and booleans stay untouched (no JSON round trip). Keys that name DNS
names rather than sources (Cilium FQDN selectors: fqdns, matchName,
matchPattern) are left as written: a host:port is no FQDN. A list nested
directly in a list is kept as written too; no values carry one.
Usage: include "agent-platform.mirror.values" (dict "values" $vals "mirror" $registry)
*/}}
{{- define "agent-platform.mirror.values" -}}
{{- $mirror := .mirror -}}
{{- $v := .values -}}
{{- range $k, $x := $v -}}
{{- if has $k (list "fqdns" "matchName" "matchPattern") -}}
{{- else if kindIs "string" $x -}}
{{- $_ := set $v $k (include "agent-platform.mirror.ref" (dict "ref" $x "mirror" $mirror)) -}}
{{- else if kindIs "map" $x -}}
{{- include "agent-platform.mirror.values" (dict "values" $x "mirror" $mirror) -}}
{{- else if kindIs "slice" $x -}}
{{- $list := list -}}
{{- range $x -}}
{{- if kindIs "string" . -}}
{{- $list = append $list (include "agent-platform.mirror.ref" (dict "ref" . "mirror" $mirror)) -}}
{{- else -}}
{{- if kindIs "map" . -}}{{- include "agent-platform.mirror.values" (dict "values" . "mirror" $mirror) -}}{{- end -}}
{{- $list = append $list . -}}
{{- end -}}
{{- end -}}
{{- $_ := set $v $k $list -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The mirror's credentials and CA on an OCIRepository spec: secretRef and
certSecretRef from gitops.mirror, each only when set (indent 2 under spec).
Usage: include "agent-platform.mirror.sourceAuth" $root
*/}}
{{- define "agent-platform.mirror.sourceAuth" -}}
{{- $m := .Values.gitops.mirror | default dict -}}
{{- with $m.secretRef }}
secretRef:
  name: {{ . }}
{{- end }}
{{- with $m.certSecretRef }}
certSecretRef:
  name: {{ . }}
{{- end }}
{{- end -}}

{{/* The operator uses the same endpoint and credential references as the snapshot store. */}}
{{- define "agent-platform.operator.snapshots" -}}
{{- $snapshots := dict -}}
{{- $substrate := .Values.substrate | default dict -}}
{{- $namespace := dig "substrate" "targetNamespace" "ate-system" .Values.components -}}
{{- if include "agent-platform.substrateStore.s3proxy" . -}}
{{- $_ := set $snapshots "endpoint" (include "agent-platform.substrateStore.s3proxyUrl" .) -}}
{{- $_ := set $snapshots "usePathStyle" true -}}
{{- $_ := set $snapshots "region" "us-east-1" -}}
{{- $_ := set $snapshots "credentials" (dict "existingSecret" (include "agent-platform.substrateStore.s3proxyName" .)) -}}
{{- else if dig "rustfs" "enabled" false $substrate -}}
{{- $_ := set $snapshots "endpoint" (printf "http://rustfs.%s.svc:9000" $namespace) -}}
{{- $_ := set $snapshots "usePathStyle" true -}}
{{- $_ := set $snapshots "region" "us-east-1" -}}
{{- $_ := set $snapshots "credentials" (dict "existingSecret" (include "agent-platform.organizations.operator" . | fromJson).snapshotSecret) -}}
{{- else -}}
{{- range dig "ateApiServer" "extraEnv" list $substrate -}}
{{- if eq .name "AWS_ENDPOINT_URL" -}}
{{- $_ := set $snapshots "endpoint" (required "substrate.ateApiServer.extraEnv AWS_ENDPOINT_URL needs a value" .value) -}}
{{- else if eq .name "AWS_S3_USE_PATH_STYLE" -}}
{{- $_ := set $snapshots "usePathStyle" (eq .value "true") -}}
{{- else if eq .name "AWS_REGION" -}}
{{- $_ := set $snapshots "region" .value -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $snapshots | toJson -}}
{{- end -}}

{{/*
agent-platform.driftDetection renders a component HelmRelease's
spec.driftDetection from components.<name>.driftDetection (passed through)
plus the ignore rules its pod-certificate workloads need
(giantswarm/agent-platform#879). helm-controller before v1.4 (Flux 2.6, whose
API types predate Kubernetes 1.35) decodes a Deployment through types without
the projected volume source podCertificate: with drift detection on, its
correction re-applies the pod template with that source emptied ({}), the next
ReplicaSet's pods start without their Substrate identity and crash-loop. The
rules leave /spec/template/spec/volumes of those workloads to Helm's own
upgrades, which apply the chart's manifest as it is; every other field of them
and every other object stays corrected. While drift detection is on (mode
enabled or warn) the rules are appended to the entry's own ignore list, so an
installation that sets one keeps them; mode disabled or no driftDetection key
renders the entry unchanged.

The table names the releases whose charts project podCertificate volumes:
kagent's controller (its Substrate pod identity, service DNS and Postgres
client certificates; its fullname follows the forwarded naming values) and
every Substrate workload (ate-api-server, ate-controller, atenet, atelet, the
bundled Postgres, the credential provider; Substrate carries no drift
detection by default, the rules hold for the day it is turned on). A release
whose chart starts projecting podCertificate gets its row here.
*/}}
{{- define "agent-platform.driftDetection" -}}
{{- $volumes := list "/spec/template/spec/volumes" -}}
{{- $kagent := .root.Values.kagent | default dict -}}
{{- $fullname := "kagent" -}}
{{- with $kagent.nameOverride }}{{ $fullname = printf "kagent-%s" . }}{{ end -}}
{{- $fullname = $kagent.fullnameOverride | default $fullname | trunc 63 | trimSuffix "-" -}}
{{- $carriers := dict
  "kagent" (list (dict "kind" "Deployment" "name" (printf "%s-controller" $fullname)))
  "substrate" (list (dict "kind" "Deployment") (dict "kind" "StatefulSet") (dict "kind" "DaemonSet"))
-}}
{{- $dd := deepCopy .spec -}}
{{- $targets := get $carriers .name | default list -}}
{{- if and $targets (ne (toString (get $dd "mode")) "disabled") -}}
{{- $ignore := get $dd "ignore" | default list -}}
{{- $present := list -}}
{{- range $ignore }}{{ $present = append $present (toJson .) }}{{ end -}}
{{- range $targets -}}
{{- $rule := dict "paths" $volumes "target" . -}}
{{- if not (has (toJson $rule) $present) -}}
{{- $ignore = append $ignore $rule -}}
{{- end -}}
{{- end -}}
{{- $_ := set $dd "ignore" $ignore -}}
{{- end -}}
{{- toYaml $dd -}}
{{- end -}}
