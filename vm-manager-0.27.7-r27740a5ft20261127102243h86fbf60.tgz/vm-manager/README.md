# vm-manager

CIMD is enabled by default. DCR is deprecated by MCP 2026-07-28 and remains a
compatibility fallback; see the [OAuth registration guide](../../docs/oauth-client-registration.md).

VM provisioning service for the Agent Platform — KVM virtual machines with an instance metadata service, a vTPM with measured boot, an immutable image and attestation, exposed as REST and MCP

vm-manager as a platform pod: the Deployment runs privileged on a KVM node with
`/dev/kvm` and `/dev/vhost-vsock` mounted from the node, QEMU and swtpm as its
children (`--launcher process`), the state directory on an optional claim and
the image directory (`make -C images` in a vm-manager checkout) mounted from a
claim or a node path. With `oauth.enabled` it is an OAuth 2.1 resource server
against the platform identity (`global.identity`), and with
`muster.mcpServer.enabled` it registers with muster under the `agent-platform`
tool group, next to agent-manager and model-manager. The agent-platform meta
chart installs it as `components.vm-manager`.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global | object | `{}` | Platform-wide values an umbrella chart (agent-platform) shares with every component; Helm forwards them to this chart. `oauth.*` reads the identity contract as its defaults: `global.identity.issuerUrl`, `global.identity.clientId`, `global.identity.existingSecret`, `global.identity.ca.secretName` / `.key`, and `global.domain` for the OAuth base URL. Empty here; a standalone install sets `oauth.*` directly. |
| replicaCount | int | `1` | Number of replicas. One: the VMs are children of the one process and the state directory is its own. The Deployment rolls with Recreate for the same reason. |
| image.registry | string | `"gsoci.azurecr.io"` | Image registry. |
| image.repository | string | `"giantswarm/vm-manager"` | Image repository. |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| image.tag | string | `""` | Image tag. Defaults to the chart appVersion. |
| imagePullSecrets | list | `[]` | Image pull secrets. |
| nameOverride | string | `""` | Override the chart name. |
| fullnameOverride | string | `""` | Override the fully qualified release name (the umbrella chart pins the Service name through this). |
| persistence.existingClaim | string | `""` | Keep the state directory (VM records, disks, vTPM state, consoles, and the guest image under images/) on a PersistentVolumeClaim: an existing claim's name, or `create: true` to render one from the settings below. With neither the state is an emptyDir: the VMs die with the pod — they end with the process anyway (--launcher process) — and every pod start fetches the guest image again and forgets the golden PCR values recorded into its policy.json. A claim keeps VM records and disks for the next `start_vm`, the image and its golden values for the next start. |
| persistence.create | bool | `false` |  |
| persistence.size | string | `"50Gi"` |  |
| persistence.storageClass | string | `""` |  |
| persistence.accessModes[0] | string | `"ReadWriteOnce"` |  |
| guestImage.enabled | bool | `true` | Fetch the guest image the pod boots — the base image, its UKI, the Kubernetes sysext layers and the policy.json `make -C images` builds, published by every release as an OCI artifact — into `<state>/images` at pod start: an init container runs `vm-manager image pull`, a no-op when the directory already holds that artifact. Off, the directory stays as it is (empty on a fresh volume: list_images is empty) — for the chart's own install smoke. |
| guestImage.registry | string | `"gsoci.azurecr.io"` | Registry of the artifact. |
| guestImage.repository | string | `"giantswarm/vm-manager-guest-image"` | Repository of the artifact. |
| guestImage.tag | string | `""` | Tag. Defaults to the chart appVersion: a release publishes its guest image next to its container image and chart. |
| guestImage.digest | string | `""` | Manifest digest (`sha256:…`) to pull instead of the tag: exact content, and a changed digest rolls the pod (a lab pushing local builds). |
| guestImage.plainHTTP | bool | `false` | Reach the registry over HTTP instead of HTTPS (a lab registry). |
| guestImage.pullSecret | string | `""` | Secret of type kubernetes.io/dockerconfigjson with the registry's credentials, for a private mirror; empty pulls anonymously. |
| guestImage.resources | object | `{"requests":{"cpu":"100m","memory":"128Mi"}}` | Resources of the init container. It streams the artifact's files to the volume, so its memory is the page cache of what it writes, and a memory limit turns a registry that delivers faster than the volume writes back into an OOM kill of the pull (seen at 256Mi with a registry on the node). The chart sets requests only; a limit is the installation's call. |
| vm.networkSubnet | string | `"192.168.127.0/24"` | CIDR of the default network, created at startup when missing. |
| vm.defaultNetwork | string | `"default"` | Its name; `create_vm` attaches to it unless told otherwise. |
| vm.installTimeout | string | `"5m"` | Installer boot ceiling, then `failed`. |
| vm.bootTimeout | string | `"4m"` | `READY=1` ceiling, then `running`; raise it when user-data runs `kubeadm init` with image pulls. |
| vm.stopTimeout | string | `"30s"` | Graceful power-down before SIGKILL, also on shutdown. |
| vm.attestation | string | `"verify"` | How guest TPM quotes are judged: `verify` (against the image policy and its golden values) or `noop`. |
| vm.learnGolden | bool | `false` | Bring-up of a guest image without released golden values (a local build) or of another firmware only: accept golden PCRs the image policy has no value for and record them for `vm-manager image golden`. |
| vm.ovmf.code | string | `""` | OVMF firmware code image and variable store template; empty probes the known locations (the image ships Ubuntu's under /usr/share/OVMF). |
| vm.ovmf.vars | string | `""` |  |
| metrics.enabled | bool | `true` | Serve the Prometheus exposition at GET /metrics, outside the OAuth guard like /healthz. |
| metrics.guestSeriesLimit | int | `1000` | Series kept per VM from one systemd-report upload. |
| mcp.path | string | `"/mcp"` | MCP endpoint path (the REST API is always served). |
| oauth.enabled | bool | `false` | Make vm-manager an OAuth 2.1 resource server (mcp-oauth): the MCP endpoint and the REST API require a bearer token the platform identity provider issued, and every call carries the caller's identity. On the Agent Platform muster forwards the session's IdP id_token to this server (MCPServer `auth.forwardToken`, rendered below), validated against the IdP's JWKS when its audience is in `trustedAudiences`. Off: anonymous — only for a server nothing but a trusted proxy can reach. |
| oauth.baseURL | string | `""` | Public base URL of this server: the issuer of its own OAuth metadata (https, or http on loopback). Empty derives `https://<fullname>.<global.domain>` when `global.domain` is set. |
| oauth.provider | string | `"dex"` | Identity provider: `dex` or `google`. |
| oauth.dex.issuerURL | string | `""` | Dex issuer URL. Empty falls back to `global.identity.issuerUrl`. |
| oauth.dex.clientID | string | `""` | Dex OAuth client ID. Empty falls back to `global.identity.clientId`. |
| oauth.dex.clientSecret | string | `""` | Dex OAuth client secret (prefer `oauth.existingSecret`). |
| oauth.dex.allowPrivateURLs | bool | `false` | Deprecated, no effect: the Dex client reaches a private or loopback issuer and follows HTTP_PROXY, HTTPS_PROXY and NO_PROXY without it. |
| oauth.dex.caSecret | object | `{"key":"ca.crt","name":""}` | Secret with the CA of a Dex that serves a private certificate; mounted and passed as `--dex-ca-file`. Empty name falls back to `global.identity.ca.secretName` / `global.identity.ca.key`. |
| oauth.google.clientID | string | `""` | Google OAuth client ID (not secret; may also come from the Secret key `google-client-id` when empty). |
| oauth.google.clientSecret | string | `""` | Google OAuth client secret (prefer `oauth.existingSecret`). |
| oauth.existingSecret | string | `""` | Existing Secret with the provider credentials: `dex-client-secret` (dex) or `google-client-secret` (+ optional `google-client-id`) (google). Empty falls back to `global.identity.existingSecret`, whose `dex-client-secret` is the platform client's; without that, the chart renders a Secret from the values above. |
| oauth.trustedAudiences | list | `[]` | OAuth client IDs whose IdP id_tokens are accepted as bearer tokens (SSO token forwarding). Empty falls back to `[global.identity.clientId]`, the platform client MCP clients and the muster CLI log in with. The server trusts the union of this list and `muster.mcpServer.auth.requiredAudiences` (in that order, without duplicates). |
| oauth.sso.allowPrivateIPs | bool | `false` | Deprecated, no effect: the issuer host's JWKS endpoint may resolve to a private address without it; list any other JWKS host in allowPrivateIPJWKSHosts. |
| oauth.sso.allowPrivateIPJWKSHosts | list | `[]` | Hosts, other than the issuer's own, whose JWKS may resolve to an RFC 1918 or RFC 4193 address: a jwks_uri the IdP's discovery document puts on another host. Exact hostnames, no port. Loopback and link-local stay refused. |
| oauth.allowPublicClientRegistration | bool | `false` | Accept unauthenticated dynamic client registration (labs only). |
| muster.mcpServer.enabled | bool | `false` | Register this server with muster by rendering an `mcpservers.muster.giantswarm.io` CR in the release namespace. Tools then appear as `x_<name>_<tool>`. The CR carries `agent-platform.giantswarm.io/tool-group: agent-platform`: the platform's own management surface, next to agent-manager and model-manager. |
| muster.mcpServer.name | string | `"vm-manager"` | MCPServer CR name (drives the tool prefix). |
| muster.mcpServer.displayName | string | `"VM Manager"` | Human-friendly name the Dev Portal shows for this server, rendered as the `ui.giantswarm.io/display-name` annotation. Empty renders none. |
| muster.mcpServer.autoStart | bool | `true` | Start the server connection when muster initializes. |
| muster.mcpServer.description | string | `"VM provisioning on the platform's KVM node (images, networks, VMs with measured boot and attestation); call get_host first, then list_images and list_networks, then create_vm"` | Human-readable description shown by muster. |
| muster.mcpServer.labels | object | `{}` | Extra labels on the MCPServer CR (merged last: they may override the tool-group label). |
| muster.mcpServer.auth | object | `{"forwardToken":true,"requiredAudiences":[]}` | How muster authenticates to this server; rendered only with `oauth.enabled`. `forwardToken` makes muster forward the session's IdP id_token byte-identical. `requiredAudiences` are extra audiences that token must carry, trusted as bearer audiences by construction. |
| muster.mcpServer.approval | object | `{"rule":"Allow","tools":{"create_network":"Allow","create_vm":"Allow","delete_network":"Allow","delete_vm":"Allow","exec_vm":"Allow","forward_port":"Allow","get_host":"Allow","get_image":"Allow","get_info":"Allow","get_network":"Allow","get_vm":"Allow","get_vm_attestation":"Allow","get_vm_console":"Allow","get_vm_metrics":"Allow","list_images":"Allow","list_networks":"Allow","list_vms":"Allow","reboot_vm":"Allow","start_vm":"Allow","stop_vm":"Allow"}}` | The connector's tool approval (the MCPServer's `spec.approval`). Every tool of this release is listed explicitly ("Allow all" preset: a platform management server), so the connector arrives reviewed. `rule` covers tools without their own entry, new ones included. Values: Allow | Ask | Block (Block hides and refuses). Override per tool in installation values; `null` renders none (`{}` does not: Helm merges it into the default) and the connector runs every tool, shown as not reviewed. On a governed platform muster asks an agent caller before every tool not on its safe list, whatever these settings say; on a trusted platform these settings apply. Needs a muster whose MCPServer CRD carries `spec.approval`. Details: https://github.com/giantswarm/agent-platform/blob/main/docs/tool-approval.md |
| networkPolicy.enabled | bool | `false` | Create a Kubernetes NetworkPolicy for the pod. |
| networkPolicy.ingressNamespaces | list | `[]` | Namespaces allowed to reach the API (label kubernetes.io/metadata.name). Empty allows ingress from the release namespace only. |
| networkPolicy.guestEgress | bool | `true` | The guests' traffic leaves the pod: the networks are userspace NAT (gvisor-tap-vsock) and a VM reaches whatever the pod reaches, so the policy admits every egress destination. False limits egress to DNS and the identity provider — VMs then have no network beyond their own. |
| serviceAccount.create | bool | `true` | Create a ServiceAccount. vm-manager calls no Kubernetes API; the token is never mounted. |
| serviceAccount.annotations | object | `{}` | Annotations on the ServiceAccount. |
| serviceAccount.name | string | `""` | ServiceAccount name (generated when empty). |
| podAnnotations | object | `{}` | Annotations on the pod. |
| podLabels | object | `{}` | Labels on the pod. |
| podSecurityContext | object | `{}` | Pod security context. Root: /dev/kvm is root:kvm on every node and the process forks QEMU and swtpm as its own children. |
| securityContext | object | `{"privileged":true,"runAsGroup":0,"runAsUser":0}` | Container security context. Privileged, on purpose: the container runtime gives a privileged container the node's devices, /dev/kvm (hardware virtualization) and /dev/vhost-vsock (the guests' READY=1 and ssh) among them, with the device cgroup open — nothing is mounted from the node. A device plugin handing out the two devices to an unprivileged pod is the refinement. No capability is used beyond that (no bridges, no tap devices, no CAP_NET_ADMIN: the networks are userspace). A node without the devices starts the pod all the same; GET /api/v1/host names them under `missing`. |
| service.type | string | `"ClusterIP"` | Service type. |
| service.port | int | `8080` | Service port (container listens on 8080). |
| serviceMonitor.enabled | bool | `false` | Render a ServiceMonitor for `GET /metrics` (`vm_manager_*` and `vm_guest_*`). Also needs `metrics.enabled`; the meta chart turns this on once the tenant label is set. |
| serviceMonitor.interval | string | `""` | Scrape interval; empty uses the Prometheus Operator default. |
| serviceMonitor.labels | object | `{}` | Labels on the ServiceMonitor, beside the chart's own. The Giant Swarm observability platform routes a scrape to a Mimir tenant by `observability.giantswarm.io/tenant`; a monitor without it writes to no tenant. |
| resources | object | `{"requests":{"cpu":"250m","memory":"512Mi"}}` | Container resources. The VMs are QEMU processes inside this container, so a memory limit bounds the sum of their memory too; none by default. |
| logging.verbose | bool | `false` | Enable debug logging. |
| observability.otel.endpoint | string | `""` | OTLP collector the server exports its traces to (`OTEL_EXPORTER_OTLP_ENDPOINT`), e.g. `http://otlp-gateway.kube-system.svc:4317` for gRPC. Empty exports nothing; the W3C propagator still honours an inbound `traceparent`. |
| observability.otel.protocol | string | `"grpc"` | OTLP protocol: `grpc` or `http/protobuf` (`OTEL_EXPORTER_OTLP_PROTOCOL`). |
| observability.otel.headers | string | `""` | Extra OTLP headers as `key=value,...` (`OTEL_EXPORTER_OTLP_HEADERS`), e.g. `X-Scope-OrgID=giantswarm` for the collector's tenant. |
| observability.otel.resourceAttributes | string | `""` | Extra resource attributes as `key=value,...`, appended to the pod's `k8s.pod.name`, `k8s.namespace.name` and `k8s.node.name` (`OTEL_RESOURCE_ATTRIBUTES`). |
| observability.otel.sampler | string | `"parentbased_traceidratio"` | Trace sampler (`OTEL_TRACES_SAMPLER`). Parent-based: a call arriving with a sampled `traceparent` (muster's) is always kept, a root span is sampled at `samplerArg`. |
| observability.otel.samplerArg | string | `"0.1"` | Sampler argument (`OTEL_TRACES_SAMPLER_ARG`): the ratio of root spans kept. |
| extraArgs | list | `[]` | Extra container arguments. |
| extraEnv | list | `[]` | Extra environment variables. |
| nodeSelector | object | `{}` | Node selector: the KVM node(s) — a label such as `kvm.giantswarm.io/enabled: "true"` on nodes that expose /dev/kvm. |
| tolerations | list | `[]` | Tolerations. |
| affinity | object | `{}` | Affinity. |
