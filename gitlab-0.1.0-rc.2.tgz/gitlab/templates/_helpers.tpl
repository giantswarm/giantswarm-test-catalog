{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label. A label value is at
most 63 characters and begins and ends alphanumeric: the cut of a long version
(a branch build's <version>-dev.<branch>.<date>.<time>.<sha>, or the
<version>+<digest> helm-controller installs) can land on any run of ".", "_"
(from "+") and "-", so the whole run is trimmed.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimAll "-._" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "labels.common" -}}
app: {{ include "name" . | quote }}
{{ include "labels.selector" . }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "labels.selector" -}}
app.kubernetes.io/name: {{ include "name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}

{{/*
The name of the release's objects.
*/}}
{{- define "fullname" -}}
{{- if contains .Chart.Name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
The GitLab image reference.
*/}}
{{- define "image" -}}
{{- printf "%s/%s:%s" .Values.registry.domain .Values.image.name (.Values.image.tag | default .Chart.AppVersion) -}}
{{- end -}}

{{/*
The host of externalUrl.
*/}}
{{- define "host" -}}
{{- $url := urlParse .Values.externalUrl -}}
{{- required "externalUrl needs a scheme and a host, e.g. https://gitlab.example.com" $url.hostname -}}
{{- end -}}

{{/*
GITLAB_OMNIBUS_CONFIG: one bundled instance behind a TLS-terminating proxy,
with the parts no test instance needs switched off.
*/}}
{{- define "omnibusConfig" -}}
external_url {{ .Values.externalUrl | quote }}
gitlab_rails['time_zone'] = {{ .Values.timeZone | quote }}
gitlab_rails['gitlab_shell_ssh_port'] = {{ .Values.ssh.externalPort | int }}
nginx['listen_port'] = {{ .Values.http.port | int }}
nginx['listen_https'] = false
nginx['proxy_set_headers'] = { 'X-Forwarded-Proto' => '{{ (urlParse .Values.externalUrl).scheme }}', 'X-Forwarded-Ssl' => '{{ ternary "on" "off" (eq (urlParse .Values.externalUrl).scheme "https") }}' }
letsencrypt['enable'] = false
registry['enable'] = false
gitlab_rails['registry_enabled'] = false
gitlab_kas['enable'] = false
gitlab_pages['enable'] = false
prometheus_monitoring['enable'] = false
puma['worker_processes'] = {{ .Values.omnibus.pumaWorkers | int }}
sidekiq['concurrency'] = {{ .Values.omnibus.sidekiqConcurrency | int }}
gitlab_rails['usage_ping_enabled'] = false
{{- with .Values.omnibus.extraConfig }}
{{ . }}
{{- end }}
{{- end -}}
