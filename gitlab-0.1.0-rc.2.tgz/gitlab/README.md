# gitlab

GitLab CE in one Omnibus container on one volume, a small self-contained GitLab instance for testing integrations.

**Homepage:** <https://github.com/giantswarm/gitlab>

## Source Code

* <https://gitlab.com/gitlab-org/omnibus-gitlab>
* <https://hub.docker.com/r/gitlab/gitlab-ce>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| registry.domain | string | `"gsoci.azurecr.io"` | Registry the image is pulled from. |
| image.name | string | `"giantswarm/gitlab-ce"` | Image repository in the registry, the mirror of `gitlab/gitlab-ce`. |
| image.tag | string | `""` | Image tag; empty means the chart's appVersion. |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| replicas | int | `1` | Number of GitLab pods: 1, or 0 to stop the instance and keep its volume. Omnibus is a single instance. |
| externalUrl | string | `"https://gitlab.example.com"` | The URL GitLab is reached at, with scheme (the hostname of the HTTPRoute or Ingress). TLS is terminated in front of the pod, so an `https://` URL serves plain HTTP in the pod and generates `https://` links. |
| rootPassword.existingSecret | string | `"gitlab-root-password"` | Name of an existing Secret holding the initial root password; the installer creates it. The password is only read when the instance is set up for the first time. The pod waits until the Secret exists. |
| rootPassword.key | string | `"password"` | Key of the password in that Secret. |
| timeZone | string | `"UTC"` | Time zone of the instance. |
| omnibus.pumaWorkers | int | `2` | Puma worker processes. 2 fits the 6 GiB memory request. |
| omnibus.sidekiqConcurrency | int | `10` | Sidekiq concurrency. |
| omnibus.extraConfig | string | `""` | Further `gitlab.rb` lines, appended to the generated `GITLAB_OMNIBUS_CONFIG` (a later line wins). |
| http.port | int | `80` | Port nginx listens on in the pod and the Service exposes. |
| ssh.enabled | bool | `false` | Expose git over SSH. Off: clones and pushes go over HTTPS only. |
| ssh.externalPort | int | `22` | Port shown in SSH clone URLs: the NodePort, the Gateway listener's port, or the LoadBalancer port. |
| ssh.service.type | string | `"NodePort"` | Type of the SSH Service: NodePort, LoadBalancer or ClusterIP (behind a TCPRoute). |
| ssh.service.nodePort | string | `nil` | Fixed node port for the NodePort type; empty lets Kubernetes pick one. |
| service.type | string | `"ClusterIP"` | Type of the HTTP Service. |
| httpRoute.enabled | bool | `false` | Render a Gateway API HTTPRoute for `externalUrl`'s host. |
| httpRoute.parentRefs | list | `[]` | Gateways the route attaches to. |
| httpRoute.annotations | object | `{}` | Annotations of the HTTPRoute. |
| tcpRoute.enabled | bool | `false` | Render a Gateway API TCPRoute (v1alpha2) for SSH; needs `ssh.enabled` and a TCP listener on the Gateway. |
| tcpRoute.parentRefs | list | `[]` | Gateways the route attaches to, naming the TCP listener. |
| ingress.enabled | bool | `false` | Render an Ingress for `externalUrl`'s host. |
| ingress.className | string | `"nginx"` | IngressClass of the Ingress. |
| ingress.annotations | object | `{}` | Annotations of the Ingress, e.g. `cert-manager.io/cluster-issuer: letsencrypt-giantswarm`. |
| ingress.tls.enabled | bool | `true` | Terminate TLS at the Ingress with the certificate in `ingress.tls.secretName`. |
| ingress.tls.secretName | string | `""` | Secret of the certificate; empty means `<release>-tls`. |
| networkPolicy.enabled | bool | `true` | Render a NetworkPolicy admitting traffic to the HTTP and SSH ports only. |
| networkPolicy.from | list | `[]` | Peers allowed to reach those ports; empty means from anywhere. |
| persistence.size | string | `"30Gi"` | Size of the volume holding /var/opt/gitlab (repositories, PostgreSQL, Redis, uploads) and /etc/gitlab. |
| persistence.storageClass | string | `""` | StorageClass of the volume; empty means the cluster's default. |
| persistence.accessMode | string | `"ReadWriteOnce"` | Access mode of the volume. |
| shmSize | string | `"256Mi"` | Size of the memory-backed /dev/shm (Puma and Sidekiq metrics). |
| resources | object | `{"limits":{"memory":"8Gi"},"requests":{"cpu":"2","memory":"6Gi"}}` | Resources of the GitLab container: the Omnibus small-instance footprint. |
| probes.startupSeconds | int | `900` | Seconds the first set-up may take before liveness checks begin (startupProbe period times failures). |
| podSecurityContext | object | `{"seccompProfile":{"type":"RuntimeDefault"}}` | Pod security context. The Omnibus image starts as root and drops to its service users itself: see the README. |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"add":["CHOWN","DAC_OVERRIDE","FOWNER","SETUID","SETGID","KILL","NET_BIND_SERVICE"],"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":false,"seccompProfile":{"type":"RuntimeDefault"}}` | Container security context: no privilege escalation, every capability dropped except those Omnibus' root start needs to chown its data and switch to its service users. See the README for the Pod Security exception. |
| nodeSelector | object | `{}` | Node selector of the pod. |
| tolerations | list | `[]` | Tolerations of the pod. |
| affinity | object | `{}` | Affinity of the pod. |
| podAnnotations | object | `{}` | Extra annotations of the pod. |
