# flux-operator

![Version: 0.62.1](https://img.shields.io/badge/Version-0.62.1-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v0.62.1](https://img.shields.io/badge/AppVersion-v0.62.1-informational?style=flat-square)

The [Flux Operator](https://github.com/controlplaneio-fluxcd/flux-operator) provides a
declarative API for the installation and upgrade of CNCF [Flux](https://fluxcd.io) and the
ControlPlane [enterprise distribution](https://control-plane.io/enterprise-for-flux-cd/).

The operator automates the patching for hotfixes and CVEs affecting the Flux controllers container images
and enables the configuration of multi-tenancy lockdown on Kubernetes and OpenShift clusters.

The operator comes with the Flux Status Page web UI exposed on port `9080` that allows users to visualize the
status of the Flux installation and monitor the GitOps delivery pipeline in real-time.

## Prerequisites

- Kubernetes 1.30+
- Helm 3.8+

## Installing Flux Operator

To install the operator in the `flux-system` namespace:

```console
helm install flux-operator oci://ghcr.io/controlplaneio-fluxcd/charts/flux-operator \
  --namespace flux-system \
  --create-namespace \
  --wait
```

## Installing the Flux Web UI as a Standalone Deployment

You can install the Flux Status Web UI as a dedicated deployment in your Kubernetes cluster,
separate from the Flux Operator with:

```console
helm install flux-web oci://ghcr.io/controlplaneio-fluxcd/charts/flux-operator \
  --namespace flux-system \
  --set fullnameOverride=flux-web \
  --set web.serverOnly=true \
  --set installCRDs=false \
  --wait
```

To deploy the Flux controllers and to configure automated updates,
see the Flux Operator [documentation](https://fluxoperator.dev/docs/).

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{"nodeAffinity":{"requiredDuringSchedulingIgnoredDuringExecution":{"nodeSelectorTerms":[{"matchExpressions":[{"key":"kubernetes.io/os","operator":"In","values":["linux"]}]}]}}}` | Pod affinity and anti-affinity settings. |
| apiPriority | object | `{"enabled":false,"extraServiceAccounts":[],"level":"workload-high"}` | Kubernetes [API priority and fairness](https://kubernetes.io/docs/concepts/cluster-administration/flow-control/) settings. |
| commonAnnotations | object | `{}` | Common annotations to add to all deployed objects including pods. |
| commonLabels | object | `{}` | Common labels to add to all deployed objects including pods. |
| extraArgs | list | `[]` | Container extra arguments. |
| extraEnvs | list | `[]` | Container extra environment variables. |
| extraVolumeMounts | list | `[]` | Container extra volume mounts. |
| extraVolumes | list | `[]` | Pod extra volumes. |
| fullnameOverride | string | `""` |  |
| hostNetwork | bool | `false` | If `true`, the container ports (`8080` and `8081`) are exposed on the host network. |
| image | object | `{"imagePullPolicy":"IfNotPresent","pullSecrets":[],"repository":"ghcr.io/controlplaneio-fluxcd/flux-operator","tag":""}` | Container image settings. The image tag defaults to the chart appVersion. |
| installCRDs | bool | `true` | Install and upgrade the custom resource definitions. |
| livenessProbe | object | `{"httpGet":{"path":"/healthz","port":8081},"initialDelaySeconds":15,"periodSeconds":20}` | Container liveness probe settings. |
| logLevel | string | `"info"` | Container logging level flag. |
| marketplace | object | `{"account":"","license":"","type":""}` | Marketplace settings. |
| multitenancy | object | `{"defaultServiceAccount":"flux-operator","defaultWorkloadIdentityServiceAccount":"flux-operator","enabled":false,"enabledForWorkloadIdentity":false}` | Enable [multitenancy lockdown](https://fluxoperator.dev/docs/crd/resourceset/#role-based-access-control) for the ResourceSet APIs. |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` | Pod Node Selector settings. |
| podSecurityContext | object | `{}` | Pod security context settings. |
| priorityClassName | string | `""` | Pod priority class name. Recommended value is system-cluster-critical. |
| rbac.create | bool | `true` | Grant the cluster-admin role to the flux-operator service account (required for the Flux Instance deployment). |
| rbac.createAggregation | bool | `true` | Grant the Kubernetes view, edit and admin roles access to ResourceSet APIs. |
| readinessProbe | object | `{"httpGet":{"path":"/readyz","port":8081},"initialDelaySeconds":5,"periodSeconds":10}` | Container readiness probe settings. |
| reporting | object | `{"interval":"5m"}` | Flux [reporting](https://fluxoperator.dev/docs/crd/fluxreport/) settings. |
| resources | object | `{"limits":{"cpu":"2000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"64Mi"}}` | Container resources requests and limits settings. |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}}` | Container security context settings. The default is compliant with the pod security restricted profile. |
| service.ipFamilyPolicy | string | `""` | Sets the IP family policy on all Service resources. Uses Kubernetes defaults if unset |
| serviceAccount | object | `{"automount":true,"create":true,"name":""}` | Pod service account settings. The name of the service account defaults to the release name. |
| serviceMonitor | object | `{"create":false,"interval":"60s","labels":{},"scrapeTimeout":"30s"}` | Prometheus Operator scraping settings. |
| spiffe | object | `{"brokerAPI":{"endpoint":"","ids":[]},"workloadAPI":{"csiDriver":"","endpoint":""}}` | SPIFFE settings for the flux-operator pod. |
| spiffe.brokerAPI.endpoint | string | `""` | The SPIFFE Broker API endpoint. Sets the `--spiffe-broker-endpoint` flag. Requires `spiffe.workloadAPI.endpoint` and `spiffe.brokerAPI.ids`. |
| spiffe.brokerAPI.ids | list | `[]` | SPIFFE IDs or prefixes of the Broker API endpoint. Sets the repeatable `--spiffe-broker-id` flag. |
| spiffe.workloadAPI.csiDriver | string | `""` | The SPIFFE CSI driver name used to mount the Workload API socket at `/spiffe-workload-api`. When set, the endpoint must be a socket under that path, e.g. `unix:///spiffe-workload-api/spire-agent.sock`. |
| spiffe.workloadAPI.endpoint | string | `""` | The SPIFFE Workload API endpoint. Sets the `SPIFFE_ENDPOINT_SOCKET` environment variable. |
| strategy | object | `{}` | Deployment update strategy. Set `{"type":"Recreate"}` for single-replica installs whose web UI is fronted by a load balancer health check, where a rolling update would otherwise deadlock. |
| tolerations | list | `[]` | Pod tolerations settings. |
| web.authorizedClientSPIFFEIDs | list | `[]` | SPIFFE IDs or prefixes of authorized web UI clients. When set, the web server on port 9080 accepts only SPIFFE mTLS connections from these clients, so the Ingress or Gateway in front of it must present an SVID (e.g. Envoy Gateway with a BackendTLSPolicy). Requires `spiffe.workloadAPI.endpoint`. |
| web.config | object | `{}` | The spec of the [Web Config API](https://fluxoperator.dev/docs/web-ui/web-config-api/) |
| web.configSecretName | string | `""` | Reference to an existing Secret in the same namespace as the deployment containing the Web Config API. Should have the key `config.yaml`. |
| web.enabled | bool | `true` | Enable the [Flux Status web server](https://fluxoperator.dev/web-ui/) on port 9080. |
| web.httpRoute | object | `{"annotations":{},"enabled":false,"hostnames":[],"parentRefs":[]}` | Gateway API HTTPRoute settings for the Flux Status web interface. |
| web.ingress | object | `{"annotations":{},"className":"","enabled":false,"hosts":[],"tls":[]}` | Ingress settings for the Flux Status web interface. |
| web.networkPolicy | object | `{"create":true}` | Create a NetworkPolicy to allow access to the Flux Status web interface. |
| web.rbac | object | `{"createAggregation":false,"createRoles":true}` | Create standard roles for [user access management](https://fluxoperator.dev/docs/web-ui/user-management/). |
| web.serverOnly | bool | `false` | Run the Flux Status web server as a standalone deployment (requires a dedicated Helm release). |
| web.serverReplicas | int | `1` | Number of replicas for the Flux Status web server standalone deployment (only applicable if `web.serverOnly` is `true`). |
| web.userActions | object | `{"access":"Impersonated"}` | GitOps actions configuration for the web UI. |
| web.userActions.access | string | `"Impersonated"` | Access mode for GitOps actions. When set to `FineGrained`, actions are performed using the web server's own privileges instead of impersonating the user, and the web ClusterRole is extended with the native Kubernetes permissions required by the actions (only effective in `web.serverOnly` mode; otherwise the operator already runs as cluster-admin). Either `Impersonated` (default) or `FineGrained`. |

## Source Code

* <https://github.com/controlplaneio-fluxcd/flux-operator>
* <https://github.com/controlplaneio-fluxcd/charts>
