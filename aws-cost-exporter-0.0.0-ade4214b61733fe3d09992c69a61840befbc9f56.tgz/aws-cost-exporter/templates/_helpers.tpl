{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "aws-cost-exporter.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "aws-cost-exporter.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "aws-cost-exporter.labels" -}}
app: {{ include "aws-cost-exporter.name" . | quote }}
{{ include "aws-cost-exporter.selectorLabels" . }}
application.giantswarm.io/team: {{ index .Chart.Annotations "application.giantswarm.io/team" | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
helm.sh/chart: {{ include "aws-cost-exporter.chart" . | quote }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "aws-cost-exporter.selectorLabels" -}}
app.kubernetes.io/name: {{ include "aws-cost-exporter.name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}

{{- define "giantswarm.irsa.annotation" -}}
{{- if (or (eq .Values.region "cn-north-1") (eq .Values.region "cn-northwest-1"))}}
eks.amazonaws.com/role-arn: arn:aws-cn:iam::{{ .Values.accountID }}:role/{{ .Values.clusterID }}-cost-exporter
{{- else }}
eks.amazonaws.com/role-arn: arn:aws:iam::{{ .Values.accountID }}:role/{{ .Values.clusterID }}-cost-exporter
{{- end -}}
{{- end -}}
