# mcp-kubernetes

A Helm chart for mcp-kubernetes - Model Context Protocol server for Kubernetes

**Homepage:** <https://github.com/giantswarm/mcp-kubernetes>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Giant Swarm | <team-bumblebee@giantswarm.io> |  |

## Source Code

* <https://github.com/giantswarm/mcp-kubernetes>

## Availability

The chart runs two replicas by default (`replicaCount: 2`), spread across
nodes by a topology spread constraint on `kubernetes.io/hostname`
(`whenUnsatisfiable: ScheduleAnyway`, so a single-node cluster still schedules
both), and a PodDisruptionBudget with `minAvailable: 1`. When one pod is
rescheduled, evicted or waits for its image, the other keeps serving the tools.
The budget renders only while more than one pod runs: with `replicaCount: 1`
(or autoscaling down to one pod) it would block every node drain.

Any pod serves any request: MCP sessions keep no pod-local state, and an
identity provider's token an aggregator such as muster forwards is validated
by every pod. Tokens the server issues through its own OAuth flow are stored
in `mcpKubernetes.oauth.storage`; with more than one pod that storage is
Valkey (`storage.type: valkey`), or a token one pod issued is unknown to the
others, and a token revoked on one pod (`/oauth/revoke`) stays valid
on the others. The per-user rate limit of
privileged access (`capiMode.privilegedAccess.rateLimit`) counts per pod: two
pods admit up to twice the configured rate. A port forward opened through the `port_forward` tool stays on the pod
that opened it.

## Rolling on credential rotation

The server reads its OAuth credentials (the Dex or Google client secret, the
registration token, the token encryption key, the Valkey password) from a
Secret at start and never again. The pod template carries a
`checksum/oauth-secret` annotation so a changed credential restarts the server:

- With `mcpKubernetes.oauth.existingSecret` (and `global.identity.existingSecret`)
  empty the chart renders the Secret from `mcpKubernetes.oauth.dex.clientSecret`
  (or `google.clientSecret`), `registrationAccessToken`, `encryptionKeyValue` and
  `storage.valkey.password`; the annotation is the SHA-256 of that Secret's data
  and follows every change of those values.
- With an existing Secret the chart cannot read it; the annotation is
  `mcpKubernetes.oauth.existingSecretChecksum` verbatim. Change it in the same
  change that rotates the Secret (a hash over the new data, a counter, a date).
  A Flux `HelmRelease` can instead feed the Secret's keys into the values above
  through `valuesFrom` entries with `targetPath`, so the chart renders the
  Secret itself and the checksum follows the rotation on its own.
- A Valkey password in its own Secret (`storage.valkey.existingSecret`) is
  marked the same way by `storage.valkey.existingSecretChecksum`, rendered as
  `checksum/valkey-secret`.

## Ingress callers

The `CiliumNetworkPolicy` (`ciliumNetworkPolicy.enabled`) admits only the
callers listed here. Cilium policies are additive, so no other policy can
widen or narrow this one: a caller missing from the list cannot reach the
server, and its calls time out. Every caller is a namespace and the labels of
its pods; the defaults are Giant Swarm's.

| Caller | Port | Admitted by | Default |
|---|---|---|---|
| muster, the only client of the MCP endpoint | server (`8080`) | `ciliumNetworkPolicy.ingress.muster` | `agent-platform`, `app.kubernetes.io/name: muster` |
| Teleport agent, through which a muster on another cluster calls this server (Teleport app access) | server (`8080`) | `ciliumNetworkPolicy.ingress.teleportPeers` | `kube-system`, `app: teleport-kube-agent`; `[]` on a cluster without Teleport |
| Gateway proxies carrying the HTTPRoute, only while `gatewayAPI.enabled` | server (`8080`) | `ciliumNetworkPolicy.ingress.gatewayPeers` | `envoy-gateway-system`, `app.kubernetes.io/name: envoy` |
| Metrics collector, only while `mcpKubernetes.instrumentation.enabled` and `mcpKubernetes.metrics.enabled` | metrics (`mcpKubernetes.metrics.port`, `9090`) | `ciliumNetworkPolicy.ingress.metricsScrapers` | `kube-system`, `app.kubernetes.io/instance: alloy-metrics` |
| Kubelet probes (liveness, readiness, startup) | every port | the `host` entity, always | |
| Any further client, e.g. the ingress controller in front of `ingress.enabled` | server (`8080`) | `ciliumNetworkPolicy.ingress.additionalPeers` | none |

A new caller is a row here, the value that admits it and a test in
`tests/ingress_callers_test.yaml`, which renders the defaults and fails when a
listed caller is no longer admitted.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global.domain | string | `""` |  |
| global.identity.issuerUrl | string | `""` |  |
| global.identity.clientId | string | `""` |  |
| global.identity.existingSecret | string | `""` |  |
| global.identity.ca.secretName | string | `""` |  |
| global.identity.ca.key | string | `"ca.crt"` |  |
| replicaCount | int | `2` | Pods of the server. Two keep the tools reachable while one pod is rescheduled, drained or waits for its image; the server is safe to run more than one: MCP sessions carry no pod-local state (a port forward stays on the pod that opened it), and a token muster forwards is validated by every pod against the identity provider. Tokens the server issues itself (its own OAuth flow) need mcpKubernetes.oauth.storage.type valkey to be known to every pod. |
| podDisruptionBudget | object | `{"enabled":true,"minAvailable":1}` | PodDisruptionBudget of the server, rendered while more than one pod runs (replicaCount, or autoscaling.minReplicas with autoscaling on): a node drain evicts one pod at a time and never the last. |
| podDisruptionBudget.enabled | bool | `true` | Renders the budget (while more than one pod runs). |
| podDisruptionBudget.minAvailable | int | `1` | Pods a voluntary disruption leaves running. |
| topologySpreadConstraints | list | `[]` | Spread of the pods. Empty: one constraint over kubernetes.io/hostname, whenUnsatisfiable ScheduleAnyway, so the pods land on different nodes where the cluster has them and still schedule on a single node. A list replaces it verbatim. |
| image.registry | string | `"gsoci.azurecr.io"` |  |
| image.repository | string | `"giantswarm/mcp-kubernetes"` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.tag | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| nameOverride | string | `""` |  |
| fullnameOverride | string | `""` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.automount | bool | `true` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.name | string | `""` |  |
| rbac.create | bool | `true` |  |
| rbac.profile | string | `"standard"` |  |
| rbac.adminConfirmation | bool | `false` |  |
| rbac.custom.enabled | bool | `false` |  |
| rbac.custom.rules | list | `[]` |  |
| podAnnotations | object | `{}` |  |
| podLabels | object | `{}` |  |
| podSecurityContext.runAsUser | int | `1000` |  |
| podSecurityContext.runAsGroup | int | `1000` |  |
| podSecurityContext.runAsNonRoot | bool | `true` |  |
| podSecurityContext.fsGroup | int | `1000` |  |
| securityContext.readOnlyRootFilesystem | bool | `true` |  |
| securityContext.allowPrivilegeEscalation | bool | `false` |  |
| securityContext.runAsUser | int | `1000` |  |
| securityContext.runAsGroup | int | `1000` |  |
| securityContext.runAsNonRoot | bool | `true` |  |
| securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| service.type | string | `"ClusterIP"` |  |
| service.port | int | `8080` |  |
| ingress.enabled | bool | `false` |  |
| ingress.className | string | `""` |  |
| ingress.annotations | object | `{}` |  |
| ingress.hosts[0].host | string | `"chart-example.local"` |  |
| ingress.hosts[0].paths[0].path | string | `"/"` |  |
| ingress.hosts[0].paths[0].pathType | string | `"Prefix"` |  |
| ingress.tls | list | `[]` |  |
| gatewayAPI.enabled | bool | `false` |  |
| gatewayAPI.httpRoute.parentRefs | list | `[]` |  |
| gatewayAPI.httpRoute.hostnames | list | `[]` |  |
| gatewayAPI.httpRoute.rules | list | `[]` |  |
| gatewayAPI.httpRoute.annotations | object | `{}` |  |
| gatewayAPI.httpRoute.labels | object | `{}` |  |
| gatewayAPI.backendTrafficPolicy.enabled | bool | `false` |  |
| gatewayAPI.backendTrafficPolicy.timeout | string | `"0s"` |  |
| gatewayAPI.backendTrafficPolicy.annotations | object | `{}` |  |
| gatewayAPI.backendTrafficPolicy.labels | object | `{}` |  |
| startupProbe.periodSeconds | int | `5` |  |
| startupProbe.timeoutSeconds | int | `5` |  |
| startupProbe.failureThreshold | int | `18` |  |
| resources.limits.cpu | string | `"500m"` |  |
| resources.limits.memory | string | `"512Mi"` |  |
| resources.limits.ephemeral-storage | string | `"100Mi"` |  |
| resources.requests.cpu | string | `"100m"` |  |
| resources.requests.memory | string | `"128Mi"` |  |
| resources.requests.ephemeral-storage | string | `"50Mi"` |  |
| autoscaling.enabled | bool | `false` |  |
| autoscaling.minReplicas | int | `2` |  |
| autoscaling.maxReplicas | int | `100` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| autoscaling.targetMemoryUtilizationPercentage | int | `0` | Average memory utilization the HPA targets; 0 leaves memory out of its metrics. |
| volumes | list | `[]` |  |
| volumeMounts | list | `[]` |  |
| nodeSelector | object | `{}` |  |
| tolerations | list | `[]` |  |
| affinity | object | `{}` |  |
| mcpKubernetes.debug | bool | `false` |  |
| mcpKubernetes.maxRequestSize | int | `5242880` |  |
| mcpKubernetes.kubernetes.inCluster | bool | `true` |  |
| mcpKubernetes.kubernetes.kubeconfig | string | `""` |  |
| mcpKubernetes.auth.existingSecret | string | `""` |  |
| mcpKubernetes.oauth.enabled | bool | `false` |  |
| mcpKubernetes.oauth.baseURL | string | `""` |  |
| mcpKubernetes.oauth.provider | string | `"dex"` |  |
| mcpKubernetes.oauth.google.clientID | string | `""` |  |
| mcpKubernetes.oauth.google.clientSecret | string | `""` |  |
| mcpKubernetes.oauth.dex.issuerURL | string | `""` |  |
| mcpKubernetes.oauth.dex.clientID | string | `""` |  |
| mcpKubernetes.oauth.dex.clientSecret | string | `""` |  |
| mcpKubernetes.oauth.dex.connectorID | string | `""` |  |
| mcpKubernetes.oauth.dex.kubernetesAuthenticatorClientID | string | `""` |  |
| mcpKubernetes.oauth.dex.caSecret.name | string | `""` |  |
| mcpKubernetes.oauth.dex.caSecret.key | string | `"ca.crt"` |  |
| mcpKubernetes.oauth.registrationAccessToken | string | `""` |  |
| mcpKubernetes.oauth.allowPublicRegistration | bool | `false` |  |
| mcpKubernetes.oauth.allowInsecureAuthWithoutState | bool | `false` |  |
| mcpKubernetes.oauth.allowPrivateURLs | bool | `false` |  |
| mcpKubernetes.oauth.maxClientsPerIP | int | `10` |  |
| mcpKubernetes.oauth.encryptionKey | bool | `false` |  |
| mcpKubernetes.oauth.encryptionKeyValue | string | `""` |  |
| mcpKubernetes.oauth.disableStreaming | bool | `false` |  |
| mcpKubernetes.oauth.enableDownstreamOAuth | bool | `false` |  |
| mcpKubernetes.oauth.existingSecret | string | `""` |  |
| mcpKubernetes.oauth.existingSecretChecksum | string | `""` |  |
| mcpKubernetes.oauth.storage.type | string | `"memory"` |  |
| mcpKubernetes.oauth.storage.valkey.url | string | `""` |  |
| mcpKubernetes.oauth.storage.valkey.password | string | `""` |  |
| mcpKubernetes.oauth.storage.valkey.tls.enabled | bool | `false` |  |
| mcpKubernetes.oauth.storage.valkey.keyPrefix | string | `"mcp:"` |  |
| mcpKubernetes.oauth.storage.valkey.db | int | `0` |  |
| mcpKubernetes.oauth.storage.valkey.existingSecret | string | `""` |  |
| mcpKubernetes.oauth.storage.valkey.existingSecretChecksum | string | `""` |  |
| mcpKubernetes.oauth.storage.valkey.secretKeyPassword | string | `"valkey-password"` |  |
| mcpKubernetes.oauth.redirectURISecurity.disableProductionMode | bool | `false` |  |
| mcpKubernetes.oauth.redirectURISecurity.allowLocalhostRedirectURIs | bool | `false` |  |
| mcpKubernetes.oauth.redirectURISecurity.allowPrivateIPRedirectURIs | bool | `false` |  |
| mcpKubernetes.oauth.redirectURISecurity.allowLinkLocalRedirectURIs | bool | `false` |  |
| mcpKubernetes.oauth.redirectURISecurity.disableDNSValidation | bool | `false` |  |
| mcpKubernetes.oauth.redirectURISecurity.disableDNSValidationStrict | bool | `false` |  |
| mcpKubernetes.oauth.redirectURISecurity.disableAuthorizationTimeValidation | bool | `false` |  |
| mcpKubernetes.oauth.trustedPublicRegistrationSchemes | list | `[]` |  |
| mcpKubernetes.oauth.disableStrictSchemeMatching | bool | `false` |  |
| mcpKubernetes.oauth.enableCIMD | bool | `true` |  |
| mcpKubernetes.oauth.cimd.allowPrivateIPs | bool | `false` |  |
| mcpKubernetes.oauth.trustedAudiences | list | `[]` |  |
| mcpKubernetes.oauth.trustedIssuers | list | `[]` |  |
| mcpKubernetes.oauth.sso.allowPrivateIPs | bool | `false` |  |
| mcpKubernetes.instrumentation.enabled | bool | `true` |  |
| mcpKubernetes.instrumentation.metricsExporter | string | `"prometheus"` |  |
| mcpKubernetes.instrumentation.tracingExporter | string | `"none"` |  |
| mcpKubernetes.instrumentation.otlpEndpoint | string | `""` |  |
| mcpKubernetes.instrumentation.otlpProtocol | string | `""` |  |
| mcpKubernetes.instrumentation.otlpHeaders | string | `""` |  |
| mcpKubernetes.instrumentation.otlpInsecure | bool | `false` |  |
| mcpKubernetes.instrumentation.traceSamplingRate | float | `0.1` |  |
| mcpKubernetes.instrumentation.detailedLabels | bool | `false` |  |
| mcpKubernetes.instrumentation.serviceMonitor.enabled | bool | `false` |  |
| mcpKubernetes.instrumentation.serviceMonitor.labels | object | `{}` |  |
| mcpKubernetes.instrumentation.serviceMonitor.annotations | object | `{}` |  |
| mcpKubernetes.instrumentation.serviceMonitor.interval | string | `""` |  |
| mcpKubernetes.instrumentation.serviceMonitor.scrapeTimeout | string | `""` |  |
| mcpKubernetes.instrumentation.serviceMonitor.relabelings | list | `[]` |  |
| mcpKubernetes.instrumentation.serviceMonitor.metricRelabelings | list | `[]` |  |
| mcpKubernetes.metrics.enabled | bool | `true` |  |
| mcpKubernetes.metrics.port | int | `9090` |  |
| mcpKubernetes.service.port | int | `8080` |  |
| mcpKubernetes.env | list | `[]` |  |
| capiMode | object | `{"cache":{"cleanupInterval":"1m","maxEntries":1000,"ttl":"10m"},"connectivity":{"burst":100,"qps":50,"requestTimeout":"30s","retryAttempts":3,"retryBackoff":"1s","timeout":"5s"},"enabled":false,"output":{"maskSecrets":true,"maxClusters":20,"maxItems":100,"maxResponseBytes":524288,"slimOutput":true},"privilegedAccess":{"enabled":true,"privilegedCAPIDiscovery":true,"rateLimit":{"burst":20,"perSecond":10},"strict":false},"rbac":{"allowedNamespaces":[],"clusterWideSecrets":false,"create":true},"workloadClusterAuth":{"caConfigMapSuffix":"-ca-public","disableCaching":false,"groupMappings":{},"mode":"impersonation"}}` | ------------------------------------ The RBAC resources created by this chart (ClusterRoles, Roles, RoleBindings) are ONLY used when OAuth Downstream is DISABLED (enableDownstreamOAuth: false).  When OAuth Downstream is ENABLED (enableDownstreamOAuth: true):   - The ServiceAccount RBAC is NOT used for Kubernetes API operations   - Users must have their own RBAC permissions on the Management Cluster to:     * List CAPI Cluster resources (cluster.x-k8s.io/clusters)     * Read kubeconfig secrets in organization namespaces   - On Workload Clusters, user identity is propagated via impersonation headers   - Users need appropriate RBAC on each Workload Cluster they access  See docs/rbac-security.md for detailed RBAC requirements per deployment mode. |
| grafanaDashboards.enabled | bool | `false` |  |
| grafanaDashboards.namespace | string | `""` |  |
| grafanaDashboards.labels.grafana_dashboard | string | `"1"` |  |
| grafanaDashboards.annotations | object | `{}` |  |
| grafanaDashboards.folder | string | `"mcp-kubernetes"` |  |
| grafanaDashboards.giantswarm.enabled | bool | `false` |  |
| grafanaDashboards.giantswarm.organization | string | `""` |  |
| grafanaDashboards.dashboards.administrator.enabled | bool | `true` |  |
| grafanaDashboards.dashboards.security.enabled | bool | `true` |  |
| grafanaDashboards.dashboards.clusterOperator.enabled | bool | `true` |  |
| prometheusRules.enabled | bool | `false` |  |
| prometheusRules.labels."observability.giantswarm.io/tenant" | string | `"giantswarm"` |  |
| prometheusRules.annotations | object | `{}` |  |
| prometheusRules.team | string | `"bumblebee"` |  |
| prometheusRules.runbookBaseUrl | string | `"https://intranet.giantswarm.io/docs/support-and-ops/runbooks"` |  |
| prometheusRules.minimumVolume | int | `20` |  |
| prometheusRules.rules.mcpKubernetesHighErrorRate.enabled | bool | `true` |  |
| prometheusRules.rules.mcpKubernetesK8sOperationFailures.enabled | bool | `true` |  |
| prometheusRules.rules.mcpKubernetesOAuthFailures.enabled | bool | `true` |  |
| prometheusRules.rules.mcpKubernetesWorkloadClusterAuthFailures.enabled | bool | `true` |  |
| prometheusRules.rules.mcpKubernetesClusterOperationFailures.enabled | bool | `true` |  |
| ciliumNetworkPolicy.enabled | bool | `true` |  |
| ciliumNetworkPolicy.labels | object | `{}` |  |
| ciliumNetworkPolicy.annotations | object | `{}` |  |
| ciliumNetworkPolicy.ingress.muster.namespace | string | `"agent-platform"` |  |
| ciliumNetworkPolicy.ingress.muster.matchLabels."app.kubernetes.io/name" | string | `"muster"` |  |
| ciliumNetworkPolicy.ingress.teleportPeers[0].namespace | string | `"kube-system"` |  |
| ciliumNetworkPolicy.ingress.teleportPeers[0].matchLabels.app | string | `"teleport-kube-agent"` |  |
| ciliumNetworkPolicy.ingress.gatewayPeers[0].namespace | string | `"envoy-gateway-system"` |  |
| ciliumNetworkPolicy.ingress.gatewayPeers[0].matchLabels."app.kubernetes.io/name" | string | `"envoy"` |  |
| ciliumNetworkPolicy.ingress.metricsScrapers[0].namespace | string | `"kube-system"` |  |
| ciliumNetworkPolicy.ingress.metricsScrapers[0].matchLabels."app.kubernetes.io/instance" | string | `"alloy-metrics"` |  |
| ciliumNetworkPolicy.ingress.additionalPeers | list | `[]` |  |
