# klaus-gateway

Slack channel gateway for the Agent Platform's kagent agents

**Homepage:** <https://github.com/giantswarm/klaus-gateway>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Giant Swarm |  | <https://www.giantswarm.io> |

## Source Code

* <https://github.com/giantswarm/klaus-gateway>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| enabled | bool | `true` |  |
| agentgatewayRoute | object | `{}` |  |
| name | string | `"klaus-gateway"` |  |
| serviceType | string | `"managed"` |  |
| fullnameOverride | string | `""` |  |
| image.registry | string | `"gsoci.azurecr.io"` |  |
| image.name | string | `"giantswarm/klaus-gateway"` |  |
| image.tag | string | `""` |  |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| replicaCount | int | `1` |  |
| logLevel | string | `"info"` |  |
| pod.user.id | int | `65532` |  |
| pod.group.id | int | `65532` |  |
| resources.limits.cpu | string | `"500m"` |  |
| resources.limits.memory | string | `"256Mi"` |  |
| resources.requests.cpu | string | `"100m"` |  |
| resources.requests.memory | string | `"128Mi"` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.annotations | object | `{}` |  |
| server.port | int | `8080` |  |
| admin.port | int | `8081` |  |
| metrics.enabled | bool | `true` |  |
| serviceMonitor.enabled | bool | `true` |  |
| serviceMonitor.interval | string | `"60s"` |  |
| serviceMonitor.scrapeTimeout | string | `"45s"` |  |
| serviceMonitor.labels | object | `{}` | Labels on the ServiceMonitor, beside the chart's own. The Giant Swarm observability platform routes a scrape to a Mimir tenant by `observability.giantswarm.io/tenant`; a monitor without it writes to no tenant. |
| routing.store | string | `"memory"` |  |
| routing.boltPath | string | `"/var/lib/klaus-gateway/routes.bolt"` |  |
| routing.threadTTL | string | `""` |  |
| routing.valkey.url | string | `""` |  |
| routing.valkey.username | string | `""` |  |
| routing.valkey.existingSecret | string | `""` |  |
| routing.valkey.passwordKey | string | `"valkey-password"` |  |
| routing.valkey.db | int | `0` |  |
| routing.valkey.tls.enabled | bool | `false` |  |
| routing.valkey.tls.serverName | string | `""` |  |
| routing.valkey.keyPrefix | string | `""` |  |
| routing.valkey.timeout | string | `"2s"` |  |
| observability.otlpEndpoint | string | `""` |  |
| observability.otlpHeaders | object | `{}` | Headers sent with every trace export, e.g. the tenant of a multi-tenant gateway: `X-Scope-OrgID: giantswarm`. Rendered as --otel-otlp-headers. |
| podAnnotations | object | `{}` | Annotations on the pod template (merged over the chart's own). The agent platform sets `karpenter.sh/do-not-disrupt: "true"` here so Karpenter's consolidation works around the pod that holds the channel connections and the in-flight A2A streams instead of evicting it. |
| podLabels | object | `{}` | Labels on the pod template. |
| podDisruptionBudget | object | `{"enabled":false,"maxUnavailable":null,"minAvailable":1,"unhealthyPodEvictionPolicy":""}` | PodDisruptionBudget on the gateway pods. Off by default: with `replicaCount: 1` a `minAvailable: 1` budget refuses every voluntary eviction (node drains wait for the drain timeout), which is the intended guard for a single replica that carries live Slack turns, but a deliberate choice. Set exactly one of `minAvailable` / `maxUnavailable` (int or percentage); `unhealthyPodEvictionPolicy: AlwaysAllow` lets a pod that is not Ready be evicted regardless, so a crash-looping gateway never wedges a drain. |
| terminationGracePeriodSeconds | int | `45` | Seconds the kubelet gives the pod to stop before it is killed. The shutdown drains the HTTP servers (up to 15 s), then stops the channel adapters (up to 15 s more), which is when a Slack turn cut short posts its restart notice and clears its progress reaction; the rest is margin for the client and store closes. Lower than the drain plus the stop and a turn interrupted by a restart ends in silence. |
| podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| securityContext.allowPrivilegeEscalation | bool | `false` |  |
| securityContext.readOnlyRootFilesystem | bool | `true` |  |
| securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| a2a.enabled | bool | `false` |  |
| a2a.defaultAgent | string | `"sre-agent"` |  |
| a2a.url | string | `""` |  |
| a2a.namespace | string | `"kagent"` |  |
| a2a.caSecret | string | `""` |  |
| a2a.caFile | string | `""` |  |
| a2a.fallbackIconUrlTemplate | string | `""` |  |
| a2a.agentManagerToolsPrefix | string | `""` |  |
| a2aServer.enabled | bool | `false` |  |
| a2aServer.publicUrl | string | `""` |  |
| a2aServer.issuers | list | `[]` |  |
| a2aServer.exchange.tokenUrl | string | `""` |  |
| a2aServer.exchange.clientId | string | `""` |  |
| a2aServer.exchange.existingSecret | string | `""` |  |
| a2aServer.exchange.audiences | list | `[]` |  |
| a2aServer.maxBodyBytes | int | `2097152` |  |
| a2aServer.minTokenLifetime | string | `"25m"` |  |
| a2aServer.caSecret | string | `""` |  |
| a2aServer.caFile | string | `""` |  |
| slack.enabled | bool | `false` |  |
| slack.mode | string | `"events"` |  |
| slack.secretName | string | `""` |  |
| slack.dmMode | string | `""` |  |
| slack.channelMode | string | `""` |  |
| slack.channelAllowlist | list | `[]` |  |
| slack.slashCommand | string | `""` |  |
| slack.contextBotIDs | list | `[]` | The bot_ids (B…) whose posts the thread context hands to the agent: the alerting integrations a conversation is opened under (Alertmanager, PagerDuty). Every human's message is shared; a bot's post only when its bot_id is listed here or its profile name matches `contextBotNames`. The gateway's own posts never are. A thread is read only in a channel the gateway's bot is a member of, so the bot is invited to every alert channel whose posts should reach an agent. Rendered as SLACK_CONTEXT_BOT_IDS. Empty lists no bot_id. |
| slack.contextBotNames | list | `[]` | Patterns matched against a bot's Slack profile name, the app's own bot name (`bot_profile.name`), never the name a post sets: `path.Match` syntax (`*`, `?`, `[...]`), case-insensitive, an invalid pattern fails start-up. One entry admits an integration that runs one Slack app per installation, each with its own bot_id: `*-alertmanager` admits every installation's Alertmanager, a new installation included. Admits beside `contextBotIDs`, with the same channel-membership requirement. Rendered as SLACK_CONTEXT_BOT_NAMES. Empty matches no name. |
| slack.dropStale | bool | `false` |  |
| slack.progress.emojis.working | string | `""` |  |
| slack.progress.emojis.done | string | `""` |  |
| slack.progress.emojis.failed | string | `""` |  |
| slack.progress.clearReactionOnDone | string | `nil` |  |
| slack.botToken | string | `""` |  |
| slack.signingSecret | string | `""` |  |
| slack.appToken | string | `""` |  |
| obo.enabled | bool | `false` |  |
| obo.musterUrl | string | `""` |  |
| obo.callbackBaseUrl | string | `""` |  |
| obo.store | string | `"bolt"` |  |
| obo.storeSecretName | string | `""` |  |
| obo.storePath | string | `""` |  |
| obo.persistence.enabled | bool | `false` |  |
| obo.persistence.size | string | `"64Mi"` |  |
| obo.persistence.accessMode | string | `"ReadWriteOnce"` |  |
| obo.persistence.storageClass | string | `""` |  |
| obo.persistence.existingClaim | string | `""` |  |
| obo.existingSecret | string | `""` |  |
| obo.stateKey | string | `""` |  |
| obo.storeKey | string | `""` |  |
| obo.minTokenLifetime | string | `""` |  |
| obo.connectors.enabled | bool | `false` |  |
| reviews.enabled | bool | `false` |  |
| reviews.audience | string | `"klaus-gateway"` |  |
| reviews.allowedCallers[0] | string | `"system:serviceaccount:giantswarm-platform-manager:giantswarm-platform-manager"` |  |
| refusals.enabled | bool | `false` |  |
| refusals.egressService | string | `"ate-system/atenet-egress"` |  |
| refusals.statsPort | int | `15020` |  |
| refusals.metricsPath | string | `"/metrics"` |  |
| refusals.kagentTarget | string | `"kagent-controller.kagent.svc:8083"` |  |
| refusals.kagentAudience | string | `"kagent"` |  |
| refusals.window | string | `"24h"` |  |
| refusals.interval | string | `"1m"` |  |
| refusals.agentURLTemplate | string | `""` |  |
| workspaces.toolsPrefix | string | `""` |  |
| global.podSecurityStandards.enforced | bool | `false` |  |
| nodeSelector | object | `{}` |  |
| tolerations | list | `[]` |  |
| affinity | object | `{}` |  |
