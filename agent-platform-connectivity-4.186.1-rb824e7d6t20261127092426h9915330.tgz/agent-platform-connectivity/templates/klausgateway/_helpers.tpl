{{/* vim: set filetype=mustache: */}}
{{/*
Helpers of the klaus-gateway component's wiring (templates/klausgateway/).

One values block feeds these templates: klausGateway — the klaus-gateway
chart's own values as the meta chart forwards them (the routing store, Slack,
OBO and A2A knobs) plus the umbrella's wiring keys (agentgatewayRoute). A
component release's values cannot be derived at render time, so the wiring
reads what the chart will see; a knob the block does not declare is read with
the klaus-gateway chart's own default. The Valkey store's
target is the platform's own Valkey (components.valkey, the valkey block), the
way the meta chart fills routing.valkey from it.
*/}}

{{/*
The klaus-gateway pod's app.kubernetes.io/name label value: the chart's
fullnameOverride, else its chart name. Every policy selecting the gateway pod
uses this, so a renamed release moves them all.
*/}}
{{- define "agent-platform.klausGateway.fullname" -}}
{{- .Values.klausGateway.fullnameOverride | default "klaus-gateway" -}}
{{- end -}}

{{/*
Truthy (emits "true") when the gateway pod reads or writes the Kubernetes API,
so its egress needs the kube-apiserver: the Secret link store
(klausGateway.obo.store: secret with OBO on — the gateway's own gate,
klaus-gateway's obo.secretStore helper), and the team-review endpoint
(klausGateway.reviews.enabled; giantswarm/klaus-gateway#273), which verifies
every caller of POST /reviews and POST /notices with an
authentication.k8s.io/v1 TokenReview — whatever the link store, so an
installation on the bolt store gets the rule too (giantswarm/agent-platform#511;
without it every review times out at the API and the endpoint answers 503).
The routing stores that reached the API (configmap, crd) and the embedded
ChannelRoute controller are gone from klaus-gateway (giantswarm/klaus-gateway#271).
Empty otherwise: the default shape — memory routing, the bolt link store, no
reviews — never touches the API and gets no rule. The keys are the
klaus-gateway chart's; when the block leaves one unset its chart default
applies (bolt, memory, reviews off).
*/}}
{{- define "agent-platform.klausGateway.apiServerEgress" -}}
{{- $kg := .Values.klausGateway -}}
{{- if or (dig "reviews" "enabled" false $kg) (and (dig "obo" "enabled" false $kg) (eq (dig "obo" "store" "bolt" $kg) "secret")) (include "agent-platform.klausGateway.refusalsOn" .) -}}true{{- end -}}
{{- end -}}

{{/*
Truthy (emits "true") while klaus-gateway runs the egress refusal notices
(giantswarm/giantswarm#38667) — the meta chart's define of the same name,
which this chart must agree with: klaus-gateway with Slack and
klausGateway.refusals.enabled on — which the meta chart resolves from auto,
the floors of the klaus-gateway and kagent ranges included — kagent and
Substrate on, the controller in the kubernetes authorization mode. The gateway then reads the Kubernetes API
(the egress's EndpointSlices, the Agents), the stats port of Substrate's
atenet-egress and the kagent controller's API port
(-klausgateway-refusals-egress).
*/}}
{{- define "agent-platform.klausGateway.refusalsOn" -}}
{{- $kg := .Values.klausGateway | default dict -}}
{{- $mode := dig "controller" "authorization" "mode" "" (.Values.kagent | default dict) -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "klaus-gateway")) (dig "slack" "enabled" false $kg) (dig "refusals" "enabled" false $kg) (include "agent-platform.componentEnabled" (dict "root" . "name" "kagent")) (include "agent-platform.componentEnabled" (dict "root" . "name" "substrate")) (eq (toString $mode) "kubernetes") -}}true{{- end -}}
{{- end -}}

{{/*
Truthy (emits "true") when the gateway pod keeps its routes in the platform's
Valkey: klausGateway.routing.store: valkey with the valkey component on
(components.valkey.enabled — the pods the rule selects). Empty otherwise; an
out-of-band Valkey (routing.valkey.url set, the component off) is not in this
namespace and gets no rule here — its egress is the installation's to add.
*/}}
{{- define "agent-platform.klausGateway.valkeyEgress" -}}
{{- if and (eq (dig "routing" "store" "memory" .Values.klausGateway) "valkey") (include "agent-platform.valkey.enabled" .) -}}true{{- end -}}
{{- end -}}

{{/*
The port the platform's Valkey Service listens on (valkey.valkey.service.port,
default 6379) — the one the meta chart puts into the gateway's routing.valkey.url.
*/}}
{{- define "agent-platform.klausGateway.valkeyPort" -}}
{{- dig "valkey" "service" "port" 6379 (.Values.valkey | default dict) -}}
{{- end -}}

{{/*
Truthy (emits "true") when the gateway pod reaches any store beyond its own
process — the gate of the -klausgateway-store-egress policy: the Valkey
routing store or anything on the Kubernetes API (the Secret link store, the
team-review endpoint's TokenReview, the refusal notices' reads).
*/}}
{{- define "agent-platform.klausGateway.storeEgress" -}}
{{- if or (include "agent-platform.klausGateway.valkeyEgress" .) (include "agent-platform.klausGateway.apiServerEgress" .) -}}true{{- end -}}
{{- end -}}

{{/*
Truthy (emits "true") while the A2A server's agentgateway entry renders:
klaus-gateway on and klausGateway.agentgatewayRoute.a2aServer.enabled.
*/}}
{{- define "agent-platform.klausGateway.a2aServerOn" -}}
{{- if and (include "agent-platform.componentEnabled" (dict "root" . "name" "klaus-gateway")) (dig "agentgatewayRoute" "a2aServer" "enabled" false (.Values.klausGateway | default dict)) -}}true{{- end -}}
{{- end -}}

{{/*
The A2A server's entry, resolved and checked, as JSON: the
klausGateway.agentgatewayRoute.a2aServer block with hostname and
exchange.tokenUrl defaulted. Fails the render on a block agentgateway could not
serve: a request it would refuse, or exchange at no connector, fails closed at
runtime with no other trace than a 401.
Usage: include "agent-platform.klausGateway.a2aServer" . | fromJson
*/}}
{{- define "agent-platform.klausGateway.a2aServer" -}}
{{- $route := .Values.klausGateway.agentgatewayRoute | default dict -}}
{{- $a2a := deepCopy ($route.a2aServer | default dict) -}}
{{- $path := "klausGateway.agentgatewayRoute.a2aServer" -}}
{{- if not (include "agent-platform.ingress.agentgateway" .) -}}
{{- fail (printf "%s.enabled is true but muster is off: the A2A server's token check and exchange run on the agentgateway data plane, which this release renders only in front of muster" $path) -}}
{{- end -}}
{{- $_ := set $a2a "hostname" ($a2a.hostname | default $route.hostname | default "") -}}
{{- if not $a2a.hostname -}}
{{- fail (printf "%s.enabled is true but neither %s.hostname nor klausGateway.agentgatewayRoute.hostname is set: the A2A server needs a public hostname" $path $path) -}}
{{- end -}}
{{- if not $a2a.issuers -}}
{{- fail (printf "%s.enabled is true but %s.issuers is empty: agentgateway would accept no A2A client token" $path $path) -}}
{{- end -}}
{{- $names := dict -}}
{{- $issuers := dict -}}
{{- range $i, $issuer := $a2a.issuers -}}
{{- range $k := list "name" "issuer" "audience" "connectorId" -}}
{{- if not (index $issuer $k) -}}
{{- fail (printf "%s.issuers[%d].%s is empty: every issuer needs name, issuer, audience, allowedClients, connectorId and jwks" $path $i $k) -}}
{{- end -}}
{{- end -}}
{{- if not $issuer.allowedClients -}}
{{- fail (printf "%s.issuers[%d].allowedClients is empty: agentgateway checks the client that requested the token (azp) against it, and an empty list would refuse every token" $path $i) -}}
{{- end -}}
{{- if has $a2a.exchange.clientId $issuer.allowedClients -}}
{{- fail (printf "%s.issuers[%d].allowedClients names the exchange client %s: its tokens are the platform tokens agentgateway issues, never an A2A client's" $path $i $a2a.exchange.clientId) -}}
{{- end -}}
{{- if hasKey $names $issuer.name -}}
{{- fail (printf "%s.issuers[%d].name %q is not unique" $path $i $issuer.name) -}}
{{- end -}}
{{- if hasKey $issuers $issuer.issuer -}}
{{- fail (printf "%s.issuers[%d].issuer %q is not unique" $path $i $issuer.issuer) -}}
{{- end -}}
{{- $_ := set $names $issuer.name true -}}
{{- $_ := set $issuers $issuer.issuer true -}}
{{- $_ := include "agent-platform.jwks.validate" (dict "ctx" $ "path" (printf "%s.issuers[%d]" $path $i) "jwks" $issuer.jwks) -}}
{{- end -}}
{{- $exchange := $a2a.exchange | default dict -}}
{{- if not $exchange.clientId -}}
{{- fail (printf "%s.exchange.clientId is empty: the exchange authenticates at Dex as this client" $path) -}}
{{- end -}}
{{- if not $exchange.secretName -}}
{{- fail (printf "%s.exchange.secretName is empty: name the Secret in this release's namespace that holds the secret of the Dex client %s" $path $exchange.clientId) -}}
{{- end -}}
{{- if not $exchange.audiences -}}
{{- fail (printf "%s.exchange.audiences is empty: the first is the audience klaus-gateway checks on the exchanged token" $path) -}}
{{- end -}}
{{- if not (has (toString $exchange.subjectTokenType) (list "IdToken" "AccessToken")) -}}
{{- fail (printf "%s.exchange.subjectTokenType is %q: IdToken or AccessToken" $path (toString $exchange.subjectTokenType)) -}}
{{- end -}}
{{- if not $exchange.tokenUrl -}}
{{- $_ := set $exchange "tokenUrl" (printf "%s/token" (include "agent-platform.issuerUrl" (dict "ctx" . "for" (printf "%s.exchange.tokenUrl" $path)) | trimSuffix "/")) -}}
{{- end -}}
{{- if not (hasPrefix "https://" $exchange.tokenUrl) -}}
{{- fail (printf "%s.exchange.tokenUrl is %q: the exchange sends the client secret and the client's token, so it must be https" $path $exchange.tokenUrl) -}}
{{- end -}}
{{- $_ := set $a2a "exchange" $exchange -}}
{{- $a2a | toJson -}}
{{- end -}}

{{/*
The CEL rule agentgateway requires of an A2A client's verified token: one
clause per issuer, its iss and the client that requested it among the issuer's
allowedClients. The requesting client is azp, else client_id (RFC 9068), else
the only aud, which a JWT may carry as a string or a one-item list.
Usage: include "agent-platform.klausGateway.a2aClientRule" $issuers
*/}}
{{- define "agent-platform.klausGateway.a2aClientRule" -}}
{{- $client := "(has(jwt.azp) ? jwt.azp : (has(jwt.client_id) ? jwt.client_id : (type(jwt.aud) == string ? jwt.aud : (size(jwt.aud) == 1 ? jwt.aud[0] : \"\"))))" -}}
{{- $clauses := list -}}
{{- range . -}}
{{- $clauses = append $clauses (printf "(jwt.iss == %s && %s in %s)" (toJson .issuer) $client (toJson .allowedClients)) -}}
{{- end -}}
{{- join " || " $clauses -}}
{{- end -}}

{{/*
The CEL expression of the exchange's connector_id: the Dex connector of the
verified token's issuer. Every iss reaching it matched a provider of the same
policy, so the final empty string is never sent.
Usage: include "agent-platform.klausGateway.a2aConnectorExpr" $issuers
*/}}
{{- define "agent-platform.klausGateway.a2aConnectorExpr" -}}
{{- $expr := "\"\"" -}}
{{- range reverse . -}}
{{- $expr = printf "jwt.iss == %s ? %s : (%s)" (toJson .issuer) (toJson .connectorId) $expr -}}
{{- end -}}
{{- $expr -}}
{{- end -}}
