{{/*
Gateway AWS NLB - "true" when the gateway runs on CAPA with an AWS Network Load Balancer
(provider.aws.useNetworkLoadBalancer, on by default). Every AWS NLB default of the chart
keys off this: the Service, shutdown, deployment and ClientTrafficPolicy defaults.
Takes a dict with "provider" and "gateway".
*/}}
{{- define "gateway.awsNlb" -}}
{{- if and (eq .provider "capa") (dig "provider" "aws" "useNetworkLoadBalancer" true .gateway) -}}
true
{{- end -}}
{{- end }}

{{/*
Gateway readiness listener - "true" when the chart moves the envoy readiness probe of an
AWS NLB gateway to its own listener. Envoy Gateway's readiness probe (19003 /ready) and
the listener /healthz the NLB probes are the same health_check filter, so the shutdown
fails both at once. The chart adds a static listener on readinessListenerPort through
the EnvoyProxy bootstrap (type Merge, appended to Envoy Gateway's listeners) that
answers readinessListenerPath with a direct 200, and points the readiness probe at it.
Startup and liveness probes keep 19003 /ready.
Turned off with provider.aws.readinessListener: false. Also left out when the gateway or
the chart-managed GatewayClass it merges onto sets a bootstrap (the chart cannot merge
two bootstraps) or the class sets an envoyDeployment.patch (see
gateway.envoyDeploymentDefaults), and when the gateway patch sets containers or a type
other than StrategicMerge, which would replace the probe. The chart cannot see a
GatewayClass it does not manage, so such gateways turn it off themselves when the class
sets a patch or a bootstrap. Takes a dict with "provider", "gateway" and "inherited".
*/}}
{{- define "gateway.readinessListener" -}}
{{- $inherited := .inherited | default dict }}
{{- $patch := dig "envoyProxy" "envoyDeployment" "patch" dict .gateway }}
{{- $patch = ternary $patch dict (kindIs "map" $patch) }}
{{- $podSpec := dict }}
{{- $value := get $patch "value" }}
{{- if kindIs "map" $value }}
{{- $spec := get $value "spec" }}
{{- if kindIs "map" $spec }}
{{- $template := get $spec "template" }}
{{- if kindIs "map" $template }}
{{- $podSpec = get $template "spec" }}
{{- end }}
{{- end }}
{{- end }}
{{- $podSpec = ternary $podSpec dict (kindIs "map" $podSpec) }}
{{- if and (include "gateway.awsNlb" .)
      (dig "provider" "aws" "readinessListener" true .gateway)
      (not (dig "bootstrap" nil $inherited))
      (not (dig "envoyProxy" "bootstrap" nil .gateway))
      (not (dig "envoyDeployment" "patch" nil $inherited))
      (eq (get $patch "type" | default "StrategicMerge") "StrategicMerge")
      (not (get $podSpec "containers")) -}}
true
{{- end -}}
{{- end }}

{{- define "gateway.readinessListenerPort" -}}19004{{- end }}
{{- define "gateway.readinessListenerPath" -}}/ready{{- end }}

{{/*
Gateway readiness listener bootstrap - the EnvoyProxy bootstrap that adds the readiness
listener. The shutdown drains it gracefully like every listener, so it keeps accepting
for the drain period: Envoy Gateway drains with skip_exit and envoy exits at the drain
timeout. drain_type MODIFY_ONLY keeps /healthcheck/fail from draining its connections.
*/}}

{{/*
Gateway readiness listener port check - fails the render when a listener of the gateway
or of one of its listener sets takes the readiness listener port, which envoy would
reject as a duplicate address. Takes a dict with "gateway".
*/}}
{{- define "gateway.validateReadinessListenerPort" -}}
{{- $port := include "gateway.readinessListenerPort" . | int }}
{{- range $_, $l := .gateway.listeners }}
{{- if and $l (eq ($l.port | int) $port) }}
{{- fail (printf "gateway %q: listener %q uses port %d, which the chart reserves for the envoy readiness listener on AWS NLB gateways. Use another port or set provider.aws.readinessListener: false." $.gateway.name $l.name $port) }}
{{- end }}
{{- end }}
{{- range $lsKey, $ls := .gateway.listenerSets }}
{{- if $ls.enabled }}
{{- range $_, $l := $ls.listeners }}
{{- if and $l (eq ($l.port | int) $port) }}
{{- fail (printf "gateway %q: listener set %q listener %q uses port %d, which the chart reserves for the envoy readiness listener on AWS NLB gateways. Use another port or set provider.aws.readinessListener: false." $.gateway.name $lsKey $l.name $port) }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- define "gateway.readinessListenerBootstrap" -}}
type: Merge
value: |
  static_resources:
    listeners:
    - name: giantswarm-readiness
      address:
        socket_address:
          address: 0.0.0.0
          port_value: {{ include "gateway.readinessListenerPort" . }}
      drain_type: MODIFY_ONLY
      bypass_overload_manager: true
      filter_chains:
      - filters:
        - name: envoy.filters.network.http_connection_manager
          typed_config:
            "@type": type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager
            stat_prefix: giantswarm-readiness
            route_config:
              virtual_hosts:
              - name: readiness
                domains:
                - "*"
                routes:
                - match:
                    path: {{ include "gateway.readinessListenerPath" . }}
                  direct_response:
                    status: 200
            http_filters:
            - name: envoy.filters.http.router
              typed_config:
                "@type": type.googleapis.com/envoy.extensions.filters.http.router.v3.Router
{{- end }}

{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimAll "-._" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "labels.common" -}}
app.kubernetes.io/name: {{ include "name" . | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "io.giantswarm.application.team" | quote }}
giantswarm.io/managed-by: {{ .Release.Name | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
Gateway Service annotations
*/}}
{{- define "service.annotations" -}}
{{- $service := .gateway.service }}
{{- $annotations := dict }}

{{- /* Enable External-DNS */}}
{{- $_ := set $annotations "external-dns.alpha.kubernetes.io/hostname" (printf "%s.%s" .gateway.dnsName (.gateway.overrideBaseDomain | default .baseDomain)) }}
{{- $_ := set $annotations "giantswarm.io/external-dns" "managed" }}

{{- /* Use AWS NLB */}}
{{- if include "gateway.awsNlb" . }}
{{- /* Enable PROXY Protocol */}}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-proxy-protocol" "*" }}

{{- /* Configure Health Checks on port 80 for all listeners */}}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-healthcheck-port" "http-80" }}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-healthcheck-path" "/healthz" }}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-healthcheck-healthy-threshold" "2" }}
{{- /* Detect an unhealthy node quickly so the NLB drain starts well before envoy exits */}}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-healthcheck-interval" "10" }}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-healthcheck-unhealthy-threshold" "2" }}

{{- /* Make LB public by default */}}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-scheme" "internet-facing" }}

{{- /* Configure attributes */}}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-attributes" "load_balancing.cross_zone.enabled=true" }}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-target-group-attributes" "target_health_state.unhealthy.connection_termination.enabled=false,target_health_state.unhealthy.draining_interval_seconds=120,preserve_client_ip.enabled=false" }}

{{- /* Tag the NLB with the owning gateway name and namespace, then the user's additional tags */}}
{{- $tags := list (printf "gateway.envoyproxy.io/owning-gateway-name=%s" .gateway.name) (printf "gateway.envoyproxy.io/owning-gateway-namespace=%s" .root.Release.Namespace) }}
{{- $additionalTags := dig "provider" "aws" "additionalResourceTags" dict .gateway }}
{{- range $k := keys $additionalTags | sortAlpha }}
{{- $tags = append $tags (printf "%s=%v" $k (index $additionalTags $k)) }}
{{- end }}
{{- $_ := set $annotations "service.beta.kubernetes.io/aws-load-balancer-additional-resource-tags" (join "," $tags) }}
{{- end }}

{{- /* Leave out the defaults the GatewayClass EnvoyProxy already sets, so they are inherited */}}
{{- range $k, $_ := dig "envoyService" "annotations" dict (.inherited | default dict) }}
{{- $_ := unset $annotations $k }}
{{- end }}
{{- $annotations = mergeOverwrite $annotations (deepCopy (default dict $service.annotations)) }}
{{- include "service.validateSubnets" (dict "owner" (printf "gateway %q" .gateway.name) "annotations" $annotations) }}
{{- $annotations | toYaml }}
{{- end }}

{{/*
Fail when the service.beta.kubernetes.io/aws-load-balancer-subnets annotation has an empty
entry, such as "a,", "a,,b" or "a, ,b", or is empty itself. The AWS Load Balancer
Controller drops empty entries without a warning, so the NLB silently loses an availability
zone and proxy pods in that zone get no traffic. A missing annotation is fine. Checked for
every provider, because an empty entry is always a mistake.
Takes: dict with "owner" (e.g. `gateway "x"`, used in the message) and "annotations"
Emits nothing.
*/}}
{{- define "service.validateSubnets" -}}
{{- $key := "service.beta.kubernetes.io/aws-load-balancer-subnets" -}}
{{- $annotations := .annotations | default dict -}}
{{- if and (hasKey $annotations $key) (not (kindIs "invalid" (index $annotations $key))) -}}
{{- $value := toString (index $annotations $key) -}}
{{- $hint := "list one subnet for each availability zone that can run proxy pods." -}}
{{- if not (trim $value) -}}
{{- fail (printf "%s: %s %q is empty. Remove the annotation, or %s" .owner $key $value $hint) -}}
{{- end -}}
{{- range splitList "," $value -}}
{{- if not (trim .) -}}
{{- fail (printf "%s: %s %q has an empty entry. Remove the extra comma, and %s" $.owner $key $value $hint) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Gateway Service loadBalancerClass
*/}}
{{- define "service.loadBalancerClass" -}}
{{- $service := .gateway.service }}
{{- if $service.loadBalancerClass }}
{{- $service.loadBalancerClass }}
{{- else if and (include "gateway.awsNlb" .) (not (dig "envoyService" "loadBalancerClass" "" (.inherited | default dict))) }}
{{- "service.k8s.aws/nlb" }}
{{- end }}
{{- end }}

{{/*
Gateway Service externalTrafficPolicy
*/}}
{{- define "service.externalTrafficPolicy" -}}
{{- $service := .gateway.service }}
{{- if $service.externalTrafficPolicy }}
{{- $service.externalTrafficPolicy }}
{{- else if not (dig "envoyService" "externalTrafficPolicy" "" (.inherited | default dict)) }}
{{- ternary "Local" "Cluster" (eq (include "gateway.awsNlb" .) "true") }}
{{- end }}
{{- end }}

{{/*
Gateway EnvoyService defaults - computes provider-specific envoyService configuration
*/}}
{{- define "gateway.envoyServiceDefaults" -}}
{{- $envoyService := dict }}
{{- $loadBalancerClass := (include "service.loadBalancerClass" .) }}
{{- if $loadBalancerClass }}
{{- $_ := set $envoyService "loadBalancerClass" $loadBalancerClass }}
{{- end }}
{{- $externalTrafficPolicy := (include "service.externalTrafficPolicy" .) }}
{{- if $externalTrafficPolicy }}
{{- $_ := set $envoyService "externalTrafficPolicy" $externalTrafficPolicy }}
{{- end }}
{{- $_ := set $envoyService "annotations" ((include "service.annotations" .) | fromYaml) }}
{{- if .gateway.service.labels }}
{{- $_ := set $envoyService "labels" ((tpl (.gateway.service.labels | toYaml | toString) .root) | fromYaml) }}
{{- end }}
{{- $envoyService | toYaml }}
{{- end }}

{{/*
Gateway shutdown timers - the graceful shutdown timers for the gateway's provider: the
three EnvoyProxy shutdown fields plus the pod terminationGracePeriodSeconds that must stay
above drainTimeout. Empty when the provider has no set. The shutdown fields are defaults
that the GatewayClass or the gateway can override field by field; the grace period only
fits the chart's own drain timeout, so it is left out as soon as any field is overridden
(see gateway.envoyDeploymentDefaults).

  CAPA with an AWS NLB: drain timers are aligned so the node always outlives the NLB
  connection drain. The NLB health check targets envoy's own /healthz, since with PROXY
  protocol it cannot probe the health check node port. Envoy Gateway serves the pod
  readiness probe (19003 /ready) from the same health_check filter, so failing /healthz
  also makes the pod not serving. With externalTrafficPolicy: Local the node then has
  no local endpoint and refuses new connections until the NLB notices (~20-30s).
  The chart avoids that with its readiness listener (see gateway.readinessListener):
  the pod readiness probe moves to a listener /healthcheck/fail does not flip, so the
  pod stays serving for the drain. /healthz then fails after a 1s delay (kept
  above 0, since Envoy Gateway only drains the listeners explicitly with a delay) and
  the NLB stops sending new flows at ~20s while envoy still accepts them.
  draining_interval_seconds (120s) then ends at ~140s, and a minDrainDuration of 180s
  keeps envoy (and therefore the node) alive until all in-flight NLB flows have moved
  off the node, avoiding RST/520 on node disruption. Without the readiness listener
  the delay stays at 30s, which at least keeps the pod serving for 30s.

  Azure (CAPZ and AKS, both provider "capz"): the load balancer has no NLB draining
  interval to outlive, so the timers are shorter. With the default
  externalTrafficPolicy: Cluster it probes the node port over TCP and never sees
  /healthz; the terminating pod leaves the Service endpoints at once and the drain
  lets its established connections finish, which Azure does not reset. The 30s delay
  matters when the gateway or its GatewayClass uses externalTrafficPolicy: Local. The
  Azure probe then targets the health check node port, which fails as soon as the
  pod terminates, and needs time (every 5s, 2 probes by default) to stop sending new
  flows to the node. Envoy stays ready (/ready) for those 30s, so kube-proxy keeps
  forwarding to it. Measured on AKS with Envoy Gateway 1.9.3 at 100 req/s during
  proxy rollouts, with Local and Cluster: no failed requests.
*/}}
{{- define "gateway.shutdownTimers" -}}
{{- $timers := dict }}
{{- if eq .provider "capz" }}
{{- $timers = dict "healthCheckFailureDelay" "30s" "minDrainDuration" "60s" "drainTimeout" "90s" "terminationGracePeriodSeconds" 120 }}
{{- else if include "gateway.awsNlb" . }}
{{- $delay := ternary "1s" "30s" (eq (include "gateway.readinessListener" .) "true") }}
{{- $timers = dict "healthCheckFailureDelay" $delay "minDrainDuration" "180s" "drainTimeout" "200s" "terminationGracePeriodSeconds" 240 }}
{{- end }}
{{- $timers | toYaml }}
{{- end }}

{{/*
Gateway Shutdown defaults - the EnvoyProxy shutdown fields of gateway.shutdownTimers,
without the fields the GatewayClass sets, so the class value is inherited.
*/}}
{{- define "gateway.shutdownDefaults" -}}
{{- $shutdown := omit ((include "gateway.shutdownTimers" .) | fromYaml) "terminationGracePeriodSeconds" }}
{{- range $k, $_ := dig "shutdown" dict (.inherited | default dict) }}
{{- $_ := unset $shutdown $k }}
{{- end }}
{{- $shutdown | toYaml }}
{{- end }}

{{/*
Gateway EnvoyDeployment defaults - computes provider-specific deployment configuration.
For AWS NLBs and Azure this sets the pod's terminationGracePeriodSeconds from
gateway.shutdownTimers. For AWS NLBs it also prefers one proxy pod per node so each
NLB instance target maps to a single envoy, and spreads the proxy pods evenly across
availability zones so that losing one zone cannot take all of them down.
Each pod default is left out when the GatewayClass EnvoyProxy sets the same field
(affinity or topologySpreadConstraints), so the class value is inherited; the other
pod default still applies. The zone spread is also left out with
provider.aws.zoneSpread: false. The caller merges the gateway values over these
defaults, so a non-empty topologySpreadConstraints list there replaces the zone spread.
The zone spread is ScheduleAnyway, so it never keeps a proxy pod Pending, and uses
nodeTaintsPolicy: Honor, so zones that only have nodes the proxies cannot run on (for
example tainted control-plane nodes) do not count.
*/}}
{{- define "gateway.envoyDeploymentDefaults" -}}
{{- $envoyDeployment := dict }}
{{- $inherited := .inherited | default dict }}
{{- if include "gateway.awsNlb" . }}
{{- $pod := dict }}
{{- /* Both pod defaults select the proxy pods by the owning-gateway labels Envoy
       Gateway stamps on them. */}}
{{- /* Prefer one proxy pod per node so each NLB instance target maps to a single
       envoy, improving NLB health-checking and traffic distribution. */}}
{{- if not (dig "envoyDeployment" "pod" "affinity" nil $inherited) }}
{{- $podAffinityTerm := dict
      "labelSelector" (dict "matchExpressions" (list
        (dict "key" "gateway.envoyproxy.io/owning-gateway-name" "operator" "In" "values" (list .gateway.name))
        (dict "key" "gateway.envoyproxy.io/owning-gateway-namespace" "operator" "In" "values" (list .namespace))
      ))
      "topologyKey" "kubernetes.io/hostname" }}
{{- $_ := set $pod "affinity" (dict "podAntiAffinity" (dict "preferredDuringSchedulingIgnoredDuringExecution" (list (dict "weight" 100 "podAffinityTerm" $podAffinityTerm)))) }}
{{- end }}
{{- /* Prefer an even spread of the proxy pods across zones. ScheduleAnyway only
       scores the placement, so a zone without free capacity cannot keep a pod
       Pending and stall an HPA scale-out. matchLabelKeys counts only the pods of the
       same ReplicaSet, so the old pods of a rollout do not skew the placement of the
       new ones. nodeTaintsPolicy Honor keeps zones that only have nodes the proxies
       cannot run on (for example tainted control-plane nodes) out of the skew. */}}
{{- if and (dig "provider" "aws" "zoneSpread" true .gateway) (not (dig "envoyDeployment" "pod" "topologySpreadConstraints" nil $inherited)) }}
{{- $zoneSpread := dict
      "maxSkew" 1
      "topologyKey" "topology.kubernetes.io/zone"
      "whenUnsatisfiable" "ScheduleAnyway"
      "nodeTaintsPolicy" "Honor"
      "labelSelector" (dict "matchLabels" (dict
        "gateway.envoyproxy.io/owning-gateway-name" .gateway.name
        "gateway.envoyproxy.io/owning-gateway-namespace" .namespace
      ))
      "matchLabelKeys" (list "pod-template-hash") }}
{{- $_ := set $pod "topologySpreadConstraints" (list $zoneSpread) }}
{{- end }}
{{- if $pod }}
{{- $_ := set $envoyDeployment "pod" $pod }}
{{- end }}
{{- end }}
{{- /* terminationGracePeriodSeconds has no dedicated field on EnvoyProxy, so patch it,
       from gateway.shutdownTimers. Left out when the GatewayClass or the gateway sets
       any shutdown field, since it only fits the chart's own drain timeout; Envoy
       Gateway then derives it from the drain timeout (+300s). Also left out when the
       GatewayClass sets its own envoyDeployment.patch, so the class patch keeps its
       type and grace period: StrategicMerge cannot merge two patches (their value is
       opaque JSON), and with JSONMerge this patch would override the class one. A
       gateway patch is merged with this one by the caller
       (templates/gateway/envoyproxy.yaml). */}}
{{- $grace := dig "terminationGracePeriodSeconds" nil ((include "gateway.shutdownTimers" .) | fromYaml) }}
{{- $ownShutdown := or (dig "shutdown" nil $inherited) (dig "envoyProxy" "shutdown" nil .gateway) }}
{{- $podSpec := dict }}
{{- if and $grace (not $ownShutdown) }}
{{- $_ := set $podSpec "terminationGracePeriodSeconds" $grace }}
{{- end }}
{{- /* The readiness listener probe, see gateway.readinessListener. Kept when a
       shutdown field is overridden, since it does not depend on the timers. */}}
{{- if include "gateway.readinessListener" . }}
{{- $probe := dict "httpGet" (dict "path" (include "gateway.readinessListenerPath" .) "port" (include "gateway.readinessListenerPort" . | int)) }}
{{- $_ := set $podSpec "containers" (list (dict "name" "envoy" "readinessProbe" $probe)) }}
{{- end }}
{{- if and $podSpec (not (dig "envoyDeployment" "patch" nil $inherited)) }}
{{- $_ := set $envoyDeployment "patch" (dict "type" "StrategicMerge" "value" (dict "spec" (dict "template" (dict "spec" $podSpec)))) }}
{{- end }}
{{- $envoyDeployment | toYaml }}
{{- end }}

{{/*
EnvoyProxy values a gateway inherits from its GatewayClass EnvoyProxy: the user values of
the chart-managed class it references, when the gateway EnvoyProxy merges onto it. The
gateway provider defaults leave out whatever these set, so the class value is not
overridden by a default. Returns empty when the gateway does not inherit.
Takes: dict with "gateway" and "root"
Returns: YAML, consume with fromYaml
*/}}
{{- define "gateway.inheritedEnvoyProxy" -}}
{{- $gateway := .gateway }}
{{- $mergeType := dig "envoyProxy" "mergeType" "" $gateway | default "StrategicMerge" }}
{{- if has $mergeType (list "StrategicMerge" "JSONMerge") }}
{{- range $_, $class := .root.Values.gatewayClasses }}
{{- if and $class.enabled (dig "envoyProxy" "enabled" true $class) (eq $class.name $gateway.className) }}
{{- omit ($class.envoyProxy | default dict) "enabled" "mergeType" | toYaml }}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
EnvoyProxy spec - shared spec output for EnvoyProxy resources
Takes: envoyProxyValues (dict with all the envoyProxy configuration)
*/}}
{{/*
Resolve effective errorPages config by merging gatewayClass defaults with per-gateway overrides.
Per-gateway values take precedence over gatewayClass values.
Takes: dict with "class" (gatewayClass.errorPages) and "gateway" ($gateway.errorPages)
*/}}
{{- define "errorPages.effective" -}}
{{- $class := .class | default dict }}
{{- $gateway := .gateway | default dict }}
{{- $effective := deepCopy $class }}
{{- $effective = mergeOverwrite $effective (deepCopy $gateway) }}
{{- $effective | toYaml }}
{{- end -}}

{{- define "envoyProxy.spec" -}}
provider:
  type: Kubernetes
  kubernetes:
    {{- with .envoyDeployment }}
    envoyDeployment:
      {{- toYaml . | nindent 6 }}
    {{- end }}
    {{- with .envoyService }}
    envoyService:
      {{- toYaml . | nindent 6 }}
    {{- end }}
    {{- with .envoyHpa }}
    envoyHpa:
      {{- toYaml . | nindent 6 }}
    {{- end }}
    {{- with .envoyPDB }}
    envoyPDB:
      {{- toYaml . | nindent 6 }}
    {{- end }}
    {{- with .envoyServiceAccount }}
    envoyServiceAccount:
      {{- toYaml . | nindent 6 }}
    {{- end }}
{{- with .logging }}
logging:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .telemetry }}
telemetry:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .bootstrap }}
bootstrap:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if .concurrency }}
concurrency: {{ .concurrency }}
{{- end }}
{{- with .extraArgs }}
extraArgs:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if .mergeGateways }}
mergeGateways: {{ .mergeGateways }}
{{- end }}
{{- with .shutdown }}
shutdown:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if .mergeType }}
mergeType: {{ .mergeType }}
{{- end }}
{{- end }}

{{/*
Resolve effective errorPages for a gateway by looking up its gatewayClass by name
and merging the class defaults with the per-gateway overrides.
Takes: dict with "gateway" and "root"
Returns: YAML, consume with fromYaml
*/}}
{{- define "gateway.errorPages" -}}
{{- $gateway := .gateway }}
{{- $classErrorPages := dict }}
{{- range $_, $class := .root.Values.gatewayClasses }}
{{- if eq $class.name $gateway.className }}
{{- $classErrorPages = $class.errorPages | default dict }}
{{- end }}
{{- end }}
{{- include "errorPages.effective" (dict "class" $classErrorPages "gateway" $gateway.errorPages) }}
{{- end -}}

{{/*
Name shared by the per-listener resources (Certificate, DNSEndpoint, TLS Secret).
Takes: dict with "gateway", "listener" and optionally "listenerSet" (the key of a
gateways.<k>.listenerSets entry). The listener set segment keeps names unique across
gateways, since a listener set key is only unique within its own gateway.
*/}}
{{- define "listener.resourceName" -}}
{{- if .listenerSet -}}
{{- printf "gateway-%s-%s-%s" .gateway.name .listenerSet .listener.name -}}
{{- else -}}
{{- printf "gateway-%s-%s" .gateway.name .listener.name -}}
{{- end -}}
{{- end -}}

{{/*
Base domain for a listener: the gateway's overrideBaseDomain when set, otherwise the
listener hostname with any wildcard prefix stripped.
Takes: dict with "gateway", "listener" and "root"
*/}}
{{- define "listener.baseDomain" -}}
{{- trimPrefix "*." (tpl (.gateway.overrideBaseDomain | default .listener.hostname) .root) -}}
{{- end -}}

{{/*
A single Gateway API listener entry. The schema is identical for Gateway.spec.listeners
and ListenerSet.spec.listeners, so both render through this.
Takes: dict with "gateway", "listener", "root" and optionally "listenerSet"
Emits at zero indent, callers apply nindent.
*/}}
{{- define "gatewayapi.listener" -}}
{{- $l := .listener -}}
- name: {{ $l.name }}
  protocol: {{ $l.protocol }}
  port: {{ $l.port }}
  {{- with $l.allowedRoutes }}
  allowedRoutes:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with $l.hostname }}
  hostname: {{ tpl (. | quote) $.root }}
  {{- end }}
  {{- with $l.tls }}
  tls:
    mode: {{ .mode }}
    {{- if or (.certificateRefs) (dig "certificate" "enabled" false $l) }}
    certificateRefs:
    {{- if and (eq .mode "Terminate") (dig "certificate" "enabled" false $l) }}
    - kind: Secret
      name: {{ printf "%s-tls" (include "listener.resourceName" $) }}
    {{- end }}
    {{- range .certificateRefs }}
    - kind: Secret
      name: {{ .name }}
      {{- if .namespace }}
      namespace: {{ .namespace }}
      {{- end }}
    {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
cert-manager Certificate for a listener.
Takes: dict with "gateway", "listener", "root" and optionally "listenerSet"
*/}}
{{- define "listener.certificate" -}}
{{- $gateway := .gateway -}}
{{- $listener := .listener -}}
{{- $root := .root -}}
{{- $name := include "listener.resourceName" . -}}
{{- $baseDomain := include "listener.baseDomain" . -}}
{{- $dnsNames := list -}}
{{- if $listener.certificate.wildcard -}}
{{- $dnsNames = append $dnsNames (printf "*.%s" $baseDomain) -}}
{{- else if and $listener.hostname (not (hasPrefix "*." $listener.hostname)) -}}
{{- $dnsNames = append $dnsNames (tpl $listener.hostname $root) -}}
{{- else if and $gateway.dnsName (eq $baseDomain $root.Values.baseDomain) -}}
{{- $dnsNames = append $dnsNames (printf "%s.%s" $gateway.dnsName $baseDomain) -}}
{{- end -}}
{{- range $k, $v := $listener.subdomains -}}
{{- $dnsNames = append $dnsNames (printf "%s.%s" $v $baseDomain) -}}
{{- end -}}
{{- if not $dnsNames -}}
{{- fail (printf "gateway %q listener %q: certificate.enabled is true but no DNS name can be derived. Set the listener hostname, or the gateway dnsName together with a matching baseDomain." $gateway.name $listener.name) -}}
{{- end -}}
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: {{ $name }}
  namespace: {{ $root.Release.Namespace }}
  labels:
    {{- include "labels.common" $root | nindent 4 }}
spec:
  dnsNames:
  {{- range $dnsNames }}
  - {{ . | quote }}
  {{- end }}
  issuerRef:
    group: cert-manager.io
    kind: {{ dig "issuer" "kind" "" $listener.certificate | default "Issuer" }}
    name: {{ dig "issuer" "name" "" $listener.certificate | default (dig "tlsIssuer" "name" "" $gateway) }}
  secretName: {{ printf "%s-tls" $name }}
{{- end -}}

{{/*
external-dns DNSEndpoint for a listener, one CNAME per record pointing at the gateway apex.
Takes: dict with "gateway", "listener", "root", "records" (list of FQDNs) and optionally "listenerSet"
*/}}
{{- define "listener.dnsEndpoint" -}}
{{- $gateway := .gateway -}}
{{- $listener := .listener -}}
{{- $root := .root -}}
apiVersion: externaldns.k8s.io/v1alpha1
kind: DNSEndpoint
metadata:
  name: {{ include "listener.resourceName" . }}
  namespace: {{ $root.Release.Namespace }}
  {{- with $listener.dnsEndpoints.annotations }}
  annotations:
    {{- . | toYaml | nindent 4}}
  {{- end }}
  labels:
    {{- include "labels.common" $root | nindent 4 }}
spec:
  endpoints:
  {{- range .records }}
  - dnsName: {{ . | quote }}
    recordTTL: 300
    recordType: CNAME
    targets:
    - {{ $gateway.dnsName }}.{{ $gateway.overrideBaseDomain | default $root.Values.baseDomain }}
  {{- end }}
{{- end -}}

{{/*
ClientTrafficPolicy spec body: NLB defaults with the user's values merged on top.
Takes: dict with "clientTrafficPolicy" (the user block), "isNLB" and
"untrustedClientHeaders" (the effective list, which callers resolve).
Returns empty when there is nothing to render, so callers can guard with "with".
*/}}
{{- define "clientTrafficPolicy.spec" -}}
{{- $defaults := dict }}
{{- if .isNLB }}
{{- $_ := set $defaults "proxyProtocol" (dict "optional" false) }}
{{- $_ := set $defaults "healthCheck" (dict "path" "/healthz") }}
{{- /* A client-supplied X-Forwarded-For is never trusted. Behind an NLB envoy terminates
       the client connection itself, and the PROXY protocol has already set its source to
       the real client IP, so drop the untrusted client headers at the listener before
       envoy reads them and it rebuilds X-Forwarded-For from that address alone. */}}
{{- if .untrustedClientHeaders }}
{{- $_ := set $defaults "headers" (dict "earlyRequestHeaders" (dict "remove" .untrustedClientHeaders)) }}
{{- end }}
{{- end }}
{{- $spec := mergeOverwrite $defaults (deepCopy (omit (.clientTrafficPolicy | default dict) "enabled" "untrustedClientHeaders")) }}
{{- if $spec }}
{{- toYaml $spec }}
{{- end }}
{{- end -}}

{{/*
Name of a chart-managed ListenerSet resource. HTTPRoutes attach to this name, so it is
user-overridable; the supporting per-listener resources stay keyed on the listener set
key instead, which is unique within the gateway regardless of any name override.
Takes: dict with "gateway", "listenerSetKey" and "listenerSet"
*/}}
{{- define "listenerSet.name" -}}
{{- .listenerSet.name | default (printf "%s-%s" .gateway.name .listenerSetKey) -}}
{{- end -}}

{{/*
Effective errorPages for a listener set: gatewayClass defaults, then the gateway's
overrides, then the listener set's own.
Takes: dict with "gateway", "listenerSet" (the entry, not the key) and "root"
Returns: YAML, consume with fromYaml
*/}}
{{- define "listenerSet.errorPages" -}}
{{- $gatewayErrorPages := include "gateway.errorPages" (dict "gateway" .gateway "root" .root) | fromYaml }}
{{- include "errorPages.effective" (dict "class" $gatewayErrorPages "gateway" .listenerSet.errorPages) }}
{{- end -}}

{{/*
Whether a gateway's own ClientTrafficPolicy renders. Listener sets inherit this decision:
the NLB proxy-protocol annotation is per-Service, not per-port, so a listener set behind an
NLB needs the same proxyProtocol settings or it receives PROXY bytes it cannot parse.
Takes: dict with "gateway" and "root"
*/}}
{{- define "gateway.clientTrafficPolicyEnabled" -}}
{{- $ctp := .gateway.clientTrafficPolicy | default dict -}}
{{- $isNLB := include "gateway.awsNlb" (dict "provider" .root.Values.provider "gateway" .gateway) -}}
{{- if ternary $ctp.enabled (ne $isNLB "") (hasKey $ctp "enabled") -}}
true
{{- end -}}
{{- end -}}

{{/*
Fail when the gateway's listener sets collide with each other or with the gateway's own
listeners. The CRD's CEL rules only enforce uniqueness within a single resource, so a
duplicate port/protocol/hostname across resources would only surface at runtime as a
Conflicted condition on the merged Gateway.
Takes: dict with "gateway" and "root"
*/}}
{{- define "gateway.validateListeners" -}}
{{- $gateway := .gateway -}}
{{- $root := .root -}}
{{- $seen := dict -}}
{{- range $k, $l := $gateway.listeners -}}
{{- $key := printf "%v/%v/%v" $l.port $l.protocol (tpl ($l.hostname | default "") $root) -}}
{{- $_ := set $seen $key (printf "gateway listener %q" $l.name) -}}
{{- end -}}
{{- range $lsKey, $ls := $gateway.listenerSets -}}
{{- if $ls.enabled -}}
{{- range $k, $l := $ls.listeners -}}
{{- $key := printf "%v/%v/%v" $l.port $l.protocol (tpl ($l.hostname | default "") $root) -}}
{{- $where := printf "listener set %q listener %q" $lsKey $l.name -}}
{{- if hasKey $seen $key -}}
{{- fail (printf "gateway %q: %s collides with %s on port/protocol/hostname %q. Envoy Gateway would mark one of them Conflicted." $gateway.name $where (get $seen $key) $key) -}}
{{- end -}}
{{- $_ := set $seen $key $where -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
