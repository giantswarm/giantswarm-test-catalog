#!/bin/bash

CLUSTER_NAME="$HOSTNAME" # Use the pod hostname as the cluster name
NAMESPACE="{{ .Values.pgCluster.namespace }}"
EXPECTED_POD_COUNT={{ .Values.pgCluster.instances }} # Define expected pod count

# Make sure that a posgresql cluster with the same name is not already running
if kubectl get clusters.postgresql.cnpg.io "${CLUSTER_NAME}" -n "${NAMESPACE}" > /dev/null 2>&1; then
  echo "A cluster with the name ${CLUSTER_NAME} already exists in namespace ${NAMESPACE}. Please delete it before running the recovery test."
  exit 1
fi

# create the recovery test cluster
echo "Creating cluster ${CLUSTER_NAME} in namespace ${NAMESPACE}..."
# using kubectl patch in order to set the cluster name dynamically based on the pod hostname, and applying the manifest in one step
if ! kubectl patch --dry-run=client -f /etc/config/pg-recovery-cluster.yaml --type merge --patch '{"metadata":{"name":"'"$CLUSTER_NAME"'"}}' -oyaml | kubectl apply -f -; then

  echo "Failed to apply cluster manifest for ${CLUSTER_NAME}. Exiting."
  exit 1
fi

# Wait for the cluster to be created and report its status
echo "Waiting for cluster ${CLUSTER_NAME} in namespace ${NAMESPACE} to be ready..."
if ! kubectl wait --for=condition=Ready clusters.postgresql.cnpg.io/"${CLUSTER_NAME}" -n "${NAMESPACE}" --timeout="${WAIT_TIMEOUT}"; then
  echo "Cluster ${CLUSTER_NAME} did not become ready in ${WAIT_TIMEOUT} seconds."
  echo "Investigate the cluster state. The script will not delete it."
  exit 1 # Exit if cluster doesn't become ready
fi
echo "Cluster ${CLUSTER_NAME} is Ready."

echo "Running recovery test for cluster ${CLUSTER_NAME}"

# Execute tests until either those are successful or the timeout is reached
while [ $SECONDS -lt "$TEST_TIMEOUT" ]; do
  # Check if the postgresql cluster's pods are in 'Ready' state
  ready_pods_count=$(kubectl get pods -n "${NAMESPACE}" -l cnpg.io/cluster=${CLUSTER_NAME} -o jsonpath='{range .items[*]}{.status.conditions[?(@.type=="Ready")].status}{"\n"}{end}' | grep -c True || true)
  # The '|| true' ensures that if grep finds nothing (exit code 1), the script doesn't exit due to set -e (if it were set)

  if [[ "${ready_pods_count}" -eq "${EXPECTED_POD_COUNT}" ]]; then
    echo "All ${EXPECTED_POD_COUNT} pods for cluster ${CLUSTER_NAME} are in 'Ready' state. Recovery test successful."
    echo "Deleting the recovery test cluster ${CLUSTER_NAME}"

    # If the postgresql cluster's pods are ready, delete the cluster and end the test
    if ! kubectl delete clusters.postgresql.cnpg.io "${CLUSTER_NAME}" -n "${NAMESPACE}"; then
      echo "Failed to delete cluster ${CLUSTER_NAME}. Please delete it manually."
      exit 1 # Exit with error if deletion fails
    fi
    echo "Cluster ${CLUSTER_NAME} deleted successfully."

    echo "Deleting persistent volume claims for the ${CLUSTER_NAME} cluster"
    if ! kubectl delete pvc -l cnpg.io/cluster="${CLUSTER_NAME}" -n "${NAMESPACE}"; then
      echo "Failed to delete pvc for the ${CLUSTER_NAME} cluster. Please delete it manually."
      exit 1 # Exit with error if deletion fails
    fi
    echo "Persistent volume claims for the ${CLUSTER_NAME} cluster deleted successfully."
    exit 0
  else
    echo "Found ${ready_pods_count} ready pods out of ${EXPECTED_POD_COUNT} for cluster ${CLUSTER_NAME}. Waiting... ($SECONDS seconds elapsed)"
  fi

  sleep 60 # Check more frequently
done

# If the timeout is reached, end the test without deleting the cluster to allow further investigation
echo "Timeout reached after $TEST_TIMEOUT seconds. Found ${ready_pods_count} ready pods out of ${EXPECTED_POD_COUNT}."
echo "Recovery test for ${CLUSTER_NAME} FAILED. The cluster will not be deleted to allow further investigation."
exit 1 # Explicitly exit with an error code on timeout
