{{/* vim: set filetype=mustache: */}}
{{/*
Helpers of the modelServing wiring (templates/model-serving/): model serving
on llm-d — the serving presets and their discovery ConfigMap, the Hugging Face
cache claim, the Kyverno cache policies, the network policies of the serving
namespace and the models Gateway. A feature switch of the roster
(components.modelServing.enabled, no chart behind it) plus the modelServing:
values block; it runs on the llm-d control plane the kserve-llmisvc-crd and
kserve-llmisvc-resources components install (or an LLMInferenceService API the
cluster already serves). The chart renders no serving.kserve.io object itself:
model-manager composes every served model into an LLMInferenceService on the
well-known LLMInferenceServiceConfigs (components.kserve-runtime-configs).
*/}}

{{/*
Truthy when the modelServing feature is on (components.modelServing.enabled).
Optional: a roster that does not carry the entry is off, never force-on.
*/}}
{{- define "agent-platform.modelServing.enabled" -}}
{{- include "agent-platform.optionalComponentEnabled" (dict "root" . "name" "modelServing") -}}
{{- end -}}

{{/*
Truthy when the platform installs the llm-d control plane itself: the
kserve-llmisvc-crd AND kserve-llmisvc-resources components are on.
*/}}
{{- define "agent-platform.modelServing.llmisvcBundled" -}}
{{- if and (include "agent-platform.optionalComponentEnabled" (dict "root" . "name" "kserve-llmisvc-crd")) (include "agent-platform.optionalComponentEnabled" (dict "root" . "name" "kserve-llmisvc-resources")) -}}true{{- end -}}
{{- end -}}

{{/*
Truthy when the cluster serves the LLMInferenceService API
(serving.kserve.io/v1alpha2). Helm fills .Capabilities.APIVersions from the
cluster on install/upgrade; an offline `helm template` has to be told with
--api-versions.
*/}}
{{- define "agent-platform.modelServing.llmisvcApiPresent" -}}
{{- if .Capabilities.APIVersions.Has "serving.kserve.io/v1alpha2" -}}true{{- end -}}
{{- end -}}

{{/*
The serving namespace: where the LLMInferenceServices run, the cache PVC and
the chat-template ConfigMaps live and the Kyverno policies match. Empty falls
back to the release namespace.
*/}}
{{- define "agent-platform.modelServing.namespace" -}}
{{- .Values.modelServing.namespace.name | default .Release.Namespace -}}
{{- end -}}

{{/*
Truthy when this chart manages the Hugging Face cache claim: model serving on,
modelServing.cache.enabled and no existingClaim. The claim is applied by the
hook Job of templates/model-serving/cache-pvc.yaml, never rendered as a release
resource (giantswarm/agent-platform#483).
*/}}
{{- define "agent-platform.modelServing.cacheClaimManaged" -}}
{{- if and (include "agent-platform.modelServing.enabled" .) .Values.modelServing.cache.enabled (not .Values.modelServing.cache.pvc.existingClaim) -}}true{{- end -}}
{{- end -}}

{{/*
The cache claim every model pod mounts: the pre-existing claim when named,
else the claim this chart applies (cache-pvc.yaml).
*/}}
{{- define "agent-platform.modelServing.claimName" -}}
{{- $pvc := .Values.modelServing.cache.pvc -}}
{{- $pvc.existingClaim | default $pvc.name -}}
{{- end -}}

{{/*
Truthy when this chart renders the cache claim's StorageClass
(templates/model-serving/storageclass.yaml): the claim is this chart's
(cacheClaimManaged) and modelServing.cache.storageClass.create. Refuses a
pvc.storageClassName next to it — two values would name the claim's class.
*/}}
{{- define "agent-platform.modelServing.cacheStorageClassManaged" -}}
{{- $cache := .Values.modelServing.cache -}}
{{- if and (include "agent-platform.modelServing.cacheClaimManaged" .) $cache.storageClass.create -}}
{{- with $cache.pvc.storageClassName -}}
{{- fail (printf "modelServing.cache.pvc.storageClassName (%q) and modelServing.cache.storageClass.create: true both name the cache claim's class; set storageClass.create: false to keep the named class (\"-\" is the empty class), or drop pvc.storageClassName for the class the chart renders" .) -}}
{{- end -}}
true
{{- end -}}
{{- end -}}

{{/*
The name of the cache claim's StorageClass, rendered or referenced:
modelServing.cache.storageClass.name, else <chart>-<claim>
(agent-platform-connectivity-hf-cache) — cluster-scoped, so named after the
chart like the serving ClusterPolicies.
*/}}
{{- define "agent-platform.modelServing.cacheStorageClass.name" -}}
{{- $cache := .Values.modelServing.cache -}}
{{- $cache.storageClass.name | default (printf "%s-%s-%s" (include "name" .) $cache.pvc.name (include "agent-platform.modelServing.cacheStorageClass.digest" .)) -}}
{{- end -}}

{{- /*
The digest a default class name carries (giantswarm/agent-platform#570): eight
hex characters of the provisioner and its parameters (sorted, key=value), so the
class is named by what the API forbids changing on it. A parameter change renders
a new class; the old Helm-owned one goes with the upgrade instead of failing it
on a forbidden update. A name set in storageClass.name carries none: the
operator owns it.
*/ -}}
{{- define "agent-platform.modelServing.cacheStorageClass.digest" -}}
{{- $sc := .Values.modelServing.cache.storageClass -}}
{{- $spec := $sc.provisioner | toString -}}
{{- range $k, $v := $sc.parameters }}{{- $spec = printf "%s;%s=%s" $spec $k (toString $v) -}}{{ end -}}
{{- $spec | sha256sum | trunc 8 -}}
{{- end -}}

{{/*
The storageClassName the applied claim carries: pvc.storageClassName when set
("-" included — the caller renders it as the empty class), else the chart's
class when it renders one or storageClass.name names an existing one, else
nothing (empty string = falsy): the cluster's default class.
*/}}
{{- define "agent-platform.modelServing.cacheClaim.storageClassName" -}}
{{- $cache := .Values.modelServing.cache -}}
{{- if $cache.pvc.storageClassName -}}
{{- $cache.pvc.storageClassName -}}
{{- else if or (include "agent-platform.modelServing.cacheStorageClassManaged" .) $cache.storageClass.name -}}
{{- include "agent-platform.modelServing.cacheStorageClass.name" . -}}
{{- end -}}
{{- end -}}

{{/*
The GPU node pool input (modelServing.gpuPool) as the scheduling it puts on a
workload the chart renders onto the pool, as JSON:
  { "tolerations": [<the toleration of the pool taint>] | [], "nodeSelector": {...} }
The toleration tolerates the pool taint with operator Exists (no value — the
gpu-node-pool chart's taint) or Equal (taint.value set); an empty taint.key
yields none. One source for the presets and the discovery ConfigMap, so the
two sites never disagree.
Usage: $pool := include "agent-platform.modelServing.gpuPool" . | fromJson
*/}}
{{- define "agent-platform.modelServing.gpuPool" -}}
{{- $gp := .Values.modelServing.gpuPool | default dict -}}
{{- $taint := get $gp "taint" | default dict -}}
{{- $tolerations := list -}}
{{- if get $taint "key" -}}
{{- $tol := dict "key" (get $taint "key") "operator" "Exists" -}}
{{- with get $taint "value" -}}
{{- $_ := set $tol "operator" "Equal" -}}
{{- $_ := set $tol "value" . -}}
{{- end -}}
{{- with get $taint "effect" -}}
{{- $_ := set $tol "effect" . -}}
{{- end -}}
{{- $tolerations = list $tol -}}
{{- end -}}
{{- dict "tolerations" $tolerations "nodeSelector" (get $gp "nodeSelector" | default dict) | toJson -}}
{{- end -}}

{{/*
Merges the pool's scheduling under a workload's own: the pool toleration first
and the workload's after it (an entry equal to the pool's once), the pool
selector under the workload's selector (the workload's keys win). Returns JSON
  { "tolerations": [...], "nodeSelector": {...} }
both empty when neither side has anything, so the caller renders nothing then.
Usage: include "agent-platform.modelServing.poolScheduling" (dict "root" $ "tolerations" $list "nodeSelector" $map) | fromJson
*/}}
{{- define "agent-platform.modelServing.poolScheduling" -}}
{{- $pool := include "agent-platform.modelServing.gpuPool" .root | fromJson -}}
{{- $tolerations := $pool.tolerations -}}
{{- range (.tolerations | default list) -}}
{{- if not (has . $tolerations) -}}
{{- $tolerations = append $tolerations . -}}
{{- end -}}
{{- end -}}
{{- $selector := merge (deepCopy (.nodeSelector | default dict)) $pool.nodeSelector -}}
{{- dict "tolerations" $tolerations "nodeSelector" $selector | toJson -}}
{{- end -}}

{{/*
Labels of every object the wiring renders.
*/}}
{{- define "agent-platform.modelServing.labels" -}}
{{ include "labels.common" . }}
app.kubernetes.io/component: model-serving
{{- end -}}

{{/*
The selector label of the pre-pull DaemonSet's pods (templates/model-serving/
prepull.yaml, giantswarm/agent-platform#545): the DaemonSet's selector and its
deny-all network policy match it; the model pod shape (podShape below) and no
policy of it carries it, so the pods stay outside every rule written for a
served model.
*/}}
{{- define "agent-platform.modelServing.prepull.selectorLabels" -}}
agent-platform.giantswarm.io/model-serving-prepull: "true"
{{- end -}}

{{/*
Whether the pre-pull DaemonSet renders (templates/model-serving/prepull.yaml):
model serving on and modelServing.prepull.enabled. Its cleanup hook and the
hook identity's pre-delete event follow this.
*/}}
{{- define "agent-platform.modelServing.prepull.enabled" -}}
{{- if and (include "agent-platform.modelServing.enabled" .) .Values.modelServing.prepull.enabled -}}true{{- end -}}
{{- end -}}

{{/* The pre-pull DaemonSet's name: the deny-all policy, the cleanup hook and its RBAC rule name the same object. */}}
{{- define "agent-platform.modelServing.prepull.name" -}}
{{- printf "%s-model-serving-prepull" (include "name" .) -}}
{{- end -}}

{{/*
The nodes the pre-pull DaemonSet selects before the pool's label is merged
under them (poolScheduling), as a JSON map: modelServing.prepull.nodeSelector
when the installation sets one — that map alone — else the chart's default,
Karpenter's label on every node of a GPU instance type. The default lives here
and not in values.yaml on purpose (giantswarm/agent-platform#562): Helm merges
maps, so a default key in values.yaml would be kept next to whatever an
installation sets — a selector no node carries — and a null for it is
coalesced away by the meta chart before it forwards its values. An empty map
is the default, a set map replaces it.
Usage: include "agent-platform.modelServing.prepull.nodeSelector" . | fromJson
*/}}
{{- define "agent-platform.modelServing.prepull.nodeSelector" -}}
{{- with (.Values.modelServing.prepull.nodeSelector | default dict) -}}
{{- toJson . -}}
{{- else -}}
{{- dict "karpenter.k8s.aws/instance-gpu-manufacturer" "nvidia" | toJson -}}
{{- end -}}
{{- end -}}

{{/*
The registry host of modelServing.modelImages.registry (giantswarm/agent-platform#551),
validated: a host with an optional port (registry.example.com,
registry.example.com:5000, an in-cluster Service name), no scheme, no path.
Empty when unset: every oci:// reference is published as written.
*/}}
{{- define "agent-platform.modelServing.modelImages.registry" -}}
{{- $registry := toString (dig "modelImages" "registry" "" .Values.modelServing) -}}
{{- if and $registry (not (regexMatch "^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?(:[0-9]{1,5})?$" $registry)) -}}
{{- fail (printf "modelServing.modelImages.registry %q must be a registry host — host or host:port, no scheme, no path; it replaces the host of every oci:// preset's storageUri, the path stays" $registry) -}}
{{- end -}}
{{- $registry -}}
{{- end -}}

{{/*
The storageUri of a preset served from an OCI model image, as published: the
reference's registry host — the segment before the first / — replaced by
modelServing.modelImages.registry when that is set, the path, tag or digest as
written; the reference as written when the registry is empty. A reference
without a host (oci://<name>:<tag>) is refused: the host is what an
installation swaps, and the pre-pull derives the image from the published form.
Usage: include "agent-platform.modelServing.publishedOciUri" (dict "root" $ "where" $where "storageUri" $uri)
*/}}
{{- define "agent-platform.modelServing.publishedOciUri" -}}
{{- $ref := trimPrefix "oci://" .storageUri -}}
{{- if or (not (contains "/" $ref)) (hasPrefix "/" $ref) -}}
{{- fail (printf "%s: spec.model.storageUri %q names no registry host; an OCI model image is oci://<registry>/<path>[:tag|@digest] — the host is what modelServing.modelImages.registry replaces" .where .storageUri) -}}
{{- end -}}
{{- $registry := include "agent-platform.modelServing.modelImages.registry" .root -}}
{{- if $registry -}}
{{- printf "oci://%s/%s" $registry (rest (splitList "/" $ref) | join "/") -}}
{{- else -}}
{{- .storageUri -}}
{{- end -}}
{{- end -}}

{{/*
The serving presets in effect, as a JSON object keyed by preset name:
  { "<name>": { "source": "shipped" | "values", "preset": <ServingPreset> } }
The shipped set (files/model-serving/presets/*.yaml, unless
shippedPresets.enabled is false) minus shippedPresets.exclude, then the
modelServing.presets entries, a same-named entry replacing the shipped one.
Names are checked here; the document shape is checked by
"agent-platform.modelServing.resolvePreset".
Usage: $presets := include "agent-platform.modelServing.presets" . | fromJson
*/}}
{{- define "agent-platform.modelServing.presets" -}}
{{- $ms := .Values.modelServing -}}
{{- $out := dict -}}
{{- $shipped := list -}}
{{- range $path, $_ := .Files.Glob "files/model-serving/presets/*.yaml" -}}
{{- $doc := $.Files.Get $path | fromYaml -}}
{{- if hasKey $doc "Error" -}}
{{- fail (printf "%s: not a YAML mapping: %s" $path $doc.Error) -}}
{{- end -}}
{{- $name := dig "metadata" "name" "" $doc -}}
{{- $stem := $path | base | trimSuffix ".yaml" -}}
{{- if ne $name $stem -}}
{{- fail (printf "%s: metadata.name (%q) must equal the file name (%q)" $path $name $stem) -}}
{{- end -}}
{{- $shipped = append $shipped $name -}}
{{- if and $ms.shippedPresets.enabled (not (has $name $ms.shippedPresets.exclude)) -}}
{{- $_ := set $out $name (dict "source" "shipped" "preset" $doc) -}}
{{- end -}}
{{- end -}}
{{- range $ms.shippedPresets.exclude -}}
{{- if not (has . $shipped) -}}
{{- fail (printf "modelServing.shippedPresets.exclude names %q, which is not a shipped preset (shipped: %s)" . (join ", " $shipped)) -}}
{{- end -}}
{{- end -}}
{{- $seen := list -}}
{{- range $i, $doc := $ms.presets -}}
{{- if not (kindIs "map" $doc) -}}
{{- fail (printf "modelServing.presets[%d]: a preset is a ServingPreset mapping" $i) -}}
{{- end -}}
{{- $name := dig "metadata" "name" "" $doc -}}
{{- if not $name -}}
{{- fail (printf "modelServing.presets[%d]: metadata.name is required" $i) -}}
{{- end -}}
{{- if has $name $seen -}}
{{- fail (printf "modelServing.presets: preset %q is listed twice" $name) -}}
{{- end -}}
{{- $seen = append $seen $name -}}
{{- $_ := set $out $name (dict "source" "values" "preset" $doc) -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/*
Validates one preset and resolves it into the published form the portal and
model-manager read: model.format defaulted to vLLM, resources.gpus to 1,
requirements.overheadGiB to 30, and the chat template (one
of file, content, existingConfigMap) resolved to the ConfigMap that holds it,
with the --chat-template flag appended to args, the GPU node pool's
toleration and selector merged under spec.scheduling (modelServing.gpuPool), and
an oci:// storageUri's registry host swapped for modelServing.modelImages.registry.
Returns JSON:
  { "preset": <published ServingPreset>,
    "chatTemplate": { "render": bool, "name": string, "key": string, "content": string } }
Usage: include "agent-platform.modelServing.resolvePreset" (dict "root" $ "name" $name "entry" $entry) | fromJson
*/}}
{{- define "agent-platform.modelServing.resolvePreset" -}}
{{- $root := .root -}}
{{- $name := .name -}}
{{- $where := printf "serving preset %q (%s)" $name .entry.source -}}
{{- $doc := deepCopy .entry.preset -}}
{{- if ne (dig "apiVersion" "" $doc) "agent-platform.giantswarm.io/v1alpha1" -}}
{{- fail (printf "%s: apiVersion must be agent-platform.giantswarm.io/v1alpha1" $where) -}}
{{- end -}}
{{- if ne (dig "kind" "" $doc) "ServingPreset" -}}
{{- fail (printf "%s: kind must be ServingPreset" $where) -}}
{{- end -}}
{{- if not (regexMatch "^[a-z0-9]([-a-z0-9]{0,28}[a-z0-9])?$" $name) -}}
{{- fail (printf "%s: metadata.name must be a lowercase DNS-1123 label of at most 30 characters (it names the LLMInferenceService and the preset ConfigMaps)" $where) -}}
{{- end -}}
{{- $spec := get $doc "spec" | default dict -}}
{{- if not (kindIs "map" $spec) -}}
{{- fail (printf "%s: spec must be a mapping" $where) -}}
{{- end -}}
{{- /* The classic InferenceService path is gone with it its two preset fields:
       spec.runtime (a ClusterServingRuntime) and spec.predictor (InferenceService
       predictor fields). A model composes onto the well-known
       LLMInferenceServiceConfigs; spec.template carries LLMInferenceService
       template fields. */ -}}
{{- range $removed := list "runtime" "predictor" -}}
{{- if hasKey $spec $removed -}}
{{- fail (printf "%s: spec.%s is no longer a preset field — the classic InferenceService path was removed; a preset composes onto the well-known LLMInferenceServiceConfigs, and LLMInferenceService template fields go under spec.template (see UPGRADE.md)" $where $removed) -}}
{{- end -}}
{{- end -}}
{{- /* spec.router.scheduler is the per-preset switch for the llm-d endpoint
       picker model-manager composes; nothing else goes under router. */ -}}
{{- if hasKey $spec "router" -}}
{{- $router := get $spec "router" -}}
{{- if not (kindIs "map" $router) -}}
{{- fail (printf "%s: spec.router must be a mapping" $where) -}}
{{- end -}}
{{- range $key, $value := $router -}}
{{- if ne $key "scheduler" -}}
{{- fail (printf "%s: spec.router.%s is not a preset field; spec.router carries scheduler only" $where $key) -}}
{{- end -}}
{{- if not (kindIs "bool" $value) -}}
{{- fail (printf "%s: spec.router.scheduler must be true or false" $where) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- /* spec.split.env is the environment model-manager adds to a split's
       leader and workers only; nothing else goes under split, and each entry
       is a literal name and value. */ -}}
{{- if hasKey $spec "split" -}}
{{- $split := get $spec "split" -}}
{{- if not (kindIs "map" $split) -}}
{{- fail (printf "%s: spec.split must be a mapping" $where) -}}
{{- end -}}
{{- range $key, $_ := $split -}}
{{- if ne $key "env" -}}
{{- fail (printf "%s: spec.split.%s is not a preset field; spec.split carries env only" $where $key) -}}
{{- end -}}
{{- end -}}
{{- $splitEnv := get $split "env" | default list -}}
{{- if not (kindIs "slice" $splitEnv) -}}
{{- fail (printf "%s: spec.split.env must be a list of {name, value}" $where) -}}
{{- end -}}
{{- range $j, $e := $splitEnv -}}
{{- if not (kindIs "map" $e) -}}
{{- fail (printf "%s: spec.split.env[%d] must be a {name, value} mapping" $where $j) -}}
{{- end -}}
{{- range $key, $_ := $e -}}
{{- if not (has $key (list "name" "value")) -}}
{{- fail (printf "%s: spec.split.env[%d].%s is not allowed; a split's environment is a literal name and value" $where $j $key) -}}
{{- end -}}
{{- end -}}
{{- if not (and (kindIs "string" (get $e "name")) (get $e "name")) -}}
{{- fail (printf "%s: spec.split.env[%d].name must be a non-empty string" $where $j) -}}
{{- end -}}
{{- if not (kindIs "string" (get $e "value")) -}}
{{- fail (printf "%s: spec.split.env[%d].value must be a string (quote a number: \"1\")" $where $j) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if not (get $spec "displayName") -}}
{{- fail (printf "%s: spec.displayName is required" $where) -}}
{{- end -}}
{{- $model := get $spec "model" | default dict -}}
{{- if not (kindIs "map" $model) -}}
{{- fail (printf "%s: spec.model must be a mapping" $where) -}}
{{- end -}}
{{- if not (get $model "id") -}}
{{- fail (printf "%s: spec.model.id (the Hugging Face repository) is required" $where) -}}
{{- end -}}
{{- if not (get $model "storageUri") -}}
{{- fail (printf "%s: spec.model.storageUri is required" $where) -}}
{{- end -}}
{{- /* An OCI model image (oci://…): the registry host published is the
       installation's (modelServing.modelImages.registry), the path kept —
       here, so the preset ConfigMap, the pre-pull DaemonSet and every
       consumer read one value (#551). */ -}}
{{- $storageUri := toString (get $model "storageUri") -}}
{{- if hasPrefix "oci://" $storageUri -}}
{{- $_ := set $model "storageUri" (include "agent-platform.modelServing.publishedOciUri" (dict "root" $root "where" $where "storageUri" $storageUri)) -}}
{{- end -}}
{{- $_ := set $model "format" (get $model "format" | default "vLLM") -}}
{{- $_ := set $spec "model" $model -}}
{{- $resources := get $spec "resources" | default dict -}}
{{- if not (kindIs "map" $resources) -}}
{{- fail (printf "%s: spec.resources must be a mapping" $where) -}}
{{- end -}}
{{- if not (hasKey $resources "gpus") -}}
{{- $_ := set $resources "gpus" 1 -}}
{{- end -}}
{{- $_ := set $spec "resources" $resources -}}
{{- $requirements := get $spec "requirements" | default dict -}}
{{- if not (kindIs "map" $requirements) -}}
{{- fail (printf "%s: spec.requirements must be a mapping" $where) -}}
{{- end -}}
{{- if not (hasKey $requirements "weightsGiB") -}}
{{- fail (printf "%s: spec.requirements.weightsGiB is required (the fit check adds overheadGiB to it)" $where) -}}
{{- end -}}
{{- if not (hasKey $requirements "overheadGiB") -}}
{{- $_ := set $requirements "overheadGiB" 30 -}}
{{- end -}}
{{- if and (hasKey $requirements "residentWeightsGiB") (gt (float64 (get $requirements "residentWeightsGiB")) (float64 (get $requirements "weightsGiB"))) -}}
{{- fail (printf "%s: spec.requirements.residentWeightsGiB (%v) exceeds weightsGiB (%v); the resident weights are the part of the checkpoint held in memory" $where (get $requirements "residentWeightsGiB") (get $requirements "weightsGiB")) -}}
{{- end -}}
{{- /* The GPU generation floor is a compute capability the form compares as
       major.minor; a number (8.9, or 10.0 read as 10) would publish a value the
       consumers cannot parse, so it is a quoted string of that form. */ -}}
{{- if hasKey $requirements "minComputeCapability" -}}
{{- $floor := get $requirements "minComputeCapability" -}}
{{- if or (not (kindIs "string" $floor)) (not (regexMatch "^[0-9]+\\.[0-9]+$" $floor)) -}}
{{- fail (printf "%s: spec.requirements.minComputeCapability (%v) is not a quoted compute capability of the form major.minor (\"8.9\")" $where $floor) -}}
{{- end -}}
{{- end -}}
{{- $_ := set $spec "requirements" $requirements -}}
{{- $args := get $spec "args" | default list -}}
{{- /* Every argument reaches vLLM through the well-known runtime template's
       entrypoint, which re-parses the arguments with a shell (eval "… $@"):
       a bare JSON is split at its whitespace and loses its double quotes, an
       unbalanced quote fails the whole command, a metacharacter expands.
       Outside single-quoted spans an argument therefore carries none of them;
       a value that needs them is single-quoted inside one argument
       (--default-chat-template-kwargs='{"enable_thinking": false}'). */ -}}
{{- range $args -}}
{{- $arg := toString . -}}
{{- /* The API interfaces a served model answers are read from its runtime's
       route list, GET /openapi.json (model-manager); the flag removes it. */ -}}
{{- if regexMatch "^--disable-fastapi-docs(=|$)" $arg -}}
{{- fail (printf "%s: spec.args carries %s, which removes the runtime's /openapi.json — the route list the platform reads a served model's API interfaces from (chat completions, Responses, Messages, embeddings); drop the flag" $where (quote $arg)) -}}
{{- end -}}
{{- if regexMatch "[[:space:]\"'$`\\\\;&|<>(){}\\[\\]*?]" (regexReplaceAll "'[^']*'" $arg "") -}}
{{- fail (printf "%s: spec.args %s carries whitespace, a quote or a shell metacharacter outside single quotes; the runtime template re-parses every argument through a shell (eval \"… $@\"), which splits it there and eats the quotes — write the value single-quoted inside one argument, e.g. --default-chat-template-kwargs='{\"enable_thinking\": false}'" $where (quote $arg)) -}}
{{- end -}}
{{- end -}}
{{- $chatTemplate := get $spec "chatTemplate" | default dict -}}
{{- $render := dict "render" false "name" "" "key" "" "content" "" -}}
{{- if $chatTemplate -}}
{{- range $args -}}
{{- if hasPrefix "--chat-template" (toString .) -}}
{{- fail (printf "%s: spec.args carries %s but spec.chatTemplate is set; the chart appends the --chat-template flag itself" $where .) -}}
{{- end -}}
{{- end -}}
{{- $sources := list -}}
{{- range $source := list "file" "content" "existingConfigMap" -}}
{{- if get $chatTemplate $source -}}
{{- $sources = append $sources $source -}}
{{- end -}}
{{- end -}}
{{- if ne (len $sources) 1 -}}
{{- fail (printf "%s: spec.chatTemplate needs exactly one of file (shipped under files/model-serving/chat-templates/), content (inline) or existingConfigMap (pre-created in the serving namespace); got %d" $where (len $sources)) -}}
{{- end -}}
{{- $key := get $chatTemplate "key" | default "chat-template.jinja" -}}
{{- $mountPath := get $chatTemplate "mountPath" | default "/mnt/chat-template" -}}
{{- $configMap := printf "agent-platform-chat-template-%s" $name -}}
{{- $content := "" -}}
{{- if get $chatTemplate "file" -}}
{{- $content = $root.Files.Get (printf "files/model-serving/chat-templates/%s" (get $chatTemplate "file")) -}}
{{- if not $content -}}
{{- fail (printf "%s: spec.chatTemplate.file %q is not shipped under files/model-serving/chat-templates/" $where (get $chatTemplate "file")) -}}
{{- end -}}
{{- else if get $chatTemplate "content" -}}
{{- $content = get $chatTemplate "content" -}}
{{- else -}}
{{- $configMap = get $chatTemplate "existingConfigMap" -}}
{{- end -}}
{{- $render = dict "render" (ne $content "") "name" $configMap "key" $key "content" $content -}}
{{- $_ := set $spec "chatTemplate" (dict "configMap" $configMap "key" $key "mountPath" $mountPath) -}}
{{- $args = append $args (printf "--chat-template=%s/%s" $mountPath $key) -}}
{{- end -}}
{{- $_ := set $spec "args" $args -}}
{{- /* The GPU node pool (modelServing.gpuPool): its toleration first and its
       selector under the preset's own scheduling block; nothing when both
       sides are empty. */ -}}
{{- $scheduling := get $spec "scheduling" | default dict -}}
{{- if not (kindIs "map" $scheduling) -}}
{{- fail (printf "%s: spec.scheduling must be a mapping" $where) -}}
{{- end -}}
{{- $pool := include "agent-platform.modelServing.poolScheduling" (dict "root" $root "tolerations" (get $scheduling "tolerations") "nodeSelector" (get $scheduling "nodeSelector")) | fromJson -}}
{{- with $pool.tolerations -}}
{{- $_ := set $scheduling "tolerations" . -}}
{{- end -}}
{{- with $pool.nodeSelector -}}
{{- $_ := set $scheduling "nodeSelector" . -}}
{{- end -}}
{{- if $scheduling -}}
{{- $_ := set $spec "scheduling" $scheduling -}}
{{- end -}}
{{- $_ := set $doc "spec" $spec -}}
{{- dict "preset" $doc "chatTemplate" $render | toJson -}}
{{- end -}}

{{/*
Cilium egress rules to the model download endpoints on TCP 443: the Hugging
Face FQDN selectors (modelServing.networkPolicy.huggingFace.fqdns), the CIDR
list (huggingFace.cidrs) and networkPolicy's additionalEgressCIDRs /
additionalEgressFQDNs. Shared by the predictor and download-Job policies. The
caller pipes the output through trim and nindent.
*/}}
{{- define "agent-platform.modelServing.huggingFaceEgress.cilium" -}}
{{- $hf := .Values.modelServing.networkPolicy.huggingFace -}}
{{- $np := .Values.networkPolicy -}}
{{- with $hf.fqdns }}
# Hugging Face by name (resolved through the DNS proxy rule above).
- toFQDNs:
    {{- toYaml . | nindent 4 }}
  toPorts:
    - ports:
        - port: "443"
          protocol: TCP
{{- end }}
{{- with $hf.cidrs }}
# Hugging Face by address (a mirror, a proxy, an S3 endpoint).
- toCIDR:
    {{- toYaml . | nindent 4 }}
  toPorts:
    - ports:
        - port: "443"
          protocol: TCP
{{- end }}
{{- with $np.additionalEgressCIDRs }}
- toCIDR:
    {{- toYaml . | nindent 4 }}
  toPorts:
    - ports:
        - port: "443"
          protocol: TCP
{{- end }}
{{- with $np.additionalEgressFQDNs }}
- toFQDNs:
    {{- toYaml . | nindent 4 }}
  toPorts:
    - ports:
        - port: "443"
          protocol: TCP
{{- end }}
{{- end -}}

{{/*
Kubernetes NetworkPolicy egress rules to the model download endpoints on TCP
443 (the kubernetes flavor of huggingFaceEgress.cilium). Vanilla
NetworkPolicy selects IP blocks, never names: with huggingFace.cidrs empty,
every public destination is admitted on 443 (0.0.0.0/0 minus
networkPolicy.kubernetes.worldExcludedCIDRs, the data plane's own rule); a
CIDR list replaces that with exactly those blocks. The caller pipes the
output through trim and nindent.
*/}}
{{- define "agent-platform.modelServing.huggingFaceEgress.kubernetes" -}}
{{- $hf := .Values.modelServing.networkPolicy.huggingFace -}}
{{- $np := .Values.networkPolicy -}}
{{- if $hf.cidrs }}
# Hugging Face by address (huggingFace.cidrs): these blocks only.
- to:
    {{- range $hf.cidrs }}
    - ipBlock:
        cidr: {{ . | quote }}
    {{- end }}
  ports:
    - port: 443
      protocol: TCP
{{- else }}
# Hugging Face: vanilla NetworkPolicy has no FQDN selector, so every public
# destination on 443 (huggingFace.cidrs narrows it to a mirror or proxy).
- to:
    - ipBlock:
        cidr: 0.0.0.0/0
        except: {{ toYaml $np.kubernetes.worldExcludedCIDRs | nindent 10 }}
  ports:
    - port: 443
      protocol: TCP
{{- end }}
{{- with $np.additionalEgressCIDRs }}
- to:
    {{- range . }}
    - ipBlock:
        cidr: {{ . | quote }}
    {{- end }}
  ports:
    - port: 443
      protocol: TCP
{{- end }}
{{- end -}}

{{/*
Truthy when the models Gateway renders (giantswarm/agent-platform#326): the
modelServing switch and the llm-d controller component on, and
modelServing.modelsGateway.enabled.
*/}}
{{- define "agent-platform.modelServing.modelsGateway.enabled" -}}
{{- if and (include "agent-platform.modelServing.enabled" .) (include "agent-platform.kserve.llmisvcEnabled" .) (.Values.modelServing.modelsGateway).enabled -}}true{{- end -}}
{{- end -}}

{{/* The models Gateway's public hostname: <hostPrefix>.<global.domain>. */}}
{{- define "agent-platform.modelServing.modelsGateway.host" -}}
{{- printf "%s.%s" .Values.modelServing.modelsGateway.hostPrefix (include "agent-platform.domain" (dict "ctx" . "for" "modelServing.modelsGateway.hostPrefix")) -}}
{{- end -}}

{{/* The models Gateway's issuer: the block's own, else global.identity.issuerUrl (or a render failure). */}}
{{- define "agent-platform.modelServing.modelsGateway.issuer" -}}
{{- $issuer := .Values.modelServing.modelsGateway.jwtAuthentication.issuer -}}
{{- if not $issuer -}}
{{- $issuer = include "agent-platform.issuerUrl" (dict "ctx" . "for" "modelServing.modelsGateway.jwtAuthentication") -}}
{{- end -}}
{{- $issuer -}}
{{- end -}}

{{/*
The models Gateway's JWKS block with the host resolved (JSON): the block's own
host, else the JWKS endpoint the issuer publishes (agent-platform.idp.jwks) —
the public issuer's host on the block's port for Dex, and for Google
www.googleapis.com:443 at /oauth2/v3/certs, its host, port and path together.
*/}}
{{- define "agent-platform.modelServing.modelsGateway.jwks" -}}
{{- $jwks := deepCopy .Values.modelServing.modelsGateway.jwtAuthentication.jwks -}}
{{- if not $jwks.host -}}
{{- $published := include "agent-platform.idp.jwks" (include "agent-platform.modelServing.modelsGateway.issuer" .) | fromJson -}}
{{- $_ := set $jwks "host" ($published.host | default "") -}}
{{- if $published.path -}}
{{- $_ := set $jwks "port" $published.port -}}
{{- $_ := set $jwks "path" $published.path -}}
{{- end -}}
{{- end -}}
{{- $jwks | toJson -}}
{{- end -}}

{{/*
The TLS Secret of the models Gateway's listener: tls.secretName, else <name>-tls
while a Certificate renders (tls.issuerRef.name set), else the platform's
wildcard (gatewayApi.gateway.tls.secretName).
*/}}
{{- define "agent-platform.modelServing.modelsGateway.tlsSecretName" -}}
{{- $mg := .Values.modelServing.modelsGateway -}}
{{- if $mg.tls.secretName -}}{{- $mg.tls.secretName -}}
{{- else if $mg.tls.issuerRef.name -}}{{- printf "%s-tls" $mg.name -}}
{{- else -}}{{- .Values.gatewayApi.gateway.tls.secretName -}}
{{- end -}}
{{- end -}}

{{/*
The pods the llm-d controller runs for a served model: the LLMInferenceService
workload pods, which carry app.kubernetes.io/part-of=llminferenceservice,
app.kubernetes.io/name=<name> and an app.kubernetes.io/component of
llminferenceservice-workload[-prefill] — a single-node Deployment's pod — or
llminferenceservice-workload-{leader,worker}[-prefill] — the pods of a
LeaderWorkerSet, a model split across nodes (modelServing.fastLinks) — and
serve from `main` (giantswarm/agent-platform#506). kserve.io/component=workload
is no selector: a LeaderWorkerSet's workers do not carry it. Every selector of the
serving namespace's model pods — the Kyverno mutations, the network policies,
the PolicyException — renders from this one description, so they never
disagree. JSON:
  { "name": "llmisvc-workload",   the object name suffix
    "kind": "LLMInferenceService",
    "nameLabel": <the label that carries the served model's name>,
    "runtimeContainer": <the container that serves>,
    "port": <the port the pod is reached on, its Service's target: modelServing.networkPolicy.llmisvcWorkload.port>,
    "matchExpressions": [<the label selector of the pod>],
    "multiNodeExpressions": [<the label selector of a LeaderWorkerSet's pods>] }
Usage: $shape := include "agent-platform.modelServing.podShape" . | fromJson
*/}}
{{- define "agent-platform.modelServing.podShape" -}}
{{- $np := .Values.modelServing.networkPolicy -}}
{{- $llmisvc := dict "name" "llmisvc-workload" "kind" "LLMInferenceService" "nameLabel" "app.kubernetes.io/name" "runtimeContainer" "main" "port" (int $np.llmisvcWorkload.port) -}}
{{- $components := list "llminferenceservice-workload" "llminferenceservice-workload-prefill" "llminferenceservice-workload-leader" "llminferenceservice-workload-worker" "llminferenceservice-workload-leader-prefill" "llminferenceservice-workload-worker-prefill" -}}
{{- $_ := set $llmisvc "matchExpressions" (list (dict "key" "app.kubernetes.io/component" "operator" "In" "values" $components) (dict "key" "app.kubernetes.io/part-of" "operator" "In" "values" (list "llminferenceservice"))) -}}
{{- $_ := set $llmisvc "multiNodeExpressions" (list (dict "key" "app.kubernetes.io/component" "operator" "In" "values" (list "llminferenceservice-workload-leader" "llminferenceservice-workload-worker" "llminferenceservice-workload-leader-prefill" "llminferenceservice-workload-worker-prefill")) (dict "key" "app.kubernetes.io/part-of" "operator" "In" "values" (list "llminferenceservice"))) -}}
{{- $llmisvc | toJson -}}
{{- end -}}

{{/*
The Kyverno foreach entries that bound every emptyDir of a model pod
(modelServing.serving: shmSizeLimit, modelCacheSizeLimit, emptyDirSizeLimit):
dshm gets shmSizeLimit whatever KServe's template set, the volume the
storage-initializer downloads into (model-cache or kserve-provision-location,
by KServe release) modelCacheSizeLimit when modelServing.cache.enabled is false
(with the cache on, the redirect rule mounts the claim at /mnt/models instead
and the emptyDir holds nothing), and every other emptyDir without a sizeLimit
gets emptyDirSizeLimit; a sizeLimit the template set on one of those stays.
The volumes are found by the pod spec's own list, so a pod shape's own
emptyDirs (an hf:// pod's model-cache, an oci:// modelcar pod's
kserve-provision-location) are bounded without being named and none is added.
"spec" is the JMESPath of the pod spec (request.object.spec for a Pod,
request.object.spec.template.spec for a Deployment), "nest" the keys the patch
nests the spec under (list "spec" or list "spec" "template" "spec").
Usage: include "agent-platform.modelServing.emptyDirBounds" (dict "root" $ "spec" "request.object.spec" "nest" (list "spec"))
*/}}
{{- define "agent-platform.modelServing.emptyDirBounds" -}}
{{- $ms := .root.Values.modelServing -}}
{{- $s := $ms.serving -}}
{{- $named := dict "dshm" (required "modelServing.serving.shmSizeLimit is required: the model pod's /dev/shm is bounded" $s.shmSizeLimit) -}}
{{- if not $ms.cache.enabled -}}
{{- $limit := toString (required "modelServing.serving.modelCacheSizeLimit is required with modelServing.cache.enabled false: model-cache holds the download" $s.modelCacheSizeLimit) -}}
{{- if not (regexMatch "^[1-9][0-9]*(Gi|Ti)$" $limit) -}}
{{- fail (printf "modelServing.serving.modelCacheSizeLimit (%s) is a whole number of Gi or Ti, compared with the presets' requirements.weightsGiB" $limit) -}}
{{- end -}}
{{- $limitGiB := mul (trimSuffix "Gi" (trimSuffix "Ti" $limit) | int) (ternary 1024 1 (hasSuffix "Ti" $limit)) -}}
{{- range $name, $entry := include "agent-platform.modelServing.presets" .root | fromJson -}}
{{- $weights := dig "spec" "requirements" "weightsGiB" 0 $entry.preset | int -}}
{{- if and (hasPrefix "hf://" (dig "spec" "model" "storageUri" "" $entry.preset)) (gt $weights $limitGiB) -}}
{{- fail (printf "modelServing.serving.modelCacheSizeLimit (%s) is smaller than preset %s's %d GiB of weights: with modelServing.cache.enabled false its pod downloads them into model-cache" $limit $name $weights) -}}
{{- end -}}
{{- end -}}
{{- /* The download's volume: model-cache on KServe releases that mount it at
       /mnt/models, kserve-provision-location on the current ones. */ -}}
{{- $_ := set $named "model-cache" $limit -}}
{{- $_ := set $named "kserve-provision-location" $limit -}}
{{- end -}}
{{- $default := required "modelServing.serving.emptyDirSizeLimit is required: every emptyDir of a model pod is bounded" $s.emptyDirSizeLimit -}}
{{- /* One JSON patch per volume, at its index: an add on an existing member
       replaces it, so a reinvoked webhook sets the same value again and the
       volumes keep KServe's order (a strategic merge moves the patched
       entries to the front of the list). */ -}}
{{- $value := list -}}
{{- range $name := keys $named | sortAlpha -}}
{{- $value = append $value (printf "(element.name == '%s' && '%s')" $name (toString (get $named $name))) -}}
{{- end -}}
{{- $value = append $value (printf "element.emptyDir.sizeLimit || '%s'" (toString $default)) }}
- list: {{ printf "%s.volumes" .spec | quote }}
  preconditions:
    all:
      - key: {{ "{{ contains(keys(element), 'emptyDir') }}" | quote }}
        operator: Equals
        value: true
  patchesJson6902: |-
    - op: add
      path: {{ printf "/%s/volumes/{{ elementIndex }}/emptyDir/sizeLimit" (join "/" .nest) }}
      value: {{ printf "{{ %s }}" (join " || " $value) | quote }}
{{- end -}}

{{/*
The Kyverno `match` entry selecting the model pods of the serving namespace at
CREATE (agent-platform.modelServing.podShape); the caller nests it under
`match.any`. Kinds default to Pod; the operations to CREATE (a pod's init
containers are immutable, and the filter keeps later updates untouched).
Usage: include "agent-platform.modelServing.kyvernoMatch" (dict "root" $ "kinds" (list "Deployment") "operations" (list "CREATE" "UPDATE"))
*/}}
{{- define "agent-platform.modelServing.kyvernoMatch" -}}
{{- $ns := include "agent-platform.modelServing.namespace" .root -}}
{{- $shape := include "agent-platform.modelServing.podShape" .root | fromJson }}
# {{ $shape.kind }}
- resources:
    kinds:
      {{- toYaml (.kinds | default (list "Pod")) | nindent 6 }}
    namespaces:
      - {{ $ns }}
    operations:
      {{- toYaml (.operations | default (list "CREATE")) | nindent 6 }}
    selector:
      matchExpressions:
        {{- toYaml $shape.matchExpressions | nindent 8 }}
{{- end -}}

{{/*
The JMESPath (bare, no delimiters) of the served model's name on a model pod:
the pod shape's name label. It names the pod's cache subdirectory
(<claim>/<model>). Kyverno evaluates it at admission; the caller wraps it in
its delimiters (and `length(... || '')` for a precondition that the pod carries
one at all).
*/}}
{{- define "agent-platform.modelServing.modelNamePath" -}}
{{- printf "request.object.metadata.labels.%q" (include "agent-platform.modelServing.podShape" . | fromJson).nameLabel -}}
{{- end -}}

{{/*
The OTLP endpoint the model pods export traces to, which
<release>-model-serving-otlp-egress opens: modelServing.networkPolicy.otlpEndpoint,
where the meta chart writes the tracing preset's resolved endpoint; `auto`
(this chart rendered on its own) follows global.observability.traces.otlp.endpoint.
vLLM and the llm-d endpoint picker export over gRPC only, so `auto` with an
http/protobuf global protocol fails the render. Empty: no export, no rule.
Usage: include "agent-platform.modelServing.otlpEndpoint" .
*/}}
{{- define "agent-platform.modelServing.otlpEndpoint" -}}
{{- $own := dig "networkPolicy" "otlpEndpoint" "auto" (.Values.modelServing | default dict) | default "" | toString | trim -}}
{{- if eq $own "auto" -}}
{{- $otlp := dig "observability" "traces" "otlp" dict (.Values.global | default dict) | default dict -}}
{{- $endpoint := dig "endpoint" "" $otlp | default "" | toString | trim -}}
{{- $protocol := dig "protocol" "" $otlp | default "grpc" | toString | lower -}}
{{- if and $endpoint (ne $protocol "grpc") -}}
{{- fail (printf "global.observability.traces.otlp.protocol is %s, but the model pods export OTLP over gRPC only (the LLMInferenceService tracing spec has no protocol): set modelServing.networkPolicy.otlpEndpoint to the collector's gRPC endpoint" $protocol) -}}
{{- end -}}
{{- $endpoint -}}
{{- else -}}
{{- $own -}}
{{- end -}}
{{- end -}}
