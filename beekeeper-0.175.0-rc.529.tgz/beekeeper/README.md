# beekeeper

beekeeper, being rebuilt; this chart version installs no resources

**Homepage:** <https://github.com/giantswarm/beekeeper>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Giant Swarm | <team-bumblebee@giantswarm.io> |  |

## Source Code

* <https://github.com/giantswarm/beekeeper>
